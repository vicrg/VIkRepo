var Toolkit = (function () {
'use strict';

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) {
  return typeof obj;
} : function (obj) {
  return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
};











var classCallCheck = function (instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
};

var createClass = function () {
  function defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor) descriptor.writable = true;
      Object.defineProperty(target, descriptor.key, descriptor);
    }
  }

  return function (Constructor, protoProps, staticProps) {
    if (protoProps) defineProperties(Constructor.prototype, protoProps);
    if (staticProps) defineProperties(Constructor, staticProps);
    return Constructor;
  };
}();







var get = function get(object, property, receiver) {
  if (object === null) object = Function.prototype;
  var desc = Object.getOwnPropertyDescriptor(object, property);

  if (desc === undefined) {
    var parent = Object.getPrototypeOf(object);

    if (parent === null) {
      return undefined;
    } else {
      return get(parent, property, receiver);
    }
  } else if ("value" in desc) {
    return desc.value;
  } else {
    var getter = desc.get;

    if (getter === undefined) {
      return undefined;
    }

    return getter.call(receiver);
  }
};

var inherits = function (subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }

  subClass.prototype = Object.create(superClass && superClass.prototype, {
    constructor: {
      value: subClass,
      enumerable: false,
      writable: true,
      configurable: true
    }
  });
  if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
};











var possibleConstructorReturn = function (self, call) {
  if (!self) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }

  return call && (typeof call === "object" || typeof call === "function") ? call : self;
};

var d3 = window.d3;
function camelize(text, separator) {

  // Assume separator is _ if no one has been provided.
  if (typeof separator === "undefined") {
    separator = "_";
  }

  // Cut the string into words
  var words = text.split(separator);

  // Concatenate all capitalized words to get camelized string
  var result = "";
  for (var i = 0; i < words.length; i++) {
    var word = words[i];
    var capitalizedWord = word.charAt(0).toUpperCase() + word.slice(1);
    result += capitalizedWord;
  }

  return result;
}

function isMergeableObject(val) {
  var nonNullObject = val && (typeof val === "undefined" ? "undefined" : _typeof(val)) === 'object';

  return nonNullObject && Object.prototype.toString.call(val) !== '[object RegExp]' && Object.prototype.toString.call(val) !== '[object Date]';
}

function emptyTarget(val) {
  return Array.isArray(val) ? [] : {};
}

function cloneIfNecessary(value, optionsArgument) {
  var clone = optionsArgument && optionsArgument.clone === true;
  return clone && isMergeableObject(value) ? deepmerge(emptyTarget(value), value, optionsArgument) : value;
}

function defaultArrayMerge(target, source, optionsArgument) {
  var destination = target.slice();
  source.forEach(function (e, i) {
    if (typeof destination[i] === 'undefined') {
      destination[i] = cloneIfNecessary(e, optionsArgument);
    } else if (isMergeableObject(e)) {
      destination[i] = deepmerge(target[i], e, optionsArgument);
    } else if (target.indexOf(e) === -1) {
      destination.push(cloneIfNecessary(e, optionsArgument));
    }
  });
  return destination;
}

function mergeObject(target, source, optionsArgument) {
  var destination = {};
  if (isMergeableObject(target)) {
    Object.keys(target).forEach(function (key) {
      destination[key] = cloneIfNecessary(target[key], optionsArgument);
    });
  }
  Object.keys(source).forEach(function (key) {
    if (!isMergeableObject(source[key]) || !target[key]) {
      destination[key] = cloneIfNecessary(source[key], optionsArgument);
    } else {
      destination[key] = deepmerge(target[key], source[key], optionsArgument);
    }
  });
  return destination;
}

function deepmerge(target, source, optionsArgument) {
  var array = Array.isArray(source);
  var options = optionsArgument || { arrayMerge: defaultArrayMerge };
  var arrayMerge = options.arrayMerge || defaultArrayMerge;

  if (array) {
    return Array.isArray(target) ? arrayMerge(target, source, optionsArgument) : cloneIfNecessary(source, optionsArgument);
  } else {
    return mergeObject(target, source, optionsArgument);
  }
}

deepmerge.all = function deepmergeAll(array, optionsArgument) {
  if (!Array.isArray(array) || array.length < 2) {
    throw new Error('first argument should be an array with at least two elements');
  }

  // we are sure there are at least 2 values, so it is safe to have no initial value
  return array.reduce(function (prev, next) {
    return deepmerge(prev, next, optionsArgument);
  });
};

function debounce(callback, wait) {
  var context = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : this;

  var timeout = null;
  var callbackArgs = null;

  var later = function later() {
    return callback.apply(context, callbackArgs);
  };

  return function () {
    callbackArgs = arguments;
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

var Base = function () {
  function Base(_ref) {
    var _ref$data = _ref.data,
        data = _ref$data === undefined ? {} : _ref$data,
        _ref$selector = _ref.selector,
        selector = _ref$selector === undefined ? 'body' : _ref$selector,
        _ref$config = _ref.config,
        config = _ref$config === undefined ? {} : _ref$config;
    classCallCheck(this, Base);

    this.data = data;
    this.selector = selector;
    this.config = config;
    this.defaults = {
      margin: {
        top: 20,
        right: 20,
        bottom: 40,
        left: 65
      },
      width: 'auto',
      height: 310,
      vertical: {
        labels: true,
        title: true,
        lines: true,
        textTitle: 'Metrics'
      },
      horizontal: {
        title: true,
        lines: true,
        labels: true,
        textTitle: 'Metrics'
      },
      borderColor: '#CCCCCC',
      borders: true,
      legend: false,
      legendText: ['Option 01', 'Option 02'],
      colors: ['#002D72', '#008ce6']
    };
  }

  createClass(Base, [{
    key: "merge",
    value: function merge(source, target) {
      return deepmerge(source, target);
    }
  }, {
    key: "concat",
    value: function concat(name, data) {
      var _this = this;

      if (data[name]) {
        data[name].forEach(function (item) {
          _this._data = _this._data.concat(item);
        });
        this['has' + camelize(name)] = true;
        this[name] = data[name];
      } else {
        this[name] = [];
      }
    }
  }, {
    key: "renderElements",
    value: function renderElements() {
      var _config = this.config,
          legend = _config.legend,
          horizontal = _config.horizontal,
          vertical = _config.vertical,
          borders = _config.borders;

      this.container();
      if (vertical.labels) this.verticalLabels();
      if (horizontal.labels) this.horizontalLabels();
      if (borders) this.borders();
      if (horizontal.lines) this.horizontalLines();
      if (vertical.lines) this.verticalLines();
      if (legend) this.legend();
    }
  }, {
    key: "render",
    value: function render() {
      this.responsive();

      this.coordinates();
      this.domains();
      this.axis();

      this.renderElements();
      this.graphic();
      return this;
    }
  }, {
    key: "responsive",
    value: function responsive() {
      var _this2 = this;

      var render = debounce(function (e) {
        _this2.d3.select(_this2.svg.node().parentNode).remove();

        _this2.coordinates();
        _this2.domains();
        _this2.axis();

        _this2.renderElements();
        _this2.graphic();
      }, 200);
      window.addEventListener('resize', render);
    }
  }, {
    key: "graphic",
    value: function graphic() {}
  }, {
    key: "legend",
    value: function legend() {
      var sampleCategoricalData = this.config.legendText;
      var sampleOrdinal = this.d3.scale.ordinal().domain(sampleCategoricalData).range(this.config.colors);
      var verticalLegend = this.d3.svg.legend().labelFormat("none").cellPadding(3).orientation("vertical").units('').cellWidth(12).cellHeight(12).cellPadding(5).inputScale(sampleOrdinal);

      this.svg.append("g").data(this.config.colors).attr("class", "legend").attr('font-size', '0.6em').attr("transform", "translate(" + (this.reducedWidth() + 10) + "," + 0 + ")").call(verticalLegend);
    }
  }, {
    key: "xValue",
    value: function xValue() {
      var width = this.reducedWidth();
      this.x = this.d3.scale.ordinal().rangeRoundBands([0, width]);
    }
  }, {
    key: "yValue",
    value: function yValue() {
      this.y = this.d3.scale.linear().range([this.height, 0]);
    }
  }, {
    key: "xAxisValue",
    value: function xAxisValue() {
      this.xAxis = this.d3.svg.axis().scale(this.x).orient("bottom");
    }
  }, {
    key: "yAxisValue",
    value: function yAxisValue() {
      this.yAxis = this.d3.svg.axis().scale(this.y).orient("left");
    }
  }, {
    key: "coordinates",
    value: function coordinates() {
      this.xValue();
      this.yValue();
    }
  }, {
    key: "domains",
    value: function domains() {
      this.xDomain();
      this.yDomain();
    }
  }, {
    key: "axis",
    value: function axis() {
      this.xAxisValue();
      this.yAxisValue();
    }
  }, {
    key: "xDomain",
    value: function xDomain() {
      var callback = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : function (d) {
        return d.label;
      };
      var data = this.data;

      this.x.domain(data.map(callback));
    }
  }, {
    key: "yDomain",
    value: function yDomain() {
      var callback = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : this.config.yRange;

      this.y.domain([0, callback]);
    }
  }, {
    key: "reducedWidth",
    value: function reducedWidth() {
      if (this.config.legend) {
        return this.width - 85;
      }
      return this.width;
    }
  }, {
    key: "borders",
    value: function borders() {
      this.svg.append("rect").attr("x", 0).attr("y", 0).attr("height", this.height).attr("width", this.reducedWidth()).style("stroke", this.config.borderColor).style("fill", "none").style('shape-rendering', 'crispEdges').style("stroke-width", '1px');
    }
  }, {
    key: "horizontalLabels",
    value: function horizontalLabels() {
      var _config$horizontal = this.config.horizontal,
          textTitle = _config$horizontal.textTitle,
          title = _config$horizontal.title;
      // Label

      this.svg.append('g').attr('class', 'x axis labels').attr('font-size', '0.6em').attr('transform', "translate(0," + this.height + ")").call(this.xAxis);

      if (title) {
        this.svg.append("text").attr("text-anchor", "middle").style("font-size", "0.6em").attr("transform", "translate(" + this.reducedWidth() / 2 + "," + (this.height + 30) + ")").text(textTitle);
      }
    }
  }, {
    key: "verticalLabels",
    value: function verticalLabels() {
      var _config2 = this.config,
          vertical = _config2.vertical,
          margin = _config2.margin;
      var textTitle = vertical.textTitle,
          title = vertical.title;


      if (title) {
        this.svg.append("text").attr("y", this.height / 2)
        //30 is the gap
        .attr("x", -margin.left + 25).attr("dy", "1em").attr('font-size', '0.6em').style("text-anchor", "middle").text(textTitle);
      }

      // label
      this.svg.append('g').attr('class', 'y axis labels').attr('font-size', '0.6em').call(this.yAxis);
    }
  }, {
    key: "horizontalLines",
    value: function horizontalLines() {
      var yAxisGrid = this.d3.svg.axis().scale(this.y).tickSize(this.reducedWidth(), 0).tickFormat("").orient("right");

      this.svg.append("g").classed('y', true).classed('axis', true).call(yAxisGrid);
    }
  }, {
    key: "verticalLines",
    value: function verticalLines() {
      var xAxisGrid = this.d3.svg.axis().scale(this.x).tickSize(this.height, 0).tickFormat("").orient("bottom");

      this.svg.append("g").classed('y', true).classed('axis', true).call(xAxisGrid);
    }
  }, {
    key: "container",
    value: function container() {
      var d3 = this.d3;
      var _config3 = this.config,
          margin = _config3.margin,
          height = _config3.height;


      this.svg = d3.select(this.selector).append('svg').attr('width', this.d3.select(this.selector).node().clientWidth).attr('height', height).append('g').attr('transform', "translate(" + margin.left + "," + margin.top + ")");
    }
  }, {
    key: "data",
    get: function get$$1() {
      return this._data;
    },
    set: function set$$1(data) {
      var _this3 = this;

      this._data = [];
      ['lines', 'dots', 'linesdot'].forEach(function (name) {
        return _this3.concat(name, data);
      });
    }
  }, {
    key: "d3",
    get: function get$$1() {
      return d3;
    }
  }, {
    key: "width",
    get: function get$$1() {
      var width = this.config.width;
      var margin = this.config.margin;

      if (width === 'auto') {
        width = this.d3.select(this.selector).node().clientWidth;
      }
      return width - margin.left - margin.right;
    }
  }, {
    key: "height",
    get: function get$$1() {
      var _config4 = this.config,
          margin = _config4.margin,
          height = _config4.height;

      return height - margin.top - margin.bottom;
    }
  }]);
  return Base;
}();

var Bar = function (_Base) {
  inherits(Bar, _Base);

  function Bar(data) {
    classCallCheck(this, Bar);

    var _this = possibleConstructorReturn(this, (Bar.__proto__ || Object.getPrototypeOf(Bar)).call(this, data));

    _this.defaults = _this.merge(_this.defaults, {
      yRange: 10,
      tips: true,
      vertical: {
        lines: false
      }
    });
    return _this;
  }

  createClass(Bar, [{
    key: 'renderElements',
    value: function renderElements() {
      var tips = this.config.tips;

      get(Bar.prototype.__proto__ || Object.getPrototypeOf(Bar.prototype), 'renderElements', this).call(this);
      if (tips) this.tips();
    }
  }, {
    key: 'tips',
    value: function tips() {
      this.tip = this.d3.tip().attr('class', 'd3-tip').offset([-10, 0]).html(function (d) {
        return d.value;
      });
      this.svg.call(this.tip);
    }
  }]);
  return Bar;
}(Base);

var BarChart = function (_Bar) {
  inherits(BarChart, _Bar);

  function BarChart(data) {
    classCallCheck(this, BarChart);

    var _this = possibleConstructorReturn(this, (BarChart.__proto__ || Object.getPrototypeOf(BarChart)).call(this, data));

    _this.defaults = _this.merge(_this.defaults, {});
    _this.config = _this.merge(_this.defaults, _this.config);
    return _this;
  }

  createClass(BarChart, [{
    key: "graphic",
    value: function graphic() {
      var _this2 = this;

      this.lines.forEach(function (line) {
        _this2.svg.selectAll(".bar").data(line).enter().append("rect").attr("class", "bar").attr("x", function (d) {
          return _this2.x(d.label) + 5;
        }).attr("width", 15).attr("y", function (d) {
          return _this2.y(d.value / 1000000);
        }).attr("height", function (d) {
          return _this2.height - _this2.y(d.value / 1000000);
        }).on('mouseover', _this2.tip.show).on('mouseout', _this2.tip.hide);
      });
    }
  }]);
  return BarChart;
}(Bar);

var Line = function (_Base) {
  inherits(Line, _Base);

  function Line(data) {
    classCallCheck(this, Line);

    var _this = possibleConstructorReturn(this, (Line.__proto__ || Object.getPrototypeOf(Line)).call(this, data));

    _this.defaults = _this.merge(_this.defaults, {
      yRange: 10,
      legend: true
    });
    return _this;
  }

  createClass(Line, [{
    key: 'xValue',
    value: function xValue() {
      var len = this.lines[0].length - 1;
      this.x = this.d3.scale.linear().range([0, this.reducedWidth() / len]);
    }
  }, {
    key: 'yValue',
    value: function yValue() {
      this.y = this.d3.scale.linear().range([this.height, 0]);
    }
  }]);
  return Line;
}(Base);

var LineChart = function (_Line) {
  inherits(LineChart, _Line);

  function LineChart(data) {
    classCallCheck(this, LineChart);

    var _this = possibleConstructorReturn(this, (LineChart.__proto__ || Object.getPrototypeOf(LineChart)).call(this, data));

    _this.defaults = _this.merge(_this.defaults, {});
    _this.config = _this.merge(_this.defaults, _this.config);
    return _this;
  }

  createClass(LineChart, [{
    key: 'graphic',
    value: function graphic() {
      var _this2 = this;

      this.lineSelection = this.d3.svg.line().x(function (d) {
        return _this2.x(d.label);
      }).y(function (d) {
        return _this2.y(d.value);
      });

      this.lines.forEach(function (line, idx) {
        _this2.svg.append("svg:path").data(line).attr('d', _this2.lineSelection(line)).attr('stroke', _this2.config.colors[idx]).attr('stroke-width', 2).attr('fill', 'none');
      });

      this.linesdot.forEach(function (dot, idx) {
        _this2.svg.selectAll("dot").data(dot).enter().append("circle").attr("r", 3.5).style("fill", _this2.config.colors[idx]).attr("cx", function (d) {
          return _this2.x(d.label);
        }).attr("cy", function (d) {
          return _this2.y(d.value);
        });
      });
    }
  }]);
  return LineChart;
}(Line);

var LineDotChart = function (_Line) {
  inherits(LineDotChart, _Line);

  function LineDotChart(data) {
    classCallCheck(this, LineDotChart);

    var _this = possibleConstructorReturn(this, (LineDotChart.__proto__ || Object.getPrototypeOf(LineDotChart)).call(this, data));

    _this.defaults = _this.merge(_this.defaults, {
      colors: ['#002D72', '#008ce6', '#c6007e'],
      texts: ['Option 1', 'Option 2']
    });
    _this.config = _this.merge(_this.defaults, _this.config);
    return _this;
  }

  createClass(LineDotChart, [{
    key: 'renderElements',
    value: function renderElements() {
      get(LineDotChart.prototype.__proto__ || Object.getPrototypeOf(LineDotChart.prototype), 'renderElements', this).call(this);
    }
  }, {
    key: 'graphic',
    value: function graphic() {
      var _this2 = this;

      var colors = this.config.colors;

      this.lineSelection = this.d3.svg.line().x(function (d) {
        return _this2.x(d.label);
      }).y(function (d) {
        return _this2.y(d.value);
      });

      this.lines.forEach(function (line, idx) {
        _this2.svg.append("svg:path").data(line).attr('d', _this2.lineSelection(line)).attr('stroke', _this2.config.colors[idx]).attr('stroke-width', 2).attr('fill', 'none');
      });

      this.linesdot.forEach(function (linedot, idx) {
        var d3 = _this2.d3;

        _this2.svg.append("svg:path").data(linedot).attr('d', _this2.lineSelection(linedot)).attr('stroke', _this2.config.colors[idx]).attr('stroke-width', 2).attr('fill', 'none');
        _this2.svg.selectAll("dot").data(linedot).enter().append("circle").attr("r", 4.5).style("fill", '#ffffff').attr("cx", function (d) {
          return _this2.x(d.label);
        }).attr("cy", function (d) {
          return _this2.y(d.value);
        }).attr("stroke", colors[idx]).attr("stroke-width", 2).on("mouseover", function () {
          d3.select(this).style("fill", colors[idx]);
        }).on("mouseout", function () {
          d3.select(this).style({ "fill": '#ffffff' });
        });
      });
    }
  }]);
  return LineDotChart;
}(Line);

var LineFillChart = function (_LineChart) {
  inherits(LineFillChart, _LineChart);

  function LineFillChart(data) {
    classCallCheck(this, LineFillChart);

    var _this = possibleConstructorReturn(this, (LineFillChart.__proto__ || Object.getPrototypeOf(LineFillChart)).call(this, data));

    _this.defaults = _this.merge(_this.defaults, {});
    _this.config = _this.merge(_this.defaults, _this.config);
    return _this;
  }

  createClass(LineFillChart, [{
    key: "graphic",
    value: function graphic() {
      var _this2 = this;

      this.lineSelection = this.d3.svg.line().x(function (d) {
        return _this2.x(d.label);
      }).y(function (d) {
        return _this2.y(d.value);
      });

      this.lines.forEach(function (line, idx) {
        var area = _this2.d3.svg.area().x(function (d) {
          return _this2.x(d.label);
        }).y0(_this2.height).y1(function (d) {
          return _this2.y(d.value);
        });

        _this2.svg.append("path").datum(line).attr("fill", _this2.config.colors[idx]).attr("opacity", '0.8').attr("d", area);
      });
    }
  }]);
  return LineFillChart;
}(LineChart);

var Utils = function () {
  function Utils() {
    classCallCheck(this, Utils);
  }

  createClass(Utils, null, [{
    key: 'throwDetailed',
    value: function throwDetailed(message) {
      var err = void 0;
      try {
        throw new Error('myError');
      } catch (e) {
        err = e;
      }
      if (!err) return;

      var aux = err.stack.split("\n");
      aux.splice(0, 2); //removing the line that we force to generate the error (var err = new Error();) from the message
      aux = aux.join('\n"');
      throw message + ' \n' + aux;
    }
  }]);
  return Utils;
}();

var ScatterPotLineChart = function (_Line) {
  inherits(ScatterPotLineChart, _Line);

  function ScatterPotLineChart(data) {
    classCallCheck(this, ScatterPotLineChart);

    var _this = possibleConstructorReturn(this, (ScatterPotLineChart.__proto__ || Object.getPrototypeOf(ScatterPotLineChart)).call(this, data));

    _this.defaults = _this.merge(_this.defaults, {
      colors: ['#008ce6', '#002D72', '#c6007e'],
      texts: ['Option 1', 'Option 2'],
      legend: true
    });
    _this.config = _this.merge(_this.defaults, _this.config);
    return _this;
  }

  createClass(ScatterPotLineChart, [{
    key: 'xValue',
    value: function xValue() {
      var len = this.dots[0].length - 1;
      var len2 = this.lines[0].length - 1;
      this.x = this.d3.scale.linear().range([0, this.reducedWidth() / len]);
      this.x2 = this.d3.scale.linear().range([0, this.reducedWidth() / len2]);
    }
  }, {
    key: 'graphic',
    value: function graphic() {
      var _this2 = this;

      this.dots.forEach(function (dot, idx) {
        _this2.svg.selectAll("dot").data(dot).enter().append("circle").attr("r", 3.5).style("fill", _this2.config.colors[idx]).attr("cx", function (d) {
          return _this2.x(d.label);
        }).attr("cy", function (d) {
          return _this2.y(d.value);
        });
      });

      this.lineSelection = this.d3.svg.line().x(function (d) {
        return _this2.x2(d.label);
      }).y(function (d) {
        return _this2.y(d.value);
      });

      this.lines.forEach(function (line, idx) {
        _this2.svg.append("svg:path").data(line).attr('d', _this2.lineSelection(line)).attr('stroke', _this2.config.colors[idx]).attr('stroke-width', 1).attr('transform', "translate(-4,0)").attr('fill', 'none');
      });
    }
  }]);
  return ScatterPotLineChart;
}(Line);

// import CanvasLineChart from './canvasline'
var Chart = function () {
  function Chart(_ref) {
    var _ref$name = _ref.name,
        name = _ref$name === undefined ? '' : _ref$name,
        _ref$data = _ref.data,
        data = _ref$data === undefined ? [] : _ref$data,
        _ref$selector = _ref.selector,
        selector = _ref$selector === undefined ? 'body' : _ref$selector,
        _ref$config = _ref.config,
        config = _ref$config === undefined ? {} : _ref$config;
    classCallCheck(this, Chart);

    this.name = name;
    this.data = data;
    this.selector = selector;
    this.config = config;
  }

  createClass(Chart, [{
    key: 'render',
    value: function render() {
      var _ref2 = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
          _ref2$name = _ref2.name,
          name = _ref2$name === undefined ? this.name : _ref2$name,
          _ref2$data = _ref2.data,
          data = _ref2$data === undefined ? this.data : _ref2$data,
          _ref2$selector = _ref2.selector,
          selector = _ref2$selector === undefined ? this.selector : _ref2$selector;

      var config = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : this.config;

      switch (name) {
        case 'Bar':
          return new BarChart({ data: data, selector: selector, config: config }).render();
          break;
        case 'Line':
          return new LineChart({ data: data, selector: selector, config: config }).render();
          break;
        case 'LineDot':
          return new LineDotChart({ data: data, selector: selector, config: config }).render();
          break;
        case 'LineFill':
          return new LineFillChart({ data: data, selector: selector, config: config }).render();
          break;
        case 'ScatterPotLine':
          return new ScatterPotLineChart({ data: data, selector: selector, config: config }).render();
          break;
        // case 'CanvasLine':
        //   return new CanvasLineChart(data, selector).render();
        //   break;
        default:
          return Utils.throwDetailed("Toolkit | Charts availables: Bar, CanvasLine");
      }
    }
  }]);
  return Chart;
}();

if (!window.d3) throw { message: "Toolkit uses https://d3js.org/ as Graphic library, please add it" };

var Toolkit = function () {
  function Toolkit() {
    classCallCheck(this, Toolkit);
  }

  createClass(Toolkit, [{
    key: 'chart',
    value: function chart(_ref) {
      var _ref$name = _ref.name,
          name = _ref$name === undefined ? '' : _ref$name,
          _ref$data = _ref.data,
          data = _ref$data === undefined ? [] : _ref$data,
          _ref$selector = _ref.selector,
          selector = _ref$selector === undefined ? 'body' : _ref$selector,
          _ref$config = _ref.config,
          config = _ref$config === undefined ? {} : _ref$config;

      return new Chart({ name: name, data: data, selector: selector, config: config });
    }
  }]);
  return Toolkit;
}();

var toolkit = new Toolkit();

return toolkit;

}());
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2l0aS10b29sa2l0LmpzIiwic291cmNlcyI6WyIuLi8uLi9zcmMvanMvY2hhcnRzL2Jhc2UuanMiLCIuLi8uLi9zcmMvanMvY2hhcnRzL2Jhci5qcyIsIi4uLy4uL3NyYy9qcy9jaGFydHMvYmFyY2hhcnQuanMiLCIuLi8uLi9zcmMvanMvY2hhcnRzL2xpbmUuanMiLCIuLi8uLi9zcmMvanMvY2hhcnRzL2xpbmVjaGFydC5qcyIsIi4uLy4uL3NyYy9qcy9jaGFydHMvbGluZWRvdGNoYXJ0LmpzIiwiLi4vLi4vc3JjL2pzL2NoYXJ0cy9saW5lZmlsbGNoYXJ0LmpzIiwiLi4vLi4vc3JjL2pzL3V0aWxzL2Jhc2UuanMiLCIuLi8uLi9zcmMvanMvY2hhcnRzL3NjYXR0ZXJwb3RsaW5lY2hhcnQuanMiLCIuLi8uLi9zcmMvanMvY2hhcnRzL2NoYXJ0LmpzIiwiLi4vLi4vc3JjL2pzL3Rvb2xraXQuanMiXSwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgZDMgPSB3aW5kb3cuZDM7XG5mdW5jdGlvbiBjYW1lbGl6ZSh0ZXh0LCBzZXBhcmF0b3IpIHtcblxuICAvLyBBc3N1bWUgc2VwYXJhdG9yIGlzIF8gaWYgbm8gb25lIGhhcyBiZWVuIHByb3ZpZGVkLlxuICBpZih0eXBlb2Yoc2VwYXJhdG9yKSA9PT0gXCJ1bmRlZmluZWRcIikge1xuICAgIHNlcGFyYXRvciA9IFwiX1wiO1xuICB9XG5cbiAgLy8gQ3V0IHRoZSBzdHJpbmcgaW50byB3b3Jkc1xuICB2YXIgd29yZHMgPSB0ZXh0LnNwbGl0KHNlcGFyYXRvcik7XG5cbiAgLy8gQ29uY2F0ZW5hdGUgYWxsIGNhcGl0YWxpemVkIHdvcmRzIHRvIGdldCBjYW1lbGl6ZWQgc3RyaW5nXG4gIHZhciByZXN1bHQgPSBcIlwiO1xuICBmb3IgKHZhciBpID0gMCA7IGkgPCB3b3Jkcy5sZW5ndGggOyBpKyspIHtcbiAgICB2YXIgd29yZCA9IHdvcmRzW2ldO1xuICAgIHZhciBjYXBpdGFsaXplZFdvcmQgPSB3b3JkLmNoYXJBdCgwKS50b1VwcGVyQ2FzZSgpICsgd29yZC5zbGljZSgxKTtcbiAgICByZXN1bHQgKz0gY2FwaXRhbGl6ZWRXb3JkO1xuICB9XG5cbiAgcmV0dXJuIHJlc3VsdDtcbn1cblxuZnVuY3Rpb24gaXNNZXJnZWFibGVPYmplY3QodmFsKSB7XG4gIHZhciBub25OdWxsT2JqZWN0ID0gdmFsICYmIHR5cGVvZiB2YWwgPT09ICdvYmplY3QnO1xuXG4gIHJldHVybiBub25OdWxsT2JqZWN0XG4gICAgJiYgT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKHZhbCkgIT09ICdbb2JqZWN0IFJlZ0V4cF0nXG4gICAgJiYgT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKHZhbCkgIT09ICdbb2JqZWN0IERhdGVdJ1xufVxuXG5mdW5jdGlvbiBlbXB0eVRhcmdldCh2YWwpIHtcbiAgcmV0dXJuIEFycmF5LmlzQXJyYXkodmFsKSA/IFtdIDoge31cbn1cblxuZnVuY3Rpb24gY2xvbmVJZk5lY2Vzc2FyeSh2YWx1ZSwgb3B0aW9uc0FyZ3VtZW50KSB7XG4gIHZhciBjbG9uZSA9IG9wdGlvbnNBcmd1bWVudCAmJiBvcHRpb25zQXJndW1lbnQuY2xvbmUgPT09IHRydWVcbiAgcmV0dXJuIChjbG9uZSAmJiBpc01lcmdlYWJsZU9iamVjdCh2YWx1ZSkpID8gZGVlcG1lcmdlKGVtcHR5VGFyZ2V0KHZhbHVlKSwgdmFsdWUsIG9wdGlvbnNBcmd1bWVudCkgOiB2YWx1ZVxufVxuXG5mdW5jdGlvbiBkZWZhdWx0QXJyYXlNZXJnZSh0YXJnZXQsIHNvdXJjZSwgb3B0aW9uc0FyZ3VtZW50KSB7XG4gIHZhciBkZXN0aW5hdGlvbiA9IHRhcmdldC5zbGljZSgpO1xuICBzb3VyY2UuZm9yRWFjaChmdW5jdGlvbiAoZSwgaSkge1xuICAgIGlmICh0eXBlb2YgZGVzdGluYXRpb25baV0gPT09ICd1bmRlZmluZWQnKSB7XG4gICAgICBkZXN0aW5hdGlvbltpXSA9IGNsb25lSWZOZWNlc3NhcnkoZSwgb3B0aW9uc0FyZ3VtZW50KVxuICAgIH0gZWxzZSBpZiAoaXNNZXJnZWFibGVPYmplY3QoZSkpIHtcbiAgICAgIGRlc3RpbmF0aW9uW2ldID0gZGVlcG1lcmdlKHRhcmdldFtpXSwgZSwgb3B0aW9uc0FyZ3VtZW50KVxuICAgIH0gZWxzZSBpZiAodGFyZ2V0LmluZGV4T2YoZSkgPT09IC0xKSB7XG4gICAgICBkZXN0aW5hdGlvbi5wdXNoKGNsb25lSWZOZWNlc3NhcnkoZSwgb3B0aW9uc0FyZ3VtZW50KSlcbiAgICB9XG4gIH0pXG4gIHJldHVybiBkZXN0aW5hdGlvblxufVxuXG5mdW5jdGlvbiBtZXJnZU9iamVjdCh0YXJnZXQsIHNvdXJjZSwgb3B0aW9uc0FyZ3VtZW50KSB7XG4gIHZhciBkZXN0aW5hdGlvbiA9IHt9O1xuICBpZiAoaXNNZXJnZWFibGVPYmplY3QodGFyZ2V0KSkge1xuICAgIE9iamVjdC5rZXlzKHRhcmdldCkuZm9yRWFjaChmdW5jdGlvbiAoa2V5KSB7XG4gICAgICBkZXN0aW5hdGlvbltrZXldID0gY2xvbmVJZk5lY2Vzc2FyeSh0YXJnZXRba2V5XSwgb3B0aW9uc0FyZ3VtZW50KVxuICAgIH0pXG4gIH1cbiAgT2JqZWN0LmtleXMoc291cmNlKS5mb3JFYWNoKGZ1bmN0aW9uIChrZXkpIHtcbiAgICBpZiAoIWlzTWVyZ2VhYmxlT2JqZWN0KHNvdXJjZVtrZXldKSB8fCAhdGFyZ2V0W2tleV0pIHtcbiAgICAgIGRlc3RpbmF0aW9uW2tleV0gPSBjbG9uZUlmTmVjZXNzYXJ5KHNvdXJjZVtrZXldLCBvcHRpb25zQXJndW1lbnQpXG4gICAgfSBlbHNlIHtcbiAgICAgIGRlc3RpbmF0aW9uW2tleV0gPSBkZWVwbWVyZ2UodGFyZ2V0W2tleV0sIHNvdXJjZVtrZXldLCBvcHRpb25zQXJndW1lbnQpXG4gICAgfVxuICB9KTtcbiAgcmV0dXJuIGRlc3RpbmF0aW9uXG59XG5cbmZ1bmN0aW9uIGRlZXBtZXJnZSh0YXJnZXQsIHNvdXJjZSwgb3B0aW9uc0FyZ3VtZW50KSB7XG4gIHZhciBhcnJheSA9IEFycmF5LmlzQXJyYXkoc291cmNlKTtcbiAgdmFyIG9wdGlvbnMgPSBvcHRpb25zQXJndW1lbnQgfHwge2FycmF5TWVyZ2U6IGRlZmF1bHRBcnJheU1lcmdlfTtcbiAgdmFyIGFycmF5TWVyZ2UgPSBvcHRpb25zLmFycmF5TWVyZ2UgfHwgZGVmYXVsdEFycmF5TWVyZ2VcblxuICBpZiAoYXJyYXkpIHtcbiAgICByZXR1cm4gQXJyYXkuaXNBcnJheSh0YXJnZXQpID8gYXJyYXlNZXJnZSh0YXJnZXQsIHNvdXJjZSwgb3B0aW9uc0FyZ3VtZW50KSA6IGNsb25lSWZOZWNlc3Nhcnkoc291cmNlLCBvcHRpb25zQXJndW1lbnQpXG4gIH0gZWxzZSB7XG4gICAgcmV0dXJuIG1lcmdlT2JqZWN0KHRhcmdldCwgc291cmNlLCBvcHRpb25zQXJndW1lbnQpXG4gIH1cbn1cblxuZGVlcG1lcmdlLmFsbCA9IGZ1bmN0aW9uIGRlZXBtZXJnZUFsbChhcnJheSwgb3B0aW9uc0FyZ3VtZW50KSB7XG4gIGlmICghQXJyYXkuaXNBcnJheShhcnJheSkgfHwgYXJyYXkubGVuZ3RoIDwgMikge1xuICAgIHRocm93IG5ldyBFcnJvcignZmlyc3QgYXJndW1lbnQgc2hvdWxkIGJlIGFuIGFycmF5IHdpdGggYXQgbGVhc3QgdHdvIGVsZW1lbnRzJylcbiAgfVxuXG4gIC8vIHdlIGFyZSBzdXJlIHRoZXJlIGFyZSBhdCBsZWFzdCAyIHZhbHVlcywgc28gaXQgaXMgc2FmZSB0byBoYXZlIG5vIGluaXRpYWwgdmFsdWVcbiAgcmV0dXJuIGFycmF5LnJlZHVjZShmdW5jdGlvbiAocHJldiwgbmV4dCkge1xuICAgIHJldHVybiBkZWVwbWVyZ2UocHJldiwgbmV4dCwgb3B0aW9uc0FyZ3VtZW50KVxuICB9KVxufTtcblxuZnVuY3Rpb24gZGVib3VuY2UoY2FsbGJhY2ssIHdhaXQsIGNvbnRleHQgPSB0aGlzKSB7XG4gIGxldCB0aW1lb3V0ID0gbnVsbFxuICBsZXQgY2FsbGJhY2tBcmdzID0gbnVsbFxuXG4gIGNvbnN0IGxhdGVyID0gKCkgPT4gY2FsbGJhY2suYXBwbHkoY29udGV4dCwgY2FsbGJhY2tBcmdzKVxuXG4gIHJldHVybiBmdW5jdGlvbigpIHtcbiAgICBjYWxsYmFja0FyZ3MgPSBhcmd1bWVudHNcbiAgICBjbGVhclRpbWVvdXQodGltZW91dClcbiAgICB0aW1lb3V0ID0gc2V0VGltZW91dChsYXRlciwgd2FpdClcbiAgfVxufVxuXG5jbGFzcyBCYXNlIHtcbiAgY29uc3RydWN0b3Ioe2RhdGEgPSB7fSwgc2VsZWN0b3IgPSAnYm9keScsIGNvbmZpZyA9IHt9fSkge1xuICAgIHRoaXMuZGF0YSA9IGRhdGE7XG4gICAgdGhpcy5zZWxlY3RvciA9IHNlbGVjdG9yO1xuICAgIHRoaXMuY29uZmlnID0gY29uZmlnO1xuICAgIHRoaXMuZGVmYXVsdHMgPSB7XG4gICAgICBtYXJnaW46IHtcbiAgICAgICAgdG9wOiAyMCxcbiAgICAgICAgcmlnaHQ6IDIwLFxuICAgICAgICBib3R0b206IDQwLFxuICAgICAgICBsZWZ0OiA2NVxuICAgICAgfSxcbiAgICAgIHdpZHRoOiAnYXV0bycsXG4gICAgICBoZWlnaHQ6IDMxMCxcbiAgICAgIHZlcnRpY2FsOiB7XG4gICAgICAgIGxhYmVsczogdHJ1ZSxcbiAgICAgICAgdGl0bGU6IHRydWUsXG4gICAgICAgIGxpbmVzOiB0cnVlLFxuICAgICAgICB0ZXh0VGl0bGU6ICdNZXRyaWNzJ1xuICAgICAgfSxcbiAgICAgIGhvcml6b250YWw6IHtcbiAgICAgICAgdGl0bGU6IHRydWUsXG4gICAgICAgIGxpbmVzOiB0cnVlLFxuICAgICAgICBsYWJlbHM6IHRydWUsXG4gICAgICAgIHRleHRUaXRsZTogJ01ldHJpY3MnXG4gICAgICB9LFxuICAgICAgYm9yZGVyQ29sb3I6ICcjQ0NDQ0NDJyxcbiAgICAgIGJvcmRlcnM6IHRydWUsXG4gICAgICBsZWdlbmQ6IGZhbHNlLFxuICAgICAgbGVnZW5kVGV4dDogWydPcHRpb24gMDEnLCAnT3B0aW9uIDAyJ10sXG4gICAgICBjb2xvcnM6IFsnIzAwMkQ3MicsICcjMDA4Y2U2J11cbiAgICB9O1xuICB9XG5cbiAgbWVyZ2Uoc291cmNlLCB0YXJnZXQpIHtcbiAgICByZXR1cm4gZGVlcG1lcmdlKHNvdXJjZSwgdGFyZ2V0KTtcbiAgfVxuXG4gIGdldCBkYXRhKCkge1xuICAgIHJldHVybiB0aGlzLl9kYXRhO1xuICB9XG5cbiAgc2V0IGRhdGEoZGF0YSkge1xuICAgICAgdGhpcy5fZGF0YSA9IFtdO1xuICAgICAgWydsaW5lcycsICdkb3RzJywgJ2xpbmVzZG90J10uZm9yRWFjaChuYW1lID0+IHRoaXMuY29uY2F0KG5hbWUsIGRhdGEpKTtcbiAgfVxuXG4gIGNvbmNhdChuYW1lLCBkYXRhKXtcbiAgICBpZihkYXRhW25hbWVdKXtcbiAgICAgIGRhdGFbbmFtZV0uZm9yRWFjaChpdGVtID0+IHtcbiAgICAgICAgdGhpcy5fZGF0YSA9IHRoaXMuX2RhdGEuY29uY2F0KGl0ZW0pO1xuICAgICAgfSk7XG4gICAgICB0aGlzWydoYXMnK2NhbWVsaXplKG5hbWUpXSA9IHRydWU7XG4gICAgICB0aGlzW25hbWVdID0gZGF0YVtuYW1lXTtcbiAgICB9ZWxzZSB7XG4gICAgICB0aGlzW25hbWVdID0gW107XG4gICAgfVxuICB9XG5cbiAgcmVuZGVyRWxlbWVudHMoKSB7XG4gICAgY29uc3Qge2xlZ2VuZCwgaG9yaXpvbnRhbCwgdmVydGljYWwsIGJvcmRlcnN9ID0gdGhpcy5jb25maWc7XG4gICAgdGhpcy5jb250YWluZXIoKTtcbiAgICBpZiAodmVydGljYWwubGFiZWxzKSB0aGlzLnZlcnRpY2FsTGFiZWxzKCk7XG4gICAgaWYgKGhvcml6b250YWwubGFiZWxzKSB0aGlzLmhvcml6b250YWxMYWJlbHMoKTtcbiAgICBpZiAoYm9yZGVycykgdGhpcy5ib3JkZXJzKCk7XG4gICAgaWYgKGhvcml6b250YWwubGluZXMpIHRoaXMuaG9yaXpvbnRhbExpbmVzKCk7XG4gICAgaWYgKHZlcnRpY2FsLmxpbmVzKSB0aGlzLnZlcnRpY2FsTGluZXMoKTtcbiAgICBpZiAobGVnZW5kKSB0aGlzLmxlZ2VuZCgpO1xuICB9XG5cbiAgcmVuZGVyKCApIHtcbiAgICB0aGlzLnJlc3BvbnNpdmUoKTtcblxuICAgIHRoaXMuY29vcmRpbmF0ZXMoKTtcbiAgICB0aGlzLmRvbWFpbnMoKTtcbiAgICB0aGlzLmF4aXMoKTtcblxuICAgIHRoaXMucmVuZGVyRWxlbWVudHMoKTtcbiAgICB0aGlzLmdyYXBoaWMoKTtcbiAgICByZXR1cm4gdGhpcztcbiAgfVxuXG4gIHJlc3BvbnNpdmUoKSB7XG4gICAgY29uc3QgcmVuZGVyID0gZGVib3VuY2UoZSA9PiB7XG4gICAgICB0aGlzLmQzLnNlbGVjdCh0aGlzLnN2Zy5ub2RlKCkucGFyZW50Tm9kZSkucmVtb3ZlKCk7XG5cbiAgICAgIHRoaXMuY29vcmRpbmF0ZXMoKTtcbiAgICAgIHRoaXMuZG9tYWlucygpO1xuICAgICAgdGhpcy5heGlzKCk7XG5cbiAgICAgIHRoaXMucmVuZGVyRWxlbWVudHMoKTtcbiAgICAgIHRoaXMuZ3JhcGhpYygpO1xuXG4gICAgfSwgMjAwKTtcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcigncmVzaXplJywgcmVuZGVyKVxuICB9XG5cbiAgZ3JhcGhpYygpIHtcbiAgfVxuXG4gIGxlZ2VuZCgpIHtcbiAgICBjb25zdCBzYW1wbGVDYXRlZ29yaWNhbERhdGEgPSB0aGlzLmNvbmZpZy5sZWdlbmRUZXh0O1xuICAgIGNvbnN0IHNhbXBsZU9yZGluYWwgPSB0aGlzLmQzLnNjYWxlLm9yZGluYWwoKS5kb21haW4oc2FtcGxlQ2F0ZWdvcmljYWxEYXRhKS5yYW5nZSh0aGlzLmNvbmZpZy5jb2xvcnMpO1xuICAgIGNvbnN0IHZlcnRpY2FsTGVnZW5kID0gdGhpcy5kMy5zdmcubGVnZW5kKClcbiAgICAgIC5sYWJlbEZvcm1hdChcIm5vbmVcIilcbiAgICAgIC5jZWxsUGFkZGluZygzKVxuICAgICAgLm9yaWVudGF0aW9uKFwidmVydGljYWxcIilcbiAgICAgIC51bml0cygnJylcbiAgICAgIC5jZWxsV2lkdGgoMTIpXG4gICAgICAuY2VsbEhlaWdodCgxMilcbiAgICAgIC5jZWxsUGFkZGluZyg1KVxuICAgICAgLmlucHV0U2NhbGUoc2FtcGxlT3JkaW5hbCk7XG5cbiAgICB0aGlzLnN2Z1xuICAgICAgLmFwcGVuZChcImdcIilcbiAgICAgIC5kYXRhKHRoaXMuY29uZmlnLmNvbG9ycylcbiAgICAgIC5hdHRyKFwiY2xhc3NcIiwgXCJsZWdlbmRcIilcbiAgICAgIC5hdHRyKCdmb250LXNpemUnLCAnMC42ZW0nKVxuICAgICAgLmF0dHIoXCJ0cmFuc2Zvcm1cIiwgXCJ0cmFuc2xhdGUoXCIgKyAodGhpcy5yZWR1Y2VkV2lkdGgoKSArIDEwKSArIFwiLFwiICsgKDApICsgXCIpXCIpXG4gICAgICAuY2FsbCh2ZXJ0aWNhbExlZ2VuZCk7XG4gIH1cblxuICB4VmFsdWUoKSB7XG4gICAgbGV0IHdpZHRoID0gdGhpcy5yZWR1Y2VkV2lkdGgoKTtcbiAgICB0aGlzLnggPSB0aGlzLmQzLnNjYWxlLm9yZGluYWwoKS5yYW5nZVJvdW5kQmFuZHMoWzAsIHdpZHRoXSk7XG4gIH1cblxuICB5VmFsdWUoKSB7XG4gICAgdGhpcy55ID0gdGhpcy5kMy5zY2FsZS5saW5lYXIoKS5yYW5nZShbdGhpcy5oZWlnaHQsIDBdKTtcbiAgfVxuXG4gIHhBeGlzVmFsdWUoKSB7XG4gICAgdGhpcy54QXhpcyA9IHRoaXMuZDMuc3ZnLmF4aXMoKVxuICAgICAgLnNjYWxlKHRoaXMueClcbiAgICAgIC5vcmllbnQoXCJib3R0b21cIik7XG4gIH1cblxuICB5QXhpc1ZhbHVlKCkge1xuICAgIHRoaXMueUF4aXMgPSB0aGlzLmQzLnN2Zy5heGlzKClcbiAgICAgIC5zY2FsZSh0aGlzLnkpXG4gICAgICAub3JpZW50KFwibGVmdFwiKTtcbiAgfVxuXG4gIGNvb3JkaW5hdGVzKCkge1xuICAgIHRoaXMueFZhbHVlKCk7XG4gICAgdGhpcy55VmFsdWUoKTtcbiAgfVxuXG4gIGRvbWFpbnMoKSB7XG4gICAgdGhpcy54RG9tYWluKCk7XG4gICAgdGhpcy55RG9tYWluKCk7XG4gIH1cblxuICBheGlzKCkge1xuICAgIHRoaXMueEF4aXNWYWx1ZSgpO1xuICAgIHRoaXMueUF4aXNWYWx1ZSgpO1xuICB9XG5cbiAgeERvbWFpbihjYWxsYmFjayA9IGQgPT4gZC5sYWJlbCkge1xuICAgIGNvbnN0IHtkYXRhfSA9IHRoaXM7XG4gICAgdGhpcy54LmRvbWFpbihkYXRhLm1hcChjYWxsYmFjaykpO1xuICB9XG5cbiAgeURvbWFpbihjYWxsYmFjayA9IHRoaXMuY29uZmlnLnlSYW5nZSkge1xuICAgIHRoaXMueS5kb21haW4oWzAsIGNhbGxiYWNrXSk7XG4gIH1cblxuICByZWR1Y2VkV2lkdGgoKXtcbiAgICBpZih0aGlzLmNvbmZpZy5sZWdlbmQpIHtcbiAgICAgIHJldHVybiB0aGlzLndpZHRoIC0gODVcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMud2lkdGhcbiAgfVxuXG4gIGJvcmRlcnMoKSB7XG4gICAgdGhpcy5zdmcuYXBwZW5kKFwicmVjdFwiKVxuICAgICAgLmF0dHIoXCJ4XCIsIDApXG4gICAgICAuYXR0cihcInlcIiwgMClcbiAgICAgIC5hdHRyKFwiaGVpZ2h0XCIsIHRoaXMuaGVpZ2h0KVxuICAgICAgLmF0dHIoXCJ3aWR0aFwiLCB0aGlzLnJlZHVjZWRXaWR0aCgpKVxuICAgICAgLnN0eWxlKFwic3Ryb2tlXCIsIHRoaXMuY29uZmlnLmJvcmRlckNvbG9yKVxuICAgICAgLnN0eWxlKFwiZmlsbFwiLCBcIm5vbmVcIilcbiAgICAgIC5zdHlsZSgnc2hhcGUtcmVuZGVyaW5nJywgJ2NyaXNwRWRnZXMnKVxuICAgICAgLnN0eWxlKFwic3Ryb2tlLXdpZHRoXCIsICcxcHgnKTtcbiAgfVxuXG4gIGhvcml6b250YWxMYWJlbHMoKSB7XG4gICAgY29uc3Qge3RleHRUaXRsZSwgdGl0bGV9ID0gdGhpcy5jb25maWcuaG9yaXpvbnRhbDtcbiAgICAvLyBMYWJlbFxuICAgIHRoaXMuc3ZnLmFwcGVuZCgnZycpXG4gICAgICAuYXR0cignY2xhc3MnLCAneCBheGlzIGxhYmVscycpXG4gICAgICAuYXR0cignZm9udC1zaXplJywgJzAuNmVtJylcbiAgICAgIC5hdHRyKCd0cmFuc2Zvcm0nLCBcInRyYW5zbGF0ZSgwLFwiICsgdGhpcy5oZWlnaHQgKyBcIilcIilcbiAgICAgIC5jYWxsKHRoaXMueEF4aXMpO1xuXG4gICAgaWYgKHRpdGxlKSB7XG4gICAgICB0aGlzLnN2Zy5hcHBlbmQoXCJ0ZXh0XCIpXG4gICAgICAgIC5hdHRyKFwidGV4dC1hbmNob3JcIiwgXCJtaWRkbGVcIilcbiAgICAgICAgLnN0eWxlKFwiZm9udC1zaXplXCIsIFwiMC42ZW1cIilcbiAgICAgICAgLmF0dHIoXCJ0cmFuc2Zvcm1cIiwgXCJ0cmFuc2xhdGUoXCIgKyAodGhpcy5yZWR1Y2VkV2lkdGgoKS8gMikgKyBcIixcIiArICh0aGlzLmhlaWdodCArIDMwKSArIFwiKVwiKVxuICAgICAgICAudGV4dCh0ZXh0VGl0bGUpO1xuICAgIH1cbiAgfVxuXG4gIHZlcnRpY2FsTGFiZWxzKCkge1xuICAgIGNvbnN0IHt2ZXJ0aWNhbCwgbWFyZ2lufSA9IHRoaXMuY29uZmlnO1xuICAgIGNvbnN0IHt0ZXh0VGl0bGUsIHRpdGxlfSA9IHZlcnRpY2FsO1xuXG4gICAgaWYgKHRpdGxlKSB7XG4gICAgICB0aGlzLnN2Zy5hcHBlbmQoXCJ0ZXh0XCIpXG4gICAgICAgIC5hdHRyKFwieVwiLCB0aGlzLmhlaWdodCAvIDIpXG4gICAgICAgIC8vMzAgaXMgdGhlIGdhcFxuICAgICAgICAuYXR0cihcInhcIiwgLW1hcmdpbi5sZWZ0ICsgMjUpXG4gICAgICAgIC5hdHRyKFwiZHlcIiwgXCIxZW1cIilcbiAgICAgICAgLmF0dHIoJ2ZvbnQtc2l6ZScsICcwLjZlbScpXG4gICAgICAgIC5zdHlsZShcInRleHQtYW5jaG9yXCIsIFwibWlkZGxlXCIpXG4gICAgICAgIC50ZXh0KHRleHRUaXRsZSk7XG4gICAgfVxuXG4gICAgLy8gbGFiZWxcbiAgICB0aGlzLnN2Zy5hcHBlbmQoJ2cnKVxuICAgICAgLmF0dHIoJ2NsYXNzJywgJ3kgYXhpcyBsYWJlbHMnKVxuICAgICAgLmF0dHIoJ2ZvbnQtc2l6ZScsICcwLjZlbScpXG4gICAgICAuY2FsbCh0aGlzLnlBeGlzKTtcbiAgfVxuXG5cbiAgaG9yaXpvbnRhbExpbmVzKCkge1xuICAgIGNvbnN0IHlBeGlzR3JpZCA9IHRoaXMuZDMuc3ZnLmF4aXMoKS5zY2FsZSh0aGlzLnkpXG4gICAgICAudGlja1NpemUodGhpcy5yZWR1Y2VkV2lkdGgoKSwgMClcbiAgICAgIC50aWNrRm9ybWF0KFwiXCIpXG4gICAgICAub3JpZW50KFwicmlnaHRcIik7XG5cbiAgICB0aGlzLnN2Zy5hcHBlbmQoXCJnXCIpXG4gICAgICAuY2xhc3NlZCgneScsIHRydWUpXG4gICAgICAuY2xhc3NlZCgnYXhpcycsIHRydWUpXG4gICAgICAuY2FsbCh5QXhpc0dyaWQpO1xuICB9XG5cbiAgdmVydGljYWxMaW5lcygpIHtcbiAgICBjb25zdCB4QXhpc0dyaWQgPSB0aGlzLmQzLnN2Zy5heGlzKCkuc2NhbGUodGhpcy54KVxuICAgICAgLnRpY2tTaXplKHRoaXMuaGVpZ2h0LCAwKVxuICAgICAgLnRpY2tGb3JtYXQoXCJcIilcbiAgICAgIC5vcmllbnQoXCJib3R0b21cIik7XG5cbiAgICB0aGlzLnN2Zy5hcHBlbmQoXCJnXCIpXG4gICAgICAuY2xhc3NlZCgneScsIHRydWUpXG4gICAgICAuY2xhc3NlZCgnYXhpcycsIHRydWUpXG4gICAgICAuY2FsbCh4QXhpc0dyaWQpO1xuICB9XG5cbiAgY29udGFpbmVyKCkge1xuICAgIGNvbnN0IHtkM30gPSB0aGlzO1xuICAgIGNvbnN0IHttYXJnaW4sIGhlaWdodH0gPSB0aGlzLmNvbmZpZztcblxuICAgIHRoaXMuc3ZnID0gZDMuc2VsZWN0KHRoaXMuc2VsZWN0b3IpLmFwcGVuZCgnc3ZnJylcbiAgICAgIC5hdHRyKCd3aWR0aCcsIHRoaXMuZDMuc2VsZWN0KHRoaXMuc2VsZWN0b3IpLm5vZGUoKS5jbGllbnRXaWR0aClcbiAgICAgIC5hdHRyKCdoZWlnaHQnLCBoZWlnaHQpXG4gICAgICAuYXBwZW5kKCdnJylcbiAgICAgIC5hdHRyKCd0cmFuc2Zvcm0nLCBcInRyYW5zbGF0ZShcIiArIG1hcmdpbi5sZWZ0ICsgXCIsXCIgKyBtYXJnaW4udG9wICsgXCIpXCIpO1xuICB9XG5cbiAgZ2V0IGQzKCkge1xuICAgIHJldHVybiBkMztcbiAgfVxuXG4gIGdldCB3aWR0aCgpIHtcbiAgICBsZXQge3dpZHRofSA9IHRoaXMuY29uZmlnO1xuICAgIGNvbnN0IHttYXJnaW59ID0gdGhpcy5jb25maWc7XG4gICAgaWYgKHdpZHRoID09PSAnYXV0bycpIHtcbiAgICAgIHdpZHRoID0gdGhpcy5kMy5zZWxlY3QodGhpcy5zZWxlY3Rvcikubm9kZSgpLmNsaWVudFdpZHRoO1xuICAgIH1cbiAgICByZXR1cm4gd2lkdGggLSBtYXJnaW4ubGVmdCAtIG1hcmdpbi5yaWdodFxuICB9XG5cbiAgZ2V0IGhlaWdodCgpIHtcbiAgICBjb25zdCB7bWFyZ2luLCBoZWlnaHR9ID0gdGhpcy5jb25maWc7XG4gICAgcmV0dXJuIGhlaWdodCAtIG1hcmdpbi50b3AgLSBtYXJnaW4uYm90dG9tXG4gIH1cbn1cblxuXG5leHBvcnQgZGVmYXVsdCBCYXNlXG4iLCJpbXBvcnQgQmFzZSBmcm9tICcuL2Jhc2UnXG5cbmNsYXNzIEJhciBleHRlbmRzIEJhc2Uge1xuICBjb25zdHJ1Y3RvcihkYXRhKSB7XG4gICAgc3VwZXIoZGF0YSk7XG4gICAgdGhpcy5kZWZhdWx0cyA9IHRoaXMubWVyZ2UodGhpcy5kZWZhdWx0cywge1xuICAgICAgeVJhbmdlOiAxMCxcbiAgICAgIHRpcHM6IHRydWUsXG4gICAgICB2ZXJ0aWNhbDoge1xuICAgICAgICBsaW5lczogZmFsc2VcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuXG4gIHJlbmRlckVsZW1lbnRzKCkge1xuICAgIGNvbnN0IHt0aXBzfSA9IHRoaXMuY29uZmlnO1xuICAgIHN1cGVyLnJlbmRlckVsZW1lbnRzKCk7XG4gICAgaWYgKHRpcHMpIHRoaXMudGlwcygpO1xuICB9XG5cbiAgdGlwcygpIHtcbiAgICB0aGlzLnRpcCA9IHRoaXMuZDMudGlwKClcbiAgICAgIC5hdHRyKCdjbGFzcycsICdkMy10aXAnKVxuICAgICAgLm9mZnNldChbLTEwLCAwXSlcbiAgICAgIC5odG1sKGQgPT4gZC52YWx1ZSk7XG4gICAgdGhpcy5zdmcuY2FsbCh0aGlzLnRpcCk7XG4gIH1cbn1cblxuZXhwb3J0IGRlZmF1bHQgQmFyXG4iLCJpbXBvcnQgQmFyIGZyb20gJy4vYmFyJ1xuXG5jbGFzcyBCYXJDaGFydCBleHRlbmRzIEJhciB7XG4gIGNvbnN0cnVjdG9yKGRhdGEpIHtcbiAgICBzdXBlcihkYXRhKTtcbiAgICB0aGlzLmRlZmF1bHRzID0gdGhpcy5tZXJnZSh0aGlzLmRlZmF1bHRzLCB7fSk7XG4gICAgdGhpcy5jb25maWcgPSB0aGlzLm1lcmdlKHRoaXMuZGVmYXVsdHMsIHRoaXMuY29uZmlnKTtcbiAgfVxuXG4gIGdyYXBoaWMoKSB7XG4gICAgdGhpcy5saW5lcy5mb3JFYWNoKGxpbmUgPT4ge1xuICAgICAgdGhpcy5zdmcuc2VsZWN0QWxsKFwiLmJhclwiKVxuICAgICAgICAuZGF0YShsaW5lKVxuICAgICAgICAuZW50ZXIoKS5hcHBlbmQoXCJyZWN0XCIpXG4gICAgICAgIC5hdHRyKFwiY2xhc3NcIiwgXCJiYXJcIilcbiAgICAgICAgLmF0dHIoXCJ4XCIsIGQgPT4gdGhpcy54KGQubGFiZWwpICsgNSlcbiAgICAgICAgLmF0dHIoXCJ3aWR0aFwiLCAxNSlcbiAgICAgICAgLmF0dHIoXCJ5XCIsIGQgPT4gdGhpcy55KGQudmFsdWUgLyAxMDAwMDAwKSlcbiAgICAgICAgLmF0dHIoXCJoZWlnaHRcIiwgZCA9PiB0aGlzLmhlaWdodCAtIHRoaXMueShkLnZhbHVlIC8gMTAwMDAwMCkpXG4gICAgICAgIC5vbignbW91c2VvdmVyJywgdGhpcy50aXAuc2hvdylcbiAgICAgICAgLm9uKCdtb3VzZW91dCcsIHRoaXMudGlwLmhpZGUpO1xuICAgIH0pXG4gIH1cbn1cblxuZXhwb3J0IGRlZmF1bHQgQmFyQ2hhcnRcbiIsImltcG9ydCBCYXNlIGZyb20gJy4vYmFzZSdcblxuY2xhc3MgTGluZSBleHRlbmRzIEJhc2Uge1xuICBjb25zdHJ1Y3RvcihkYXRhKSB7XG4gICAgc3VwZXIoZGF0YSk7XG4gICAgdGhpcy5kZWZhdWx0cyA9IHRoaXMubWVyZ2UodGhpcy5kZWZhdWx0cywge1xuICAgICAgeVJhbmdlOiAxMCxcbiAgICAgIGxlZ2VuZDogdHJ1ZVxuICAgIH0pO1xuICB9XG5cbiAgeFZhbHVlKCkge1xuICAgIGxldCBsZW4gPSB0aGlzLmxpbmVzWzBdLmxlbmd0aCAtIDE7XG4gICAgdGhpcy54ID0gdGhpcy5kMy5zY2FsZS5saW5lYXIoKS5yYW5nZShbMCwgKHRoaXMucmVkdWNlZFdpZHRoKCkgLyBsZW4pXSk7XG4gIH1cblxuICB5VmFsdWUoKSB7XG4gICAgdGhpcy55ID0gdGhpcy5kMy5zY2FsZS5saW5lYXIoKS5yYW5nZShbdGhpcy5oZWlnaHQsIDBdKTtcbiAgfVxufVxuXG5leHBvcnQgZGVmYXVsdCBMaW5lXG4iLCJpbXBvcnQgTGluZSBmcm9tICcuL2xpbmUnXG5cbmNsYXNzIExpbmVDaGFydCBleHRlbmRzIExpbmUge1xuICBjb25zdHJ1Y3RvcihkYXRhKSB7XG4gICAgc3VwZXIoZGF0YSk7XG4gICAgdGhpcy5kZWZhdWx0cyA9IHRoaXMubWVyZ2UodGhpcy5kZWZhdWx0cywge30pO1xuICAgIHRoaXMuY29uZmlnID0gdGhpcy5tZXJnZSh0aGlzLmRlZmF1bHRzLCB0aGlzLmNvbmZpZyk7XG4gIH1cblxuICBncmFwaGljKCkge1xuICAgIHRoaXMubGluZVNlbGVjdGlvbiA9IHRoaXMuZDMuc3ZnLmxpbmUoKVxuICAgICAgLngoZCA9PiB0aGlzLngoZC5sYWJlbCkpXG4gICAgICAueShkID0+IHRoaXMueShkLnZhbHVlKSk7XG5cbiAgICB0aGlzLmxpbmVzLmZvckVhY2goKGxpbmUsIGlkeCkgPT4ge1xuICAgICAgdGhpcy5zdmcuYXBwZW5kKFwic3ZnOnBhdGhcIilcbiAgICAgICAgLmRhdGEobGluZSlcbiAgICAgICAgLmF0dHIoJ2QnLCB0aGlzLmxpbmVTZWxlY3Rpb24obGluZSkpXG4gICAgICAgIC5hdHRyKCdzdHJva2UnLCB0aGlzLmNvbmZpZy5jb2xvcnNbaWR4XSlcbiAgICAgICAgLmF0dHIoJ3N0cm9rZS13aWR0aCcsIDIpXG4gICAgICAgIC5hdHRyKCdmaWxsJywgJ25vbmUnKTtcblxuICAgIH0pO1xuXG4gICAgdGhpcy5saW5lc2RvdC5mb3JFYWNoKChkb3QsIGlkeCkgPT4ge1xuICAgICAgdGhpcy5zdmcuc2VsZWN0QWxsKFwiZG90XCIpXG4gICAgICAgIC5kYXRhKGRvdClcbiAgICAgICAgLmVudGVyKCkuYXBwZW5kKFwiY2lyY2xlXCIpXG4gICAgICAgIC5hdHRyKFwiclwiLCAzLjUpXG4gICAgICAgIC5zdHlsZShcImZpbGxcIiwgdGhpcy5jb25maWcuY29sb3JzW2lkeF0pXG4gICAgICAgIC5hdHRyKFwiY3hcIiwgZCA9PiB0aGlzLngoZC5sYWJlbCkpXG4gICAgICAgIC5hdHRyKFwiY3lcIiwgZCA9PiB0aGlzLnkoZC52YWx1ZSkpO1xuICAgIH0pO1xuICB9XG5cbn1cblxuZXhwb3J0IGRlZmF1bHQgTGluZUNoYXJ0XG4iLCJpbXBvcnQgTGluZSBmcm9tICcuL2xpbmUnXG5cbmNsYXNzIExpbmVEb3RDaGFydCBleHRlbmRzIExpbmUge1xuICBjb25zdHJ1Y3RvcihkYXRhKSB7XG4gICAgc3VwZXIoZGF0YSk7XG4gICAgdGhpcy5kZWZhdWx0cyA9IHRoaXMubWVyZ2UodGhpcy5kZWZhdWx0cywge1xuICAgICAgY29sb3JzOiBbJyMwMDJENzInLCAnIzAwOGNlNicsICcjYzYwMDdlJ10sXG4gICAgICB0ZXh0czogWydPcHRpb24gMScsICdPcHRpb24gMiddXG4gICAgfSk7XG4gICAgdGhpcy5jb25maWcgPSB0aGlzLm1lcmdlKHRoaXMuZGVmYXVsdHMsIHRoaXMuY29uZmlnKTtcbiAgfVxuXG4gIHJlbmRlckVsZW1lbnRzKCkge1xuICAgIHN1cGVyLnJlbmRlckVsZW1lbnRzKCk7XG4gIH1cblxuICBncmFwaGljKCkge1xuICAgIGNvbnN0IHtjb2xvcnN9ID0gdGhpcy5jb25maWdcbiAgICB0aGlzLmxpbmVTZWxlY3Rpb24gPSB0aGlzLmQzLnN2Zy5saW5lKClcbiAgICAgIC54KGQgPT4gdGhpcy54KGQubGFiZWwpKVxuICAgICAgLnkoZCA9PiB0aGlzLnkoZC52YWx1ZSkpO1xuXG4gICAgdGhpcy5saW5lcy5mb3JFYWNoKChsaW5lLCBpZHgpID0+IHtcbiAgICAgIHRoaXMuc3ZnLmFwcGVuZChcInN2ZzpwYXRoXCIpXG4gICAgICAgIC5kYXRhKGxpbmUpXG4gICAgICAgIC5hdHRyKCdkJywgdGhpcy5saW5lU2VsZWN0aW9uKGxpbmUpKVxuICAgICAgICAuYXR0cignc3Ryb2tlJywgdGhpcy5jb25maWcuY29sb3JzW2lkeF0pXG4gICAgICAgIC5hdHRyKCdzdHJva2Utd2lkdGgnLCAyKVxuICAgICAgICAuYXR0cignZmlsbCcsICdub25lJyk7XG4gICAgfSk7XG5cbiAgICB0aGlzLmxpbmVzZG90LmZvckVhY2goKGxpbmVkb3QsIGlkeCkgPT4ge1xuICAgICAgY29uc3Qge2QzfSA9IHRoaXM7XG4gICAgICB0aGlzLnN2Zy5hcHBlbmQoXCJzdmc6cGF0aFwiKVxuICAgICAgICAuZGF0YShsaW5lZG90KVxuICAgICAgICAuYXR0cignZCcsIHRoaXMubGluZVNlbGVjdGlvbihsaW5lZG90KSlcbiAgICAgICAgLmF0dHIoJ3N0cm9rZScsIHRoaXMuY29uZmlnLmNvbG9yc1tpZHhdKVxuICAgICAgICAuYXR0cignc3Ryb2tlLXdpZHRoJywgMilcbiAgICAgICAgLmF0dHIoJ2ZpbGwnLCAnbm9uZScpO1xuICAgICAgdGhpcy5zdmcuc2VsZWN0QWxsKFwiZG90XCIpXG4gICAgICAgIC5kYXRhKGxpbmVkb3QpXG4gICAgICAgIC5lbnRlcigpLmFwcGVuZChcImNpcmNsZVwiKVxuICAgICAgICAuYXR0cihcInJcIiwgNC41KVxuICAgICAgICAuc3R5bGUoXCJmaWxsXCIsICcjZmZmZmZmJylcbiAgICAgICAgLmF0dHIoXCJjeFwiLCBkID0+IHRoaXMueChkLmxhYmVsKSlcbiAgICAgICAgLmF0dHIoXCJjeVwiLCBkID0+IHRoaXMueShkLnZhbHVlKSlcbiAgICAgICAgLmF0dHIoXCJzdHJva2VcIiwgY29sb3JzW2lkeF0pXG4gICAgICAgIC5hdHRyKFwic3Ryb2tlLXdpZHRoXCIsIDIpXG4gICAgICAgIC5vbihcIm1vdXNlb3ZlclwiLCBmdW5jdGlvbigpIHsgZDMuc2VsZWN0KHRoaXMpLnN0eWxlKFwiZmlsbFwiLCBjb2xvcnNbaWR4XSkgfSlcbiAgICAgICAgLm9uKFwibW91c2VvdXRcIiwgZnVuY3Rpb24oKSB7IGQzLnNlbGVjdCh0aGlzKS5zdHlsZSh7XCJmaWxsXCI6ICcjZmZmZmZmJ30pIH0pO1xuICAgIH0pO1xuICB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IExpbmVEb3RDaGFydFxuIiwiaW1wb3J0IExpbmVDaGFydCBmcm9tICcuL2xpbmVjaGFydCdcblxuY2xhc3MgTGluZUZpbGxDaGFydCBleHRlbmRzIExpbmVDaGFydCB7XG4gIGNvbnN0cnVjdG9yKGRhdGEpIHtcbiAgICBzdXBlcihkYXRhKTtcbiAgICB0aGlzLmRlZmF1bHRzID0gdGhpcy5tZXJnZSh0aGlzLmRlZmF1bHRzLCB7fSk7XG4gICAgdGhpcy5jb25maWcgPSB0aGlzLm1lcmdlKHRoaXMuZGVmYXVsdHMsIHRoaXMuY29uZmlnKTtcbiAgfVxuXG4gIGdyYXBoaWMoKSB7XG4gICAgdGhpcy5saW5lU2VsZWN0aW9uID0gdGhpcy5kMy5zdmcubGluZSgpXG4gICAgICAueChkID0+IHRoaXMueChkLmxhYmVsKSlcbiAgICAgIC55KGQgPT4gdGhpcy55KGQudmFsdWUpKTtcblxuICAgIHRoaXMubGluZXMuZm9yRWFjaCgobGluZSwgaWR4KSA9PiB7XG4gICAgICBjb25zdCBhcmVhID0gdGhpcy5kMy5zdmcuYXJlYSgpXG4gICAgICAgIC54KGQgPT4gdGhpcy54KGQubGFiZWwpKVxuICAgICAgICAueTAodGhpcy5oZWlnaHQpXG4gICAgICAgIC55MShkID0+IHRoaXMueShkLnZhbHVlKSk7XG5cbiAgICAgIHRoaXMuc3ZnLmFwcGVuZChcInBhdGhcIilcbiAgICAgICAgLmRhdHVtKGxpbmUpXG4gICAgICAgIC5hdHRyKFwiZmlsbFwiLCB0aGlzLmNvbmZpZy5jb2xvcnNbaWR4XSlcbiAgICAgICAgLmF0dHIoXCJvcGFjaXR5XCIsICcwLjgnKVxuICAgICAgICAuYXR0cihcImRcIiwgYXJlYSk7XG4gICAgfSlcbiAgfVxufVxuXG5leHBvcnQgZGVmYXVsdCBMaW5lRmlsbENoYXJ0XG4iLCJjbGFzcyBVdGlscyB7XG5cbiAgc3RhdGljIHRocm93RGV0YWlsZWQobWVzc2FnZSkge1xuICAgIGxldCBlcnI7XG4gICAgdHJ5IHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignbXlFcnJvcicpO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIGVyciA9IGU7XG4gICAgfVxuICAgIGlmICghZXJyKSByZXR1cm47XG5cbiAgICBsZXQgYXV4ID0gZXJyLnN0YWNrLnNwbGl0KFwiXFxuXCIpO1xuICAgIGF1eC5zcGxpY2UoMCwgMik7IC8vcmVtb3ZpbmcgdGhlIGxpbmUgdGhhdCB3ZSBmb3JjZSB0byBnZW5lcmF0ZSB0aGUgZXJyb3IgKHZhciBlcnIgPSBuZXcgRXJyb3IoKTspIGZyb20gdGhlIG1lc3NhZ2VcbiAgICBhdXggPSBhdXguam9pbignXFxuXCInKTtcbiAgICB0aHJvdyBtZXNzYWdlICsgJyBcXG4nICsgYXV4O1xuICB9XG5cbn1cblxuZXhwb3J0IGRlZmF1bHQgVXRpbHNcbiIsImltcG9ydCBMaW5lIGZyb20gJy4vbGluZSdcblxuY2xhc3MgU2NhdHRlclBvdExpbmVDaGFydCBleHRlbmRzIExpbmUge1xuICBjb25zdHJ1Y3RvcihkYXRhKSB7XG4gICAgc3VwZXIoZGF0YSk7XG4gICAgdGhpcy5kZWZhdWx0cyA9IHRoaXMubWVyZ2UodGhpcy5kZWZhdWx0cywge1xuICAgICAgY29sb3JzOiBbJyMwMDhjZTYnLCAnIzAwMkQ3MicsICcjYzYwMDdlJ10sXG4gICAgICB0ZXh0czogWydPcHRpb24gMScsICdPcHRpb24gMiddLFxuICAgICAgbGVnZW5kOiB0cnVlXG4gICAgfSk7XG4gICAgdGhpcy5jb25maWcgPSB0aGlzLm1lcmdlKHRoaXMuZGVmYXVsdHMsIHRoaXMuY29uZmlnKTtcbiAgfVxuXG4gIHhWYWx1ZSgpIHtcbiAgICBsZXQgbGVuID0gdGhpcy5kb3RzWzBdLmxlbmd0aCAtIDE7XG4gICAgbGV0IGxlbjIgPSB0aGlzLmxpbmVzWzBdLmxlbmd0aCAtIDE7XG4gICAgdGhpcy54ID0gdGhpcy5kMy5zY2FsZS5saW5lYXIoKS5yYW5nZShbMCwgdGhpcy5yZWR1Y2VkV2lkdGgoKSAvIGxlbl0pO1xuICAgIHRoaXMueDIgPSB0aGlzLmQzLnNjYWxlLmxpbmVhcigpLnJhbmdlKFswLCB0aGlzLnJlZHVjZWRXaWR0aCgpIC8gbGVuMl0pO1xuICB9XG5cbiAgZ3JhcGhpYygpIHtcbiAgICB0aGlzLmRvdHMuZm9yRWFjaCgoZG90LCBpZHgpID0+IHtcbiAgICAgIHRoaXMuc3ZnLnNlbGVjdEFsbChcImRvdFwiKVxuICAgICAgICAuZGF0YShkb3QpXG4gICAgICAgIC5lbnRlcigpLmFwcGVuZChcImNpcmNsZVwiKVxuICAgICAgICAuYXR0cihcInJcIiwgMy41KVxuICAgICAgICAuc3R5bGUoXCJmaWxsXCIsIHRoaXMuY29uZmlnLmNvbG9yc1tpZHhdKVxuICAgICAgICAuYXR0cihcImN4XCIsIGQgPT4gdGhpcy54KGQubGFiZWwpKVxuICAgICAgICAuYXR0cihcImN5XCIsIGQgPT4gdGhpcy55KGQudmFsdWUpKTtcbiAgICB9KTtcblxuICAgIHRoaXMubGluZVNlbGVjdGlvbiA9IHRoaXMuZDMuc3ZnLmxpbmUoKVxuICAgICAgLngoZCA9PiB0aGlzLngyKGQubGFiZWwpKVxuICAgICAgLnkoZCA9PiB0aGlzLnkoZC52YWx1ZSkpO1xuXG4gICAgdGhpcy5saW5lcy5mb3JFYWNoKChsaW5lLCBpZHgpID0+IHtcbiAgICAgIHRoaXMuc3ZnLmFwcGVuZChcInN2ZzpwYXRoXCIpXG4gICAgICAgIC5kYXRhKGxpbmUpXG4gICAgICAgIC5hdHRyKCdkJywgdGhpcy5saW5lU2VsZWN0aW9uKGxpbmUpKVxuICAgICAgICAuYXR0cignc3Ryb2tlJywgdGhpcy5jb25maWcuY29sb3JzW2lkeF0pXG4gICAgICAgIC5hdHRyKCdzdHJva2Utd2lkdGgnLCAxKVxuICAgICAgICAuYXR0cigndHJhbnNmb3JtJywgXCJ0cmFuc2xhdGUoLTQsMClcIilcbiAgICAgICAgLmF0dHIoJ2ZpbGwnLCAnbm9uZScpO1xuXG4gICAgfSlcbiAgfVxufVxuXG5leHBvcnQgZGVmYXVsdCBTY2F0dGVyUG90TGluZUNoYXJ0XG4iLCIvLyBpbXBvcnQgQ2FudmFzTGluZUNoYXJ0IGZyb20gJy4vY2FudmFzbGluZSdcbmltcG9ydCBCYXJDaGFydCBmcm9tICcuL2JhcmNoYXJ0J1xuaW1wb3J0IExpbmVDaGFydCBmcm9tICcuL2xpbmVjaGFydCdcbmltcG9ydCBMaW5lRG90Q2hhcnQgZnJvbSAnLi9saW5lZG90Y2hhcnQnXG5pbXBvcnQgTGluZUZpbGxDaGFydCBmcm9tICcuL2xpbmVmaWxsY2hhcnQnXG5pbXBvcnQgVXRpbHMgZnJvbSAnLi4vdXRpbHMvYmFzZSdcbmltcG9ydCBTY2F0dGVyUG90TGluZUNoYXJ0IGZyb20gXCIuL3NjYXR0ZXJwb3RsaW5lY2hhcnRcIjtcblxuY2xhc3MgQ2hhcnQge1xuICBjb25zdHJ1Y3Rvcih7bmFtZSA9ICcnLCBkYXRhID0gW10sIHNlbGVjdG9yID0gJ2JvZHknLCBjb25maWcgPSB7fX0pIHtcbiAgICB0aGlzLm5hbWUgPSBuYW1lO1xuICAgIHRoaXMuZGF0YSA9IGRhdGE7XG4gICAgdGhpcy5zZWxlY3RvciA9IHNlbGVjdG9yO1xuICAgIHRoaXMuY29uZmlnID0gY29uZmlnO1xuICB9XG5cbiAgcmVuZGVyKHtuYW1lID0gdGhpcy5uYW1lLCBkYXRhID0gdGhpcy5kYXRhLCBzZWxlY3RvciA9IHRoaXMuc2VsZWN0b3J9ID0ge30sIGNvbmZpZyA9IHRoaXMuY29uZmlnKSB7XG4gICAgc3dpdGNoIChuYW1lKSB7XG4gICAgICBjYXNlICdCYXInOlxuICAgICAgICByZXR1cm4gbmV3IEJhckNoYXJ0KHtkYXRhLCBzZWxlY3RvciwgY29uZmlnfSkucmVuZGVyKCk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSAnTGluZSc6XG4gICAgICAgIHJldHVybiBuZXcgTGluZUNoYXJ0KHtkYXRhLCBzZWxlY3RvciwgY29uZmlnfSkucmVuZGVyKCk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSAnTGluZURvdCc6XG4gICAgICAgIHJldHVybiBuZXcgTGluZURvdENoYXJ0KHtkYXRhLCBzZWxlY3RvciwgY29uZmlnfSkucmVuZGVyKCk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSAnTGluZUZpbGwnOlxuICAgICAgICByZXR1cm4gbmV3IExpbmVGaWxsQ2hhcnQoe2RhdGEsIHNlbGVjdG9yLCBjb25maWd9KS5yZW5kZXIoKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlICdTY2F0dGVyUG90TGluZSc6XG4gICAgICAgIHJldHVybiBuZXcgU2NhdHRlclBvdExpbmVDaGFydCh7ZGF0YSwgc2VsZWN0b3IsIGNvbmZpZ30pLnJlbmRlcigpO1xuICAgICAgICBicmVhaztcbiAgICAgIC8vIGNhc2UgJ0NhbnZhc0xpbmUnOlxuICAgICAgLy8gICByZXR1cm4gbmV3IENhbnZhc0xpbmVDaGFydChkYXRhLCBzZWxlY3RvcikucmVuZGVyKCk7XG4gICAgICAvLyAgIGJyZWFrO1xuICAgICAgZGVmYXVsdDpcbiAgICAgICAgcmV0dXJuIFV0aWxzLnRocm93RGV0YWlsZWQoXCJUb29sa2l0IHwgQ2hhcnRzIGF2YWlsYWJsZXM6IEJhciwgQ2FudmFzTGluZVwiKTtcbiAgICB9XG4gIH1cblxufVxuXG5leHBvcnQgZGVmYXVsdCBDaGFydFxuIiwiaWYgKCF3aW5kb3cuZDMpIHRocm93IHttZXNzYWdlOiBcIlRvb2xraXQgdXNlcyBodHRwczovL2QzanMub3JnLyBhcyBHcmFwaGljIGxpYnJhcnksIHBsZWFzZSBhZGQgaXRcIn07XG5cbmltcG9ydCBDaGFydCBmcm9tICcuL2NoYXJ0cy9jaGFydCdcblxuY2xhc3MgVG9vbGtpdCB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICB9XG5cbiAgY2hhcnQoe25hbWUgPSAnJywgZGF0YSA9IFtdLCBzZWxlY3RvciA9ICdib2R5JywgY29uZmlnID0ge319KSB7XG4gICAgcmV0dXJuIG5ldyBDaGFydCh7bmFtZSwgZGF0YSwgc2VsZWN0b3IsIGNvbmZpZ30pO1xuICB9XG5cbn1cblxuZXhwb3J0IGRlZmF1bHQgbmV3IFRvb2xraXQoKTtcbiJdLCJuYW1lcyI6WyJkMyIsIndpbmRvdyIsImNhbWVsaXplIiwidGV4dCIsInNlcGFyYXRvciIsIndvcmRzIiwic3BsaXQiLCJyZXN1bHQiLCJpIiwibGVuZ3RoIiwid29yZCIsImNhcGl0YWxpemVkV29yZCIsImNoYXJBdCIsInRvVXBwZXJDYXNlIiwic2xpY2UiLCJpc01lcmdlYWJsZU9iamVjdCIsInZhbCIsIm5vbk51bGxPYmplY3QiLCJPYmplY3QiLCJwcm90b3R5cGUiLCJ0b1N0cmluZyIsImNhbGwiLCJlbXB0eVRhcmdldCIsIkFycmF5IiwiaXNBcnJheSIsImNsb25lSWZOZWNlc3NhcnkiLCJ2YWx1ZSIsIm9wdGlvbnNBcmd1bWVudCIsImNsb25lIiwiZGVlcG1lcmdlIiwiZGVmYXVsdEFycmF5TWVyZ2UiLCJ0YXJnZXQiLCJzb3VyY2UiLCJkZXN0aW5hdGlvbiIsImZvckVhY2giLCJlIiwiaW5kZXhPZiIsInB1c2giLCJtZXJnZU9iamVjdCIsImtleXMiLCJrZXkiLCJhcnJheSIsIm9wdGlvbnMiLCJhcnJheU1lcmdlIiwiYWxsIiwiZGVlcG1lcmdlQWxsIiwiRXJyb3IiLCJyZWR1Y2UiLCJwcmV2IiwibmV4dCIsImRlYm91bmNlIiwiY2FsbGJhY2siLCJ3YWl0IiwiY29udGV4dCIsInRpbWVvdXQiLCJjYWxsYmFja0FyZ3MiLCJsYXRlciIsImFwcGx5IiwiYXJndW1lbnRzIiwic2V0VGltZW91dCIsIkJhc2UiLCJkYXRhIiwic2VsZWN0b3IiLCJjb25maWciLCJkZWZhdWx0cyIsIm5hbWUiLCJfZGF0YSIsImNvbmNhdCIsIml0ZW0iLCJsZWdlbmQiLCJob3Jpem9udGFsIiwidmVydGljYWwiLCJib3JkZXJzIiwiY29udGFpbmVyIiwibGFiZWxzIiwidmVydGljYWxMYWJlbHMiLCJob3Jpem9udGFsTGFiZWxzIiwibGluZXMiLCJob3Jpem9udGFsTGluZXMiLCJ2ZXJ0aWNhbExpbmVzIiwicmVzcG9uc2l2ZSIsImNvb3JkaW5hdGVzIiwiZG9tYWlucyIsImF4aXMiLCJyZW5kZXJFbGVtZW50cyIsImdyYXBoaWMiLCJyZW5kZXIiLCJzZWxlY3QiLCJzdmciLCJub2RlIiwicGFyZW50Tm9kZSIsInJlbW92ZSIsImFkZEV2ZW50TGlzdGVuZXIiLCJzYW1wbGVDYXRlZ29yaWNhbERhdGEiLCJsZWdlbmRUZXh0Iiwic2FtcGxlT3JkaW5hbCIsInNjYWxlIiwib3JkaW5hbCIsImRvbWFpbiIsInJhbmdlIiwiY29sb3JzIiwidmVydGljYWxMZWdlbmQiLCJsYWJlbEZvcm1hdCIsImNlbGxQYWRkaW5nIiwib3JpZW50YXRpb24iLCJ1bml0cyIsImNlbGxXaWR0aCIsImNlbGxIZWlnaHQiLCJpbnB1dFNjYWxlIiwiYXBwZW5kIiwiYXR0ciIsInJlZHVjZWRXaWR0aCIsIndpZHRoIiwieCIsInJhbmdlUm91bmRCYW5kcyIsInkiLCJsaW5lYXIiLCJoZWlnaHQiLCJ4QXhpcyIsIm9yaWVudCIsInlBeGlzIiwieFZhbHVlIiwieVZhbHVlIiwieERvbWFpbiIsInlEb21haW4iLCJ4QXhpc1ZhbHVlIiwieUF4aXNWYWx1ZSIsImQiLCJsYWJlbCIsIm1hcCIsInlSYW5nZSIsInN0eWxlIiwiYm9yZGVyQ29sb3IiLCJ0ZXh0VGl0bGUiLCJ0aXRsZSIsIm1hcmdpbiIsImxlZnQiLCJ5QXhpc0dyaWQiLCJ0aWNrU2l6ZSIsInRpY2tGb3JtYXQiLCJjbGFzc2VkIiwieEF4aXNHcmlkIiwiY2xpZW50V2lkdGgiLCJ0b3AiLCJyaWdodCIsImJvdHRvbSIsIkJhciIsIm1lcmdlIiwidGlwcyIsInRpcCIsIm9mZnNldCIsImh0bWwiLCJCYXJDaGFydCIsInNlbGVjdEFsbCIsImxpbmUiLCJlbnRlciIsIm9uIiwic2hvdyIsImhpZGUiLCJMaW5lIiwibGVuIiwiTGluZUNoYXJ0IiwibGluZVNlbGVjdGlvbiIsImlkeCIsImxpbmVzZG90IiwiZG90IiwiTGluZURvdENoYXJ0IiwibGluZWRvdCIsIkxpbmVGaWxsQ2hhcnQiLCJhcmVhIiwieTAiLCJ5MSIsImRhdHVtIiwiVXRpbHMiLCJtZXNzYWdlIiwiZXJyIiwiYXV4Iiwic3RhY2siLCJzcGxpY2UiLCJqb2luIiwiU2NhdHRlclBvdExpbmVDaGFydCIsImRvdHMiLCJsZW4yIiwieDIiLCJDaGFydCIsInRocm93RGV0YWlsZWQiLCJUb29sa2l0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFNQSxLQUFLQyxPQUFPRCxFQUFsQjtBQUNBLFNBQVNFLFFBQVQsQ0FBa0JDLElBQWxCLEVBQXdCQyxTQUF4QixFQUFtQzs7O01BRzlCLE9BQU9BLFNBQVAsS0FBc0IsV0FBekIsRUFBc0M7Z0JBQ3hCLEdBQVo7Ozs7TUFJRUMsUUFBUUYsS0FBS0csS0FBTCxDQUFXRixTQUFYLENBQVo7OztNQUdJRyxTQUFTLEVBQWI7T0FDSyxJQUFJQyxJQUFJLENBQWIsRUFBaUJBLElBQUlILE1BQU1JLE1BQTNCLEVBQW9DRCxHQUFwQyxFQUF5QztRQUNuQ0UsT0FBT0wsTUFBTUcsQ0FBTixDQUFYO1FBQ0lHLGtCQUFrQkQsS0FBS0UsTUFBTCxDQUFZLENBQVosRUFBZUMsV0FBZixLQUErQkgsS0FBS0ksS0FBTCxDQUFXLENBQVgsQ0FBckQ7Y0FDVUgsZUFBVjs7O1NBR0tKLE1BQVA7OztBQUdGLFNBQVNRLGlCQUFULENBQTJCQyxHQUEzQixFQUFnQztNQUMxQkMsZ0JBQWdCRCxPQUFPLFFBQU9BLEdBQVAseUNBQU9BLEdBQVAsT0FBZSxRQUExQzs7U0FFT0MsaUJBQ0ZDLE9BQU9DLFNBQVAsQ0FBaUJDLFFBQWpCLENBQTBCQyxJQUExQixDQUErQkwsR0FBL0IsTUFBd0MsaUJBRHRDLElBRUZFLE9BQU9DLFNBQVAsQ0FBaUJDLFFBQWpCLENBQTBCQyxJQUExQixDQUErQkwsR0FBL0IsTUFBd0MsZUFGN0M7OztBQUtGLFNBQVNNLFdBQVQsQ0FBcUJOLEdBQXJCLEVBQTBCO1NBQ2pCTyxNQUFNQyxPQUFOLENBQWNSLEdBQWQsSUFBcUIsRUFBckIsR0FBMEIsRUFBakM7OztBQUdGLFNBQVNTLGdCQUFULENBQTBCQyxLQUExQixFQUFpQ0MsZUFBakMsRUFBa0Q7TUFDNUNDLFFBQVFELG1CQUFtQkEsZ0JBQWdCQyxLQUFoQixLQUEwQixJQUF6RDtTQUNRQSxTQUFTYixrQkFBa0JXLEtBQWxCLENBQVYsR0FBc0NHLFVBQVVQLFlBQVlJLEtBQVosQ0FBVixFQUE4QkEsS0FBOUIsRUFBcUNDLGVBQXJDLENBQXRDLEdBQThGRCxLQUFyRzs7O0FBR0YsU0FBU0ksaUJBQVQsQ0FBMkJDLE1BQTNCLEVBQW1DQyxNQUFuQyxFQUEyQ0wsZUFBM0MsRUFBNEQ7TUFDdERNLGNBQWNGLE9BQU9qQixLQUFQLEVBQWxCO1NBQ09vQixPQUFQLENBQWUsVUFBVUMsQ0FBVixFQUFhM0IsQ0FBYixFQUFnQjtRQUN6QixPQUFPeUIsWUFBWXpCLENBQVosQ0FBUCxLQUEwQixXQUE5QixFQUEyQztrQkFDN0JBLENBQVosSUFBaUJpQixpQkFBaUJVLENBQWpCLEVBQW9CUixlQUFwQixDQUFqQjtLQURGLE1BRU8sSUFBSVosa0JBQWtCb0IsQ0FBbEIsQ0FBSixFQUEwQjtrQkFDbkIzQixDQUFaLElBQWlCcUIsVUFBVUUsT0FBT3ZCLENBQVAsQ0FBVixFQUFxQjJCLENBQXJCLEVBQXdCUixlQUF4QixDQUFqQjtLQURLLE1BRUEsSUFBSUksT0FBT0ssT0FBUCxDQUFlRCxDQUFmLE1BQXNCLENBQUMsQ0FBM0IsRUFBOEI7a0JBQ3ZCRSxJQUFaLENBQWlCWixpQkFBaUJVLENBQWpCLEVBQW9CUixlQUFwQixDQUFqQjs7R0FOSjtTQVNPTSxXQUFQOzs7QUFHRixTQUFTSyxXQUFULENBQXFCUCxNQUFyQixFQUE2QkMsTUFBN0IsRUFBcUNMLGVBQXJDLEVBQXNEO01BQ2hETSxjQUFjLEVBQWxCO01BQ0lsQixrQkFBa0JnQixNQUFsQixDQUFKLEVBQStCO1dBQ3RCUSxJQUFQLENBQVlSLE1BQVosRUFBb0JHLE9BQXBCLENBQTRCLFVBQVVNLEdBQVYsRUFBZTtrQkFDN0JBLEdBQVosSUFBbUJmLGlCQUFpQk0sT0FBT1MsR0FBUCxDQUFqQixFQUE4QmIsZUFBOUIsQ0FBbkI7S0FERjs7U0FJS1ksSUFBUCxDQUFZUCxNQUFaLEVBQW9CRSxPQUFwQixDQUE0QixVQUFVTSxHQUFWLEVBQWU7UUFDckMsQ0FBQ3pCLGtCQUFrQmlCLE9BQU9RLEdBQVAsQ0FBbEIsQ0FBRCxJQUFtQyxDQUFDVCxPQUFPUyxHQUFQLENBQXhDLEVBQXFEO2tCQUN2Q0EsR0FBWixJQUFtQmYsaUJBQWlCTyxPQUFPUSxHQUFQLENBQWpCLEVBQThCYixlQUE5QixDQUFuQjtLQURGLE1BRU87a0JBQ09hLEdBQVosSUFBbUJYLFVBQVVFLE9BQU9TLEdBQVAsQ0FBVixFQUF1QlIsT0FBT1EsR0FBUCxDQUF2QixFQUFvQ2IsZUFBcEMsQ0FBbkI7O0dBSko7U0FPT00sV0FBUDs7O0FBR0YsU0FBU0osU0FBVCxDQUFtQkUsTUFBbkIsRUFBMkJDLE1BQTNCLEVBQW1DTCxlQUFuQyxFQUFvRDtNQUM5Q2MsUUFBUWxCLE1BQU1DLE9BQU4sQ0FBY1EsTUFBZCxDQUFaO01BQ0lVLFVBQVVmLG1CQUFtQixFQUFDZ0IsWUFBWWIsaUJBQWIsRUFBakM7TUFDSWEsYUFBYUQsUUFBUUMsVUFBUixJQUFzQmIsaUJBQXZDOztNQUVJVyxLQUFKLEVBQVc7V0FDRmxCLE1BQU1DLE9BQU4sQ0FBY08sTUFBZCxJQUF3QlksV0FBV1osTUFBWCxFQUFtQkMsTUFBbkIsRUFBMkJMLGVBQTNCLENBQXhCLEdBQXNFRixpQkFBaUJPLE1BQWpCLEVBQXlCTCxlQUF6QixDQUE3RTtHQURGLE1BRU87V0FDRVcsWUFBWVAsTUFBWixFQUFvQkMsTUFBcEIsRUFBNEJMLGVBQTVCLENBQVA7Ozs7QUFJSkUsVUFBVWUsR0FBVixHQUFnQixTQUFTQyxZQUFULENBQXNCSixLQUF0QixFQUE2QmQsZUFBN0IsRUFBOEM7TUFDeEQsQ0FBQ0osTUFBTUMsT0FBTixDQUFjaUIsS0FBZCxDQUFELElBQXlCQSxNQUFNaEMsTUFBTixHQUFlLENBQTVDLEVBQStDO1VBQ3ZDLElBQUlxQyxLQUFKLENBQVUsOERBQVYsQ0FBTjs7OztTQUlLTCxNQUFNTSxNQUFOLENBQWEsVUFBVUMsSUFBVixFQUFnQkMsSUFBaEIsRUFBc0I7V0FDakNwQixVQUFVbUIsSUFBVixFQUFnQkMsSUFBaEIsRUFBc0J0QixlQUF0QixDQUFQO0dBREssQ0FBUDtDQU5GOztBQVdBLFNBQVN1QixRQUFULENBQWtCQyxRQUFsQixFQUE0QkMsSUFBNUIsRUFBa0Q7TUFBaEJDLE9BQWdCLHVFQUFOLElBQU07O01BQzVDQyxVQUFVLElBQWQ7TUFDSUMsZUFBZSxJQUFuQjs7TUFFTUMsUUFBUSxTQUFSQSxLQUFRO1dBQU1MLFNBQVNNLEtBQVQsQ0FBZUosT0FBZixFQUF3QkUsWUFBeEIsQ0FBTjtHQUFkOztTQUVPLFlBQVc7bUJBQ0RHLFNBQWY7aUJBQ2FKLE9BQWI7Y0FDVUssV0FBV0gsS0FBWCxFQUFrQkosSUFBbEIsQ0FBVjtHQUhGOzs7SUFPSVE7c0JBQ3FEO3lCQUE1Q0MsSUFBNEM7UUFBNUNBLElBQTRDLDZCQUFyQyxFQUFxQzs2QkFBakNDLFFBQWlDO1FBQWpDQSxRQUFpQyxpQ0FBdEIsTUFBc0I7MkJBQWRDLE1BQWM7UUFBZEEsTUFBYywrQkFBTCxFQUFLOzs7U0FDbERGLElBQUwsR0FBWUEsSUFBWjtTQUNLQyxRQUFMLEdBQWdCQSxRQUFoQjtTQUNLQyxNQUFMLEdBQWNBLE1BQWQ7U0FDS0MsUUFBTCxHQUFnQjtjQUNOO2FBQ0QsRUFEQztlQUVDLEVBRkQ7Z0JBR0UsRUFIRjtjQUlBO09BTE07YUFPUCxNQVBPO2NBUU4sR0FSTTtnQkFTSjtnQkFDQSxJQURBO2VBRUQsSUFGQztlQUdELElBSEM7bUJBSUc7T0FiQztrQkFlRjtlQUNILElBREc7ZUFFSCxJQUZHO2dCQUdGLElBSEU7bUJBSUM7T0FuQkM7bUJBcUJELFNBckJDO2VBc0JMLElBdEJLO2NBdUJOLEtBdkJNO2tCQXdCRixDQUFDLFdBQUQsRUFBYyxXQUFkLENBeEJFO2NBeUJOLENBQUMsU0FBRCxFQUFZLFNBQVo7S0F6QlY7Ozs7OzBCQTZCSWhDLFFBQVFELFFBQVE7YUFDYkYsVUFBVUcsTUFBVixFQUFrQkQsTUFBbEIsQ0FBUDs7OzsyQkFZS2tDLE1BQU1KLE1BQUs7OztVQUNiQSxLQUFLSSxJQUFMLENBQUgsRUFBYzthQUNQQSxJQUFMLEVBQVcvQixPQUFYLENBQW1CLGdCQUFRO2dCQUNwQmdDLEtBQUwsR0FBYSxNQUFLQSxLQUFMLENBQVdDLE1BQVgsQ0FBa0JDLElBQWxCLENBQWI7U0FERjthQUdLLFFBQU1sRSxTQUFTK0QsSUFBVCxDQUFYLElBQTZCLElBQTdCO2FBQ0tBLElBQUwsSUFBYUosS0FBS0ksSUFBTCxDQUFiO09BTEYsTUFNTTthQUNDQSxJQUFMLElBQWEsRUFBYjs7Ozs7cUNBSWE7b0JBQ2lDLEtBQUtGLE1BRHRDO1VBQ1JNLE1BRFEsV0FDUkEsTUFEUTtVQUNBQyxVQURBLFdBQ0FBLFVBREE7VUFDWUMsUUFEWixXQUNZQSxRQURaO1VBQ3NCQyxPQUR0QixXQUNzQkEsT0FEdEI7O1dBRVZDLFNBQUw7VUFDSUYsU0FBU0csTUFBYixFQUFxQixLQUFLQyxjQUFMO1VBQ2pCTCxXQUFXSSxNQUFmLEVBQXVCLEtBQUtFLGdCQUFMO1VBQ25CSixPQUFKLEVBQWEsS0FBS0EsT0FBTDtVQUNURixXQUFXTyxLQUFmLEVBQXNCLEtBQUtDLGVBQUw7VUFDbEJQLFNBQVNNLEtBQWIsRUFBb0IsS0FBS0UsYUFBTDtVQUNoQlYsTUFBSixFQUFZLEtBQUtBLE1BQUw7Ozs7NkJBR0o7V0FDSFcsVUFBTDs7V0FFS0MsV0FBTDtXQUNLQyxPQUFMO1dBQ0tDLElBQUw7O1dBRUtDLGNBQUw7V0FDS0MsT0FBTDthQUNPLElBQVA7Ozs7aUNBR1c7OztVQUNMQyxTQUFTcEMsU0FBUyxhQUFLO2VBQ3RCbEQsRUFBTCxDQUFRdUYsTUFBUixDQUFlLE9BQUtDLEdBQUwsQ0FBU0MsSUFBVCxHQUFnQkMsVUFBL0IsRUFBMkNDLE1BQTNDOztlQUVLVixXQUFMO2VBQ0tDLE9BQUw7ZUFDS0MsSUFBTDs7ZUFFS0MsY0FBTDtlQUNLQyxPQUFMO09BUmEsRUFVWixHQVZZLENBQWY7YUFXT08sZ0JBQVAsQ0FBd0IsUUFBeEIsRUFBa0NOLE1BQWxDOzs7OzhCQUdROzs7NkJBR0Q7VUFDRE8sd0JBQXdCLEtBQUs5QixNQUFMLENBQVkrQixVQUExQztVQUNNQyxnQkFBZ0IsS0FBSy9GLEVBQUwsQ0FBUWdHLEtBQVIsQ0FBY0MsT0FBZCxHQUF3QkMsTUFBeEIsQ0FBK0JMLHFCQUEvQixFQUFzRE0sS0FBdEQsQ0FBNEQsS0FBS3BDLE1BQUwsQ0FBWXFDLE1BQXhFLENBQXRCO1VBQ01DLGlCQUFpQixLQUFLckcsRUFBTCxDQUFRd0YsR0FBUixDQUFZbkIsTUFBWixHQUNwQmlDLFdBRG9CLENBQ1IsTUFEUSxFQUVwQkMsV0FGb0IsQ0FFUixDQUZRLEVBR3BCQyxXQUhvQixDQUdSLFVBSFEsRUFJcEJDLEtBSm9CLENBSWQsRUFKYyxFQUtwQkMsU0FMb0IsQ0FLVixFQUxVLEVBTXBCQyxVQU5vQixDQU1ULEVBTlMsRUFPcEJKLFdBUG9CLENBT1IsQ0FQUSxFQVFwQkssVUFSb0IsQ0FRVGIsYUFSUyxDQUF2Qjs7V0FVS1AsR0FBTCxDQUNHcUIsTUFESCxDQUNVLEdBRFYsRUFFR2hELElBRkgsQ0FFUSxLQUFLRSxNQUFMLENBQVlxQyxNQUZwQixFQUdHVSxJQUhILENBR1EsT0FIUixFQUdpQixRQUhqQixFQUlHQSxJQUpILENBSVEsV0FKUixFQUlxQixPQUpyQixFQUtHQSxJQUxILENBS1EsV0FMUixFQUtxQixnQkFBZ0IsS0FBS0MsWUFBTCxLQUFzQixFQUF0QyxJQUE0QyxHQUE1QyxHQUFtRCxDQUFuRCxHQUF3RCxHQUw3RSxFQU1HMUYsSUFOSCxDQU1RZ0YsY0FOUjs7Ozs2QkFTTztVQUNIVyxRQUFRLEtBQUtELFlBQUwsRUFBWjtXQUNLRSxDQUFMLEdBQVMsS0FBS2pILEVBQUwsQ0FBUWdHLEtBQVIsQ0FBY0MsT0FBZCxHQUF3QmlCLGVBQXhCLENBQXdDLENBQUMsQ0FBRCxFQUFJRixLQUFKLENBQXhDLENBQVQ7Ozs7NkJBR087V0FDRkcsQ0FBTCxHQUFTLEtBQUtuSCxFQUFMLENBQVFnRyxLQUFSLENBQWNvQixNQUFkLEdBQXVCakIsS0FBdkIsQ0FBNkIsQ0FBQyxLQUFLa0IsTUFBTixFQUFjLENBQWQsQ0FBN0IsQ0FBVDs7OztpQ0FHVztXQUNOQyxLQUFMLEdBQWEsS0FBS3RILEVBQUwsQ0FBUXdGLEdBQVIsQ0FBWUwsSUFBWixHQUNWYSxLQURVLENBQ0osS0FBS2lCLENBREQsRUFFVk0sTUFGVSxDQUVILFFBRkcsQ0FBYjs7OztpQ0FLVztXQUNOQyxLQUFMLEdBQWEsS0FBS3hILEVBQUwsQ0FBUXdGLEdBQVIsQ0FBWUwsSUFBWixHQUNWYSxLQURVLENBQ0osS0FBS21CLENBREQsRUFFVkksTUFGVSxDQUVILE1BRkcsQ0FBYjs7OztrQ0FLWTtXQUNQRSxNQUFMO1dBQ0tDLE1BQUw7Ozs7OEJBR1E7V0FDSEMsT0FBTDtXQUNLQyxPQUFMOzs7OzJCQUdLO1dBQ0FDLFVBQUw7V0FDS0MsVUFBTDs7Ozs4QkFHK0I7VUFBekIzRSxRQUF5Qix1RUFBZDtlQUFLNEUsRUFBRUMsS0FBUDtPQUFjO1VBQ3hCbkUsSUFEd0IsR0FDaEIsSUFEZ0IsQ0FDeEJBLElBRHdCOztXQUUxQm9ELENBQUwsQ0FBT2YsTUFBUCxDQUFjckMsS0FBS29FLEdBQUwsQ0FBUzlFLFFBQVQsQ0FBZDs7Ozs4QkFHcUM7VUFBL0JBLFFBQStCLHVFQUFwQixLQUFLWSxNQUFMLENBQVltRSxNQUFROztXQUNoQ2YsQ0FBTCxDQUFPakIsTUFBUCxDQUFjLENBQUMsQ0FBRCxFQUFJL0MsUUFBSixDQUFkOzs7O21DQUdZO1VBQ1QsS0FBS1ksTUFBTCxDQUFZTSxNQUFmLEVBQXVCO2VBQ2QsS0FBSzJDLEtBQUwsR0FBYSxFQUFwQjs7YUFFSyxLQUFLQSxLQUFaOzs7OzhCQUdRO1dBQ0h4QixHQUFMLENBQVNxQixNQUFULENBQWdCLE1BQWhCLEVBQ0dDLElBREgsQ0FDUSxHQURSLEVBQ2EsQ0FEYixFQUVHQSxJQUZILENBRVEsR0FGUixFQUVhLENBRmIsRUFHR0EsSUFISCxDQUdRLFFBSFIsRUFHa0IsS0FBS08sTUFIdkIsRUFJR1AsSUFKSCxDQUlRLE9BSlIsRUFJaUIsS0FBS0MsWUFBTCxFQUpqQixFQUtHb0IsS0FMSCxDQUtTLFFBTFQsRUFLbUIsS0FBS3BFLE1BQUwsQ0FBWXFFLFdBTC9CLEVBTUdELEtBTkgsQ0FNUyxNQU5ULEVBTWlCLE1BTmpCLEVBT0dBLEtBUEgsQ0FPUyxpQkFQVCxFQU80QixZQVA1QixFQVFHQSxLQVJILENBUVMsY0FSVCxFQVF5QixLQVJ6Qjs7Ozt1Q0FXaUI7K0JBQ1UsS0FBS3BFLE1BQUwsQ0FBWU8sVUFEdEI7VUFDVitELFNBRFUsc0JBQ1ZBLFNBRFU7VUFDQ0MsS0FERCxzQkFDQ0EsS0FERDs7O1dBR1o5QyxHQUFMLENBQVNxQixNQUFULENBQWdCLEdBQWhCLEVBQ0dDLElBREgsQ0FDUSxPQURSLEVBQ2lCLGVBRGpCLEVBRUdBLElBRkgsQ0FFUSxXQUZSLEVBRXFCLE9BRnJCLEVBR0dBLElBSEgsQ0FHUSxXQUhSLEVBR3FCLGlCQUFpQixLQUFLTyxNQUF0QixHQUErQixHQUhwRCxFQUlHaEcsSUFKSCxDQUlRLEtBQUtpRyxLQUpiOztVQU1JZ0IsS0FBSixFQUFXO2FBQ0o5QyxHQUFMLENBQVNxQixNQUFULENBQWdCLE1BQWhCLEVBQ0dDLElBREgsQ0FDUSxhQURSLEVBQ3VCLFFBRHZCLEVBRUdxQixLQUZILENBRVMsV0FGVCxFQUVzQixPQUZ0QixFQUdHckIsSUFISCxDQUdRLFdBSFIsRUFHcUIsZUFBZ0IsS0FBS0MsWUFBTCxLQUFxQixDQUFyQyxHQUEwQyxHQUExQyxJQUFpRCxLQUFLTSxNQUFMLEdBQWMsRUFBL0QsSUFBcUUsR0FIMUYsRUFJR2xILElBSkgsQ0FJUWtJLFNBSlI7Ozs7O3FDQVFhO3FCQUNZLEtBQUt0RSxNQURqQjtVQUNSUSxRQURRLFlBQ1JBLFFBRFE7VUFDRWdFLE1BREYsWUFDRUEsTUFERjtVQUVSRixTQUZRLEdBRVk5RCxRQUZaLENBRVI4RCxTQUZRO1VBRUdDLEtBRkgsR0FFWS9ELFFBRlosQ0FFRytELEtBRkg7OztVQUlYQSxLQUFKLEVBQVc7YUFDSjlDLEdBQUwsQ0FBU3FCLE1BQVQsQ0FBZ0IsTUFBaEIsRUFDR0MsSUFESCxDQUNRLEdBRFIsRUFDYSxLQUFLTyxNQUFMLEdBQWMsQ0FEM0I7O1NBR0dQLElBSEgsQ0FHUSxHQUhSLEVBR2EsQ0FBQ3lCLE9BQU9DLElBQVIsR0FBZSxFQUg1QixFQUlHMUIsSUFKSCxDQUlRLElBSlIsRUFJYyxLQUpkLEVBS0dBLElBTEgsQ0FLUSxXQUxSLEVBS3FCLE9BTHJCLEVBTUdxQixLQU5ILENBTVMsYUFOVCxFQU13QixRQU54QixFQU9HaEksSUFQSCxDQU9Ra0ksU0FQUjs7OztXQVdHN0MsR0FBTCxDQUFTcUIsTUFBVCxDQUFnQixHQUFoQixFQUNHQyxJQURILENBQ1EsT0FEUixFQUNpQixlQURqQixFQUVHQSxJQUZILENBRVEsV0FGUixFQUVxQixPQUZyQixFQUdHekYsSUFISCxDQUdRLEtBQUttRyxLQUhiOzs7O3NDQU9nQjtVQUNWaUIsWUFBWSxLQUFLekksRUFBTCxDQUFRd0YsR0FBUixDQUFZTCxJQUFaLEdBQW1CYSxLQUFuQixDQUF5QixLQUFLbUIsQ0FBOUIsRUFDZnVCLFFBRGUsQ0FDTixLQUFLM0IsWUFBTCxFQURNLEVBQ2UsQ0FEZixFQUVmNEIsVUFGZSxDQUVKLEVBRkksRUFHZnBCLE1BSGUsQ0FHUixPQUhRLENBQWxCOztXQUtLL0IsR0FBTCxDQUFTcUIsTUFBVCxDQUFnQixHQUFoQixFQUNHK0IsT0FESCxDQUNXLEdBRFgsRUFDZ0IsSUFEaEIsRUFFR0EsT0FGSCxDQUVXLE1BRlgsRUFFbUIsSUFGbkIsRUFHR3ZILElBSEgsQ0FHUW9ILFNBSFI7Ozs7b0NBTWM7VUFDUkksWUFBWSxLQUFLN0ksRUFBTCxDQUFRd0YsR0FBUixDQUFZTCxJQUFaLEdBQW1CYSxLQUFuQixDQUF5QixLQUFLaUIsQ0FBOUIsRUFDZnlCLFFBRGUsQ0FDTixLQUFLckIsTUFEQyxFQUNPLENBRFAsRUFFZnNCLFVBRmUsQ0FFSixFQUZJLEVBR2ZwQixNQUhlLENBR1IsUUFIUSxDQUFsQjs7V0FLSy9CLEdBQUwsQ0FBU3FCLE1BQVQsQ0FBZ0IsR0FBaEIsRUFDRytCLE9BREgsQ0FDVyxHQURYLEVBQ2dCLElBRGhCLEVBRUdBLE9BRkgsQ0FFVyxNQUZYLEVBRW1CLElBRm5CLEVBR0d2SCxJQUhILENBR1F3SCxTQUhSOzs7O2dDQU1VO1VBQ0g3SSxFQURHLEdBQ0csSUFESCxDQUNIQSxFQURHO3FCQUVlLEtBQUsrRCxNQUZwQjtVQUVId0UsTUFGRyxZQUVIQSxNQUZHO1VBRUtsQixNQUZMLFlBRUtBLE1BRkw7OztXQUlMN0IsR0FBTCxHQUFXeEYsR0FBR3VGLE1BQUgsQ0FBVSxLQUFLekIsUUFBZixFQUF5QitDLE1BQXpCLENBQWdDLEtBQWhDLEVBQ1JDLElBRFEsQ0FDSCxPQURHLEVBQ00sS0FBSzlHLEVBQUwsQ0FBUXVGLE1BQVIsQ0FBZSxLQUFLekIsUUFBcEIsRUFBOEIyQixJQUE5QixHQUFxQ3FELFdBRDNDLEVBRVJoQyxJQUZRLENBRUgsUUFGRyxFQUVPTyxNQUZQLEVBR1JSLE1BSFEsQ0FHRCxHQUhDLEVBSVJDLElBSlEsQ0FJSCxXQUpHLEVBSVUsZUFBZXlCLE9BQU9DLElBQXRCLEdBQTZCLEdBQTdCLEdBQW1DRCxPQUFPUSxHQUExQyxHQUFnRCxHQUoxRCxDQUFYOzs7OzJCQXpOUzthQUNGLEtBQUs3RSxLQUFaOzt5QkFHT0wsTUFBTTs7O1dBQ05LLEtBQUwsR0FBYSxFQUFiO09BQ0MsT0FBRCxFQUFVLE1BQVYsRUFBa0IsVUFBbEIsRUFBOEJoQyxPQUE5QixDQUFzQztlQUFRLE9BQUtpQyxNQUFMLENBQVlGLElBQVosRUFBa0JKLElBQWxCLENBQVI7T0FBdEM7Ozs7MkJBME5LO2FBQ0E3RCxFQUFQOzs7OzJCQUdVO1VBQ0xnSCxLQURLLEdBQ0ksS0FBS2pELE1BRFQsQ0FDTGlELEtBREs7VUFFSHVCLE1BRkcsR0FFTyxLQUFLeEUsTUFGWixDQUVId0UsTUFGRzs7VUFHTnZCLFVBQVUsTUFBZCxFQUFzQjtnQkFDWixLQUFLaEgsRUFBTCxDQUFRdUYsTUFBUixDQUFlLEtBQUt6QixRQUFwQixFQUE4QjJCLElBQTlCLEdBQXFDcUQsV0FBN0M7O2FBRUs5QixRQUFRdUIsT0FBT0MsSUFBZixHQUFzQkQsT0FBT1MsS0FBcEM7Ozs7MkJBR1c7cUJBQ2MsS0FBS2pGLE1BRG5CO1VBQ0p3RSxNQURJLFlBQ0pBLE1BREk7VUFDSWxCLE1BREosWUFDSUEsTUFESjs7YUFFSkEsU0FBU2tCLE9BQU9RLEdBQWhCLEdBQXNCUixPQUFPVSxNQUFwQzs7Ozs7O0lDN1hFQzs7O2VBQ1FyRixJQUFaLEVBQWtCOzs7eUdBQ1ZBLElBRFU7O1VBRVhHLFFBQUwsR0FBZ0IsTUFBS21GLEtBQUwsQ0FBVyxNQUFLbkYsUUFBaEIsRUFBMEI7Y0FDaEMsRUFEZ0M7WUFFbEMsSUFGa0M7Z0JBRzlCO2VBQ0Q7O0tBSkssQ0FBaEI7Ozs7OztxQ0FTZTtVQUNSb0YsSUFEUSxHQUNBLEtBQUtyRixNQURMLENBQ1JxRixJQURROzs7VUFHWEEsSUFBSixFQUFVLEtBQUtBLElBQUw7Ozs7MkJBR0w7V0FDQUMsR0FBTCxHQUFXLEtBQUtySixFQUFMLENBQVFxSixHQUFSLEdBQ1J2QyxJQURRLENBQ0gsT0FERyxFQUNNLFFBRE4sRUFFUndDLE1BRlEsQ0FFRCxDQUFDLENBQUMsRUFBRixFQUFNLENBQU4sQ0FGQyxFQUdSQyxJQUhRLENBR0g7ZUFBS3hCLEVBQUVyRyxLQUFQO09BSEcsQ0FBWDtXQUlLOEQsR0FBTCxDQUFTbkUsSUFBVCxDQUFjLEtBQUtnSSxHQUFuQjs7OztFQXZCY3pGOztJQ0FaNEY7OztvQkFDUTNGLElBQVosRUFBa0I7OzttSEFDVkEsSUFEVTs7VUFFWEcsUUFBTCxHQUFnQixNQUFLbUYsS0FBTCxDQUFXLE1BQUtuRixRQUFoQixFQUEwQixFQUExQixDQUFoQjtVQUNLRCxNQUFMLEdBQWMsTUFBS29GLEtBQUwsQ0FBVyxNQUFLbkYsUUFBaEIsRUFBMEIsTUFBS0QsTUFBL0IsQ0FBZDs7Ozs7OzhCQUdROzs7V0FDSGMsS0FBTCxDQUFXM0MsT0FBWCxDQUFtQixnQkFBUTtlQUNwQnNELEdBQUwsQ0FBU2lFLFNBQVQsQ0FBbUIsTUFBbkIsRUFDRzVGLElBREgsQ0FDUTZGLElBRFIsRUFFR0MsS0FGSCxHQUVXOUMsTUFGWCxDQUVrQixNQUZsQixFQUdHQyxJQUhILENBR1EsT0FIUixFQUdpQixLQUhqQixFQUlHQSxJQUpILENBSVEsR0FKUixFQUlhO2lCQUFLLE9BQUtHLENBQUwsQ0FBT2MsRUFBRUMsS0FBVCxJQUFrQixDQUF2QjtTQUpiLEVBS0dsQixJQUxILENBS1EsT0FMUixFQUtpQixFQUxqQixFQU1HQSxJQU5ILENBTVEsR0FOUixFQU1hO2lCQUFLLE9BQUtLLENBQUwsQ0FBT1ksRUFBRXJHLEtBQUYsR0FBVSxPQUFqQixDQUFMO1NBTmIsRUFPR29GLElBUEgsQ0FPUSxRQVBSLEVBT2tCO2lCQUFLLE9BQUtPLE1BQUwsR0FBYyxPQUFLRixDQUFMLENBQU9ZLEVBQUVyRyxLQUFGLEdBQVUsT0FBakIsQ0FBbkI7U0FQbEIsRUFRR2tJLEVBUkgsQ0FRTSxXQVJOLEVBUW1CLE9BQUtQLEdBQUwsQ0FBU1EsSUFSNUIsRUFTR0QsRUFUSCxDQVNNLFVBVE4sRUFTa0IsT0FBS1AsR0FBTCxDQUFTUyxJQVQzQjtPQURGOzs7O0VBUm1CWjs7SUNBakJhOzs7Z0JBQ1FsRyxJQUFaLEVBQWtCOzs7MkdBQ1ZBLElBRFU7O1VBRVhHLFFBQUwsR0FBZ0IsTUFBS21GLEtBQUwsQ0FBVyxNQUFLbkYsUUFBaEIsRUFBMEI7Y0FDaEMsRUFEZ0M7Y0FFaEM7S0FGTSxDQUFoQjs7Ozs7OzZCQU1PO1VBQ0hnRyxNQUFNLEtBQUtuRixLQUFMLENBQVcsQ0FBWCxFQUFjcEUsTUFBZCxHQUF1QixDQUFqQztXQUNLd0csQ0FBTCxHQUFTLEtBQUtqSCxFQUFMLENBQVFnRyxLQUFSLENBQWNvQixNQUFkLEdBQXVCakIsS0FBdkIsQ0FBNkIsQ0FBQyxDQUFELEVBQUssS0FBS1ksWUFBTCxLQUFzQmlELEdBQTNCLENBQTdCLENBQVQ7Ozs7NkJBR087V0FDRjdDLENBQUwsR0FBUyxLQUFLbkgsRUFBTCxDQUFRZ0csS0FBUixDQUFjb0IsTUFBZCxHQUF1QmpCLEtBQXZCLENBQTZCLENBQUMsS0FBS2tCLE1BQU4sRUFBYyxDQUFkLENBQTdCLENBQVQ7Ozs7RUFmZXpEOztJQ0FicUc7OztxQkFDUXBHLElBQVosRUFBa0I7OztxSEFDVkEsSUFEVTs7VUFFWEcsUUFBTCxHQUFnQixNQUFLbUYsS0FBTCxDQUFXLE1BQUtuRixRQUFoQixFQUEwQixFQUExQixDQUFoQjtVQUNLRCxNQUFMLEdBQWMsTUFBS29GLEtBQUwsQ0FBVyxNQUFLbkYsUUFBaEIsRUFBMEIsTUFBS0QsTUFBL0IsQ0FBZDs7Ozs7OzhCQUdROzs7V0FDSG1HLGFBQUwsR0FBcUIsS0FBS2xLLEVBQUwsQ0FBUXdGLEdBQVIsQ0FBWWtFLElBQVosR0FDbEJ6QyxDQURrQixDQUNoQjtlQUFLLE9BQUtBLENBQUwsQ0FBT2MsRUFBRUMsS0FBVCxDQUFMO09BRGdCLEVBRWxCYixDQUZrQixDQUVoQjtlQUFLLE9BQUtBLENBQUwsQ0FBT1ksRUFBRXJHLEtBQVQsQ0FBTDtPQUZnQixDQUFyQjs7V0FJS21ELEtBQUwsQ0FBVzNDLE9BQVgsQ0FBbUIsVUFBQ3dILElBQUQsRUFBT1MsR0FBUCxFQUFlO2VBQzNCM0UsR0FBTCxDQUFTcUIsTUFBVCxDQUFnQixVQUFoQixFQUNHaEQsSUFESCxDQUNRNkYsSUFEUixFQUVHNUMsSUFGSCxDQUVRLEdBRlIsRUFFYSxPQUFLb0QsYUFBTCxDQUFtQlIsSUFBbkIsQ0FGYixFQUdHNUMsSUFISCxDQUdRLFFBSFIsRUFHa0IsT0FBSy9DLE1BQUwsQ0FBWXFDLE1BQVosQ0FBbUIrRCxHQUFuQixDQUhsQixFQUlHckQsSUFKSCxDQUlRLGNBSlIsRUFJd0IsQ0FKeEIsRUFLR0EsSUFMSCxDQUtRLE1BTFIsRUFLZ0IsTUFMaEI7T0FERjs7V0FVS3NELFFBQUwsQ0FBY2xJLE9BQWQsQ0FBc0IsVUFBQ21JLEdBQUQsRUFBTUYsR0FBTixFQUFjO2VBQzdCM0UsR0FBTCxDQUFTaUUsU0FBVCxDQUFtQixLQUFuQixFQUNHNUYsSUFESCxDQUNRd0csR0FEUixFQUVHVixLQUZILEdBRVc5QyxNQUZYLENBRWtCLFFBRmxCLEVBR0dDLElBSEgsQ0FHUSxHQUhSLEVBR2EsR0FIYixFQUlHcUIsS0FKSCxDQUlTLE1BSlQsRUFJaUIsT0FBS3BFLE1BQUwsQ0FBWXFDLE1BQVosQ0FBbUIrRCxHQUFuQixDQUpqQixFQUtHckQsSUFMSCxDQUtRLElBTFIsRUFLYztpQkFBSyxPQUFLRyxDQUFMLENBQU9jLEVBQUVDLEtBQVQsQ0FBTDtTQUxkLEVBTUdsQixJQU5ILENBTVEsSUFOUixFQU1jO2lCQUFLLE9BQUtLLENBQUwsQ0FBT1ksRUFBRXJHLEtBQVQsQ0FBTDtTQU5kO09BREY7Ozs7RUF0Qm9CcUk7O0lDQWxCTzs7O3dCQUNRekcsSUFBWixFQUFrQjs7OzJIQUNWQSxJQURVOztVQUVYRyxRQUFMLEdBQWdCLE1BQUttRixLQUFMLENBQVcsTUFBS25GLFFBQWhCLEVBQTBCO2NBQ2hDLENBQUMsU0FBRCxFQUFZLFNBQVosRUFBdUIsU0FBdkIsQ0FEZ0M7YUFFakMsQ0FBQyxVQUFELEVBQWEsVUFBYjtLQUZPLENBQWhCO1VBSUtELE1BQUwsR0FBYyxNQUFLb0YsS0FBTCxDQUFXLE1BQUtuRixRQUFoQixFQUEwQixNQUFLRCxNQUEvQixDQUFkOzs7Ozs7cUNBR2U7Ozs7OzhCQUlQOzs7VUFDRHFDLE1BREMsR0FDUyxLQUFLckMsTUFEZCxDQUNEcUMsTUFEQzs7V0FFSDhELGFBQUwsR0FBcUIsS0FBS2xLLEVBQUwsQ0FBUXdGLEdBQVIsQ0FBWWtFLElBQVosR0FDbEJ6QyxDQURrQixDQUNoQjtlQUFLLE9BQUtBLENBQUwsQ0FBT2MsRUFBRUMsS0FBVCxDQUFMO09BRGdCLEVBRWxCYixDQUZrQixDQUVoQjtlQUFLLE9BQUtBLENBQUwsQ0FBT1ksRUFBRXJHLEtBQVQsQ0FBTDtPQUZnQixDQUFyQjs7V0FJS21ELEtBQUwsQ0FBVzNDLE9BQVgsQ0FBbUIsVUFBQ3dILElBQUQsRUFBT1MsR0FBUCxFQUFlO2VBQzNCM0UsR0FBTCxDQUFTcUIsTUFBVCxDQUFnQixVQUFoQixFQUNHaEQsSUFESCxDQUNRNkYsSUFEUixFQUVHNUMsSUFGSCxDQUVRLEdBRlIsRUFFYSxPQUFLb0QsYUFBTCxDQUFtQlIsSUFBbkIsQ0FGYixFQUdHNUMsSUFISCxDQUdRLFFBSFIsRUFHa0IsT0FBSy9DLE1BQUwsQ0FBWXFDLE1BQVosQ0FBbUIrRCxHQUFuQixDQUhsQixFQUlHckQsSUFKSCxDQUlRLGNBSlIsRUFJd0IsQ0FKeEIsRUFLR0EsSUFMSCxDQUtRLE1BTFIsRUFLZ0IsTUFMaEI7T0FERjs7V0FTS3NELFFBQUwsQ0FBY2xJLE9BQWQsQ0FBc0IsVUFBQ3FJLE9BQUQsRUFBVUosR0FBVixFQUFrQjtZQUMvQm5LLEVBRCtCLFVBQy9CQSxFQUQrQjs7ZUFFakN3RixHQUFMLENBQVNxQixNQUFULENBQWdCLFVBQWhCLEVBQ0doRCxJQURILENBQ1EwRyxPQURSLEVBRUd6RCxJQUZILENBRVEsR0FGUixFQUVhLE9BQUtvRCxhQUFMLENBQW1CSyxPQUFuQixDQUZiLEVBR0d6RCxJQUhILENBR1EsUUFIUixFQUdrQixPQUFLL0MsTUFBTCxDQUFZcUMsTUFBWixDQUFtQitELEdBQW5CLENBSGxCLEVBSUdyRCxJQUpILENBSVEsY0FKUixFQUl3QixDQUp4QixFQUtHQSxJQUxILENBS1EsTUFMUixFQUtnQixNQUxoQjtlQU1LdEIsR0FBTCxDQUFTaUUsU0FBVCxDQUFtQixLQUFuQixFQUNHNUYsSUFESCxDQUNRMEcsT0FEUixFQUVHWixLQUZILEdBRVc5QyxNQUZYLENBRWtCLFFBRmxCLEVBR0dDLElBSEgsQ0FHUSxHQUhSLEVBR2EsR0FIYixFQUlHcUIsS0FKSCxDQUlTLE1BSlQsRUFJaUIsU0FKakIsRUFLR3JCLElBTEgsQ0FLUSxJQUxSLEVBS2M7aUJBQUssT0FBS0csQ0FBTCxDQUFPYyxFQUFFQyxLQUFULENBQUw7U0FMZCxFQU1HbEIsSUFOSCxDQU1RLElBTlIsRUFNYztpQkFBSyxPQUFLSyxDQUFMLENBQU9ZLEVBQUVyRyxLQUFULENBQUw7U0FOZCxFQU9Hb0YsSUFQSCxDQU9RLFFBUFIsRUFPa0JWLE9BQU8rRCxHQUFQLENBUGxCLEVBUUdyRCxJQVJILENBUVEsY0FSUixFQVF3QixDQVJ4QixFQVNHOEMsRUFUSCxDQVNNLFdBVE4sRUFTbUIsWUFBVzthQUFLckUsTUFBSCxDQUFVLElBQVYsRUFBZ0I0QyxLQUFoQixDQUFzQixNQUF0QixFQUE4Qi9CLE9BQU8rRCxHQUFQLENBQTlCO1NBVGhDLEVBVUdQLEVBVkgsQ0FVTSxVQVZOLEVBVWtCLFlBQVc7YUFBS3JFLE1BQUgsQ0FBVSxJQUFWLEVBQWdCNEMsS0FBaEIsQ0FBc0IsRUFBQyxRQUFRLFNBQVQsRUFBdEI7U0FWL0I7T0FSRjs7OztFQTdCdUI0Qjs7SUNBckJTOzs7eUJBQ1EzRyxJQUFaLEVBQWtCOzs7NkhBQ1ZBLElBRFU7O1VBRVhHLFFBQUwsR0FBZ0IsTUFBS21GLEtBQUwsQ0FBVyxNQUFLbkYsUUFBaEIsRUFBMEIsRUFBMUIsQ0FBaEI7VUFDS0QsTUFBTCxHQUFjLE1BQUtvRixLQUFMLENBQVcsTUFBS25GLFFBQWhCLEVBQTBCLE1BQUtELE1BQS9CLENBQWQ7Ozs7Ozs4QkFHUTs7O1dBQ0htRyxhQUFMLEdBQXFCLEtBQUtsSyxFQUFMLENBQVF3RixHQUFSLENBQVlrRSxJQUFaLEdBQ2xCekMsQ0FEa0IsQ0FDaEI7ZUFBSyxPQUFLQSxDQUFMLENBQU9jLEVBQUVDLEtBQVQsQ0FBTDtPQURnQixFQUVsQmIsQ0FGa0IsQ0FFaEI7ZUFBSyxPQUFLQSxDQUFMLENBQU9ZLEVBQUVyRyxLQUFULENBQUw7T0FGZ0IsQ0FBckI7O1dBSUttRCxLQUFMLENBQVczQyxPQUFYLENBQW1CLFVBQUN3SCxJQUFELEVBQU9TLEdBQVAsRUFBZTtZQUMxQk0sT0FBTyxPQUFLekssRUFBTCxDQUFRd0YsR0FBUixDQUFZaUYsSUFBWixHQUNWeEQsQ0FEVSxDQUNSO2lCQUFLLE9BQUtBLENBQUwsQ0FBT2MsRUFBRUMsS0FBVCxDQUFMO1NBRFEsRUFFVjBDLEVBRlUsQ0FFUCxPQUFLckQsTUFGRSxFQUdWc0QsRUFIVSxDQUdQO2lCQUFLLE9BQUt4RCxDQUFMLENBQU9ZLEVBQUVyRyxLQUFULENBQUw7U0FITyxDQUFiOztlQUtLOEQsR0FBTCxDQUFTcUIsTUFBVCxDQUFnQixNQUFoQixFQUNHK0QsS0FESCxDQUNTbEIsSUFEVCxFQUVHNUMsSUFGSCxDQUVRLE1BRlIsRUFFZ0IsT0FBSy9DLE1BQUwsQ0FBWXFDLE1BQVosQ0FBbUIrRCxHQUFuQixDQUZoQixFQUdHckQsSUFISCxDQUdRLFNBSFIsRUFHbUIsS0FIbkIsRUFJR0EsSUFKSCxDQUlRLEdBSlIsRUFJYTJELElBSmI7T0FORjs7OztFQVp3QlI7O0lDRnRCWTs7Ozs7OztrQ0FFaUJDLFNBQVM7VUFDeEJDLFlBQUo7VUFDSTtjQUNJLElBQUlqSSxLQUFKLENBQVUsU0FBVixDQUFOO09BREYsQ0FFRSxPQUFPWCxDQUFQLEVBQVU7Y0FDSkEsQ0FBTjs7VUFFRSxDQUFDNEksR0FBTCxFQUFVOztVQUVOQyxNQUFNRCxJQUFJRSxLQUFKLENBQVUzSyxLQUFWLENBQWdCLElBQWhCLENBQVY7VUFDSTRLLE1BQUosQ0FBVyxDQUFYLEVBQWMsQ0FBZCxFQVY0QjtZQVd0QkYsSUFBSUcsSUFBSixDQUFTLEtBQVQsQ0FBTjtZQUNNTCxVQUFVLEtBQVYsR0FBa0JFLEdBQXhCOzs7Ozs7SUNaRUk7OzsrQkFDUXZILElBQVosRUFBa0I7Ozt5SUFDVkEsSUFEVTs7VUFFWEcsUUFBTCxHQUFnQixNQUFLbUYsS0FBTCxDQUFXLE1BQUtuRixRQUFoQixFQUEwQjtjQUNoQyxDQUFDLFNBQUQsRUFBWSxTQUFaLEVBQXVCLFNBQXZCLENBRGdDO2FBRWpDLENBQUMsVUFBRCxFQUFhLFVBQWIsQ0FGaUM7Y0FHaEM7S0FITSxDQUFoQjtVQUtLRCxNQUFMLEdBQWMsTUFBS29GLEtBQUwsQ0FBVyxNQUFLbkYsUUFBaEIsRUFBMEIsTUFBS0QsTUFBL0IsQ0FBZDs7Ozs7OzZCQUdPO1VBQ0hpRyxNQUFNLEtBQUtxQixJQUFMLENBQVUsQ0FBVixFQUFhNUssTUFBYixHQUFzQixDQUFoQztVQUNJNkssT0FBTyxLQUFLekcsS0FBTCxDQUFXLENBQVgsRUFBY3BFLE1BQWQsR0FBdUIsQ0FBbEM7V0FDS3dHLENBQUwsR0FBUyxLQUFLakgsRUFBTCxDQUFRZ0csS0FBUixDQUFjb0IsTUFBZCxHQUF1QmpCLEtBQXZCLENBQTZCLENBQUMsQ0FBRCxFQUFJLEtBQUtZLFlBQUwsS0FBc0JpRCxHQUExQixDQUE3QixDQUFUO1dBQ0t1QixFQUFMLEdBQVUsS0FBS3ZMLEVBQUwsQ0FBUWdHLEtBQVIsQ0FBY29CLE1BQWQsR0FBdUJqQixLQUF2QixDQUE2QixDQUFDLENBQUQsRUFBSSxLQUFLWSxZQUFMLEtBQXNCdUUsSUFBMUIsQ0FBN0IsQ0FBVjs7Ozs4QkFHUTs7O1dBQ0hELElBQUwsQ0FBVW5KLE9BQVYsQ0FBa0IsVUFBQ21JLEdBQUQsRUFBTUYsR0FBTixFQUFjO2VBQ3pCM0UsR0FBTCxDQUFTaUUsU0FBVCxDQUFtQixLQUFuQixFQUNHNUYsSUFESCxDQUNRd0csR0FEUixFQUVHVixLQUZILEdBRVc5QyxNQUZYLENBRWtCLFFBRmxCLEVBR0dDLElBSEgsQ0FHUSxHQUhSLEVBR2EsR0FIYixFQUlHcUIsS0FKSCxDQUlTLE1BSlQsRUFJaUIsT0FBS3BFLE1BQUwsQ0FBWXFDLE1BQVosQ0FBbUIrRCxHQUFuQixDQUpqQixFQUtHckQsSUFMSCxDQUtRLElBTFIsRUFLYztpQkFBSyxPQUFLRyxDQUFMLENBQU9jLEVBQUVDLEtBQVQsQ0FBTDtTQUxkLEVBTUdsQixJQU5ILENBTVEsSUFOUixFQU1jO2lCQUFLLE9BQUtLLENBQUwsQ0FBT1ksRUFBRXJHLEtBQVQsQ0FBTDtTQU5kO09BREY7O1dBVUt3SSxhQUFMLEdBQXFCLEtBQUtsSyxFQUFMLENBQVF3RixHQUFSLENBQVlrRSxJQUFaLEdBQ2xCekMsQ0FEa0IsQ0FDaEI7ZUFBSyxPQUFLc0UsRUFBTCxDQUFReEQsRUFBRUMsS0FBVixDQUFMO09BRGdCLEVBRWxCYixDQUZrQixDQUVoQjtlQUFLLE9BQUtBLENBQUwsQ0FBT1ksRUFBRXJHLEtBQVQsQ0FBTDtPQUZnQixDQUFyQjs7V0FJS21ELEtBQUwsQ0FBVzNDLE9BQVgsQ0FBbUIsVUFBQ3dILElBQUQsRUFBT1MsR0FBUCxFQUFlO2VBQzNCM0UsR0FBTCxDQUFTcUIsTUFBVCxDQUFnQixVQUFoQixFQUNHaEQsSUFESCxDQUNRNkYsSUFEUixFQUVHNUMsSUFGSCxDQUVRLEdBRlIsRUFFYSxPQUFLb0QsYUFBTCxDQUFtQlIsSUFBbkIsQ0FGYixFQUdHNUMsSUFISCxDQUdRLFFBSFIsRUFHa0IsT0FBSy9DLE1BQUwsQ0FBWXFDLE1BQVosQ0FBbUIrRCxHQUFuQixDQUhsQixFQUlHckQsSUFKSCxDQUlRLGNBSlIsRUFJd0IsQ0FKeEIsRUFLR0EsSUFMSCxDQUtRLFdBTFIsRUFLcUIsaUJBTHJCLEVBTUdBLElBTkgsQ0FNUSxNQU5SLEVBTWdCLE1BTmhCO09BREY7Ozs7RUFqQzhCaUQ7O0FDRmxDO0FBQ0EsSUFPTXlCO3VCQUNnRTt5QkFBdkR2SCxJQUF1RDtRQUF2REEsSUFBdUQsNkJBQWhELEVBQWdEO3lCQUE1Q0osSUFBNEM7UUFBNUNBLElBQTRDLDZCQUFyQyxFQUFxQzs2QkFBakNDLFFBQWlDO1FBQWpDQSxRQUFpQyxpQ0FBdEIsTUFBc0I7MkJBQWRDLE1BQWM7UUFBZEEsTUFBYywrQkFBTCxFQUFLOzs7U0FDN0RFLElBQUwsR0FBWUEsSUFBWjtTQUNLSixJQUFMLEdBQVlBLElBQVo7U0FDS0MsUUFBTCxHQUFnQkEsUUFBaEI7U0FDS0MsTUFBTCxHQUFjQSxNQUFkOzs7Ozs2QkFHZ0c7c0ZBQTFCLEVBQTBCOzZCQUExRkUsSUFBMEY7VUFBMUZBLElBQTBGLDhCQUFuRixLQUFLQSxJQUE4RTs2QkFBeEVKLElBQXdFO1VBQXhFQSxJQUF3RSw4QkFBakUsS0FBS0EsSUFBNEQ7aUNBQXREQyxRQUFzRDtVQUF0REEsUUFBc0Qsa0NBQTNDLEtBQUtBLFFBQXNDOztVQUF0QkMsTUFBc0IsdUVBQWIsS0FBS0EsTUFBUTs7Y0FDeEZFLElBQVI7YUFDTyxLQUFMO2lCQUNTLElBQUl1RixRQUFKLENBQWEsRUFBQzNGLFVBQUQsRUFBT0Msa0JBQVAsRUFBaUJDLGNBQWpCLEVBQWIsRUFBdUN1QixNQUF2QyxFQUFQOzthQUVHLE1BQUw7aUJBQ1MsSUFBSTJFLFNBQUosQ0FBYyxFQUFDcEcsVUFBRCxFQUFPQyxrQkFBUCxFQUFpQkMsY0FBakIsRUFBZCxFQUF3Q3VCLE1BQXhDLEVBQVA7O2FBRUcsU0FBTDtpQkFDUyxJQUFJZ0YsWUFBSixDQUFpQixFQUFDekcsVUFBRCxFQUFPQyxrQkFBUCxFQUFpQkMsY0FBakIsRUFBakIsRUFBMkN1QixNQUEzQyxFQUFQOzthQUVHLFVBQUw7aUJBQ1MsSUFBSWtGLGFBQUosQ0FBa0IsRUFBQzNHLFVBQUQsRUFBT0Msa0JBQVAsRUFBaUJDLGNBQWpCLEVBQWxCLEVBQTRDdUIsTUFBNUMsRUFBUDs7YUFFRyxnQkFBTDtpQkFDUyxJQUFJOEYsbUJBQUosQ0FBd0IsRUFBQ3ZILFVBQUQsRUFBT0Msa0JBQVAsRUFBaUJDLGNBQWpCLEVBQXhCLEVBQWtEdUIsTUFBbEQsRUFBUDs7Ozs7O2lCQU1PdUYsTUFBTVksYUFBTixDQUFvQiw4Q0FBcEIsQ0FBUDs7Ozs7OztBQ3JDUixJQUFJLENBQUN4TCxPQUFPRCxFQUFaLEVBQWdCLE1BQU0sRUFBQzhLLFNBQVMsa0VBQVYsRUFBTjs7QUFFaEIsSUFFTVk7cUJBQ1U7Ozs7OztnQ0FHZ0Q7MkJBQXZEekgsSUFBdUQ7VUFBdkRBLElBQXVELDZCQUFoRCxFQUFnRDsyQkFBNUNKLElBQTRDO1VBQTVDQSxJQUE0Qyw2QkFBckMsRUFBcUM7K0JBQWpDQyxRQUFpQztVQUFqQ0EsUUFBaUMsaUNBQXRCLE1BQXNCOzZCQUFkQyxNQUFjO1VBQWRBLE1BQWMsK0JBQUwsRUFBSzs7YUFDckQsSUFBSXlILEtBQUosQ0FBVSxFQUFDdkgsVUFBRCxFQUFPSixVQUFQLEVBQWFDLGtCQUFiLEVBQXVCQyxjQUF2QixFQUFWLENBQVA7Ozs7OztBQUtKLGNBQWUsSUFBSTJILE9BQUosRUFBZjs7Ozs7Ozs7In0=
