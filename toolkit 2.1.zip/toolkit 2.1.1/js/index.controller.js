if (typeof _satellite !== 'undefined') {
  _satellite.pageBottom();
}




$(window).load(function () {


  //FORM PAGE
  $(document).ready(function(){
    $("#has-success input").focus(function(){
      $(this).parent().find(".error-icon").hide();
    });
    $("#has-success input").blur(function(){
      $(this).parent().find(".error-icon").show();
    });

    $("#has-postal input").focus(function(){
      $(this).parent().find(".error-icon").hide();
    });
    $("#has-postal input").blur(function(){
      $(this).parent().find(".error-icon").show();
    });

    $("#has-City input").focus(function(){
      $(this).parent().find(".error-icon").hide();

    });
    $("#has-City input").blur(function(){
      $(this).parent().find(".error-icon").show();
    });

    $("#has-Country input").focus(function(){
      $(this).parent().find(".error-icon").hide();

    });
    $("#has-Country input").blur(function(){
      $(this).parent().find(".error-icon").show();
    });

    $("#has-address input").focus(function(){
      $(this).parent().find(".error-icon").hide();

    });
    $("#has-address input").blur(function(){
      $(this).parent().find(".error-icon").show();
    });

    enableDatePicker();
  });


  $("#test .my-nav li").hover(
    function () {
      $(this).addClass("li-hover-style");
      var lThis = $(this);
      $(this).parent().children().each(function (index, element) {
        if (lThis.width > $(element).width()) {
          lThis.children("ul").css("left", lThis.width() + 1);
        } else {
            lThis.children("ul").css("left", $(element).width() + 1);
        }
    })
    },
    function () {
        $('ul', this).slideUp('fast');
        $(this).removeClass("li-hover-style");
    });
    $("#test > li").mouseenter(function(){
        $('.my-nav').css("display", "none");
        $(this).children('.my-nav').css({"display": "block", "visibility": "visible"});
    });
    $("#test .my-nav").mouseleave(function(){
        $('.my-nav').css("display", "none");
    });
     $(".search-ico-anchor").off("click").on("click", function(){
        $(this).css("display", "none");
        $(".search-ico-text").removeClass("display-none");
    });
    $(".search-ico-text").off("blur").on("blur", function(){
        $(this).addClass("display-none");
        $(".search-ico-anchor").css("display", "block");
    });
    bindHomePageEvent();

    mobileHeaderEvent();

});

function enableDatePicker() {
  $('.date-picker').datetimepicker({
    format: 'MM/DD/YYYY'
  });
}

var firstTable = {
  "data": [
    {
      "id": "1",
      "name": "Tiger Nixon",
      "position": "System Architect",
      "salary": "$320,800",
      "start_date": "2011/04/25",
      "office": "Edinburgh",
      "extn": "5421"
    },
    {
      "id": "2",
      "name": "Garrett Winters",
      "position": "Accountant",
      "salary": "$170,750",
      "start_date": "2011/07/25",
      "office": "Tokyo",
      "extn": "8422"
    },
    {
      "id": "3",
      "name": "Ashton Cox",
      "position": "Junior Technical Author",
      "salary": "$86,000",
      "start_date": "2009/01/12",
      "office": "San Francisco",
      "extn": "1562"
    },
    {
      "id": "4",
      "name": "Cedric Kelly",
      "position": "Senior Javascript Developer",
      "salary": "$433,060",
      "start_date": "2012/03/29",
      "office": "Edinburgh",
      "extn": "6224"
    },
    {
      "id": "5",
      "name": "Airi Satou",
      "position": "Accountant",
      "salary": "$162,700",
      "start_date": "2008/11/28",
      "office": "Tokyo",
      "extn": "5407"
    },
    {
      "id": "6",
      "name": "Brielle Williamson",
      "position": "Integration Specialist",
      "salary": "$372,000",
      "start_date": "2012/12/02",
      "office": "New York",
      "extn": "4804"
    },
    {
      "id": "7",
      "name": "Herrod Chandler",
      "position": "Sales Assistant",
      "salary": "$137,500",
      "start_date": "2012/08/06",
      "office": "San Francisco",
      "extn": "9608"
    },
    {
      "id": "8",
      "name": "Rhona Davidson",
      "position": "Integration Specialist",
      "salary": "$327,900",
      "start_date": "2010/10/14",
      "office": "Tokyo",
      "extn": "6200"
    },
    {
      "id": "9",
      "name": "Colleen Hurst",
      "position": "Javascript Developer",
      "salary": "$205,500",
      "start_date": "2009/09/15",
      "office": "San Francisco",
      "extn": "2360"
    },
    {
      "id": "10",
      "name": "Sonya Frost",
      "position": "Software Engineer",
      "salary": "$103,600",
      "start_date": "2008/12/13",
      "office": "Edinburgh",
      "extn": "1667"
    },
    {
      "id": "11",
      "name": "Jena Gaines",
      "position": "Office Manager",
      "salary": "$90,560",
      "start_date": "2008/12/19",
      "office": "London",
      "extn": "3814"
    },
    {
      "id": "12",
      "name": "Quinn Flynn",
      "position": "Support Lead",
      "salary": "$342,000",
      "start_date": "2013/03/03",
      "office": "Edinburgh",
      "extn": "9497"
    },
    {
      "id": "13",
      "name": "Charde Marshall",
      "position": "Regional Director",
      "salary": "$470,600",
      "start_date": "2008/10/16",
      "office": "San Francisco",
      "extn": "6741"
    },
    {
      "id": "14",
      "name": "Haley Kennedy",
      "position": "Senior Marketing Designer",
      "salary": "$313,500",
      "start_date": "2012/12/18",
      "office": "London",
      "extn": "3597"
    },
    {
      "id": "15",
      "name": "Tatyana Fitzpatrick",
      "position": "Regional Director",
      "salary": "$385,750",
      "start_date": "2010/03/17",
      "office": "London",
      "extn": "1965"
    },
    {
      "id": "16",
      "name": "Michael Silva",
      "position": "Marketing Designer",
      "salary": "$198,500",
      "start_date": "2012/11/27",
      "office": "London",
      "extn": "1581"
    },
    {
      "id": "17",
      "name": "Paul Byrd",
      "position": "Chief Financial Officer (CFO)",
      "salary": "$725,000",
      "start_date": "2010/06/09",
      "office": "New York",
      "extn": "3059"
    },
    {
      "id": "18",
      "name": "Gloria Little",
      "position": "Systems Administrator",
      "salary": "$237,500",
      "start_date": "2009/04/10",
      "office": "New York",
      "extn": "1721"
    },
    {
      "id": "19",
      "name": "Bradley Greer",
      "position": "Software Engineer",
      "salary": "$132,000",
      "start_date": "2012/10/13",
      "office": "London",
      "extn": "2558"
    },
    {
      "id": "20",
      "name": "Dai Rios",
      "position": "Personnel Lead",
      "salary": "$217,500",
      "start_date": "2012/09/26",
      "office": "Edinburgh",
      "extn": "2290"
    },
    {
      "id": "21",
      "name": "Jenette Caldwell",
      "position": "Development Lead",
      "salary": "$345,000",
      "start_date": "2011/09/03",
      "office": "New York",
      "extn": "1937"
    },
    {
      "id": "22",
      "name": "Yuri Berry",
      "position": "Chief Marketing Officer (CMO)",
      "salary": "$675,000",
      "start_date": "2009/06/25",
      "office": "New York",
      "extn": "6154"
    },
    {
      "id": "23",
      "name": "Caesar Vance",
      "position": "Pre-Sales Support",
      "salary": "$106,450",
      "start_date": "2011/12/12",
      "office": "New York",
      "extn": "8330"
    },
    {
      "id": "24",
      "name": "Doris Wilder",
      "position": "Sales Assistant",
      "salary": "$85,600",
      "start_date": "2010/09/20",
      "office": "Sidney",
      "extn": "3023"
    },
    {
      "id": "25",
      "name": "Angelica Ramos",
      "position": "Chief Executive Officer (CEO)",
      "salary": "$1,200,000",
      "start_date": "2009/10/09",
      "office": "London",
      "extn": "5797"
    },
    {
      "id": "26",
      "name": "Gavin Joyce",
      "position": "Developer",
      "salary": "$92,575",
      "start_date": "2010/12/22",
      "office": "Edinburgh",
      "extn": "8822"
    },
    {
      "id": "27",
      "name": "Jennifer Chang",
      "position": "Regional Director",
      "salary": "$357,650",
      "start_date": "2010/11/14",
      "office": "Singapore",
      "extn": "9239"
    },
    {
      "id": "28",
      "name": "Brenden Wagner",
      "position": "Software Engineer",
      "salary": "$206,850",
      "start_date": "2011/06/07",
      "office": "San Francisco",
      "extn": "1314"
    },
    {
      "id": "29",
      "name": "Fiona Green",
      "position": "Chief Operating Officer (COO)",
      "salary": "$850,000",
      "start_date": "2010/03/11",
      "office": "San Francisco",
      "extn": "2947"
    },
    {
      "id": "30",
      "name": "Shou Itou",
      "position": "Regional Marketing",
      "salary": "$163,000",
      "start_date": "2011/08/14",
      "office": "Tokyo",
      "extn": "8899"
    },
    {
      "id": "31",
      "name": "Michelle House",
      "position": "Integration Specialist",
      "salary": "$95,400",
      "start_date": "2011/06/02",
      "office": "Sidney",
      "extn": "2769"
    },
    {
      "id": "32",
      "name": "Suki Burks",
      "position": "Developer",
      "salary": "$114,500",
      "start_date": "2009/10/22",
      "office": "London",
      "extn": "6832"
    },
    {
      "id": "33",
      "name": "Prescott Bartlett",
      "position": "Technical Author",
      "salary": "$145,000",
      "start_date": "2011/05/07",
      "office": "London",
      "extn": "3606"
    },
    {
      "id": "34",
      "name": "Gavin Cortez",
      "position": "Team Leader",
      "salary": "$235,500",
      "start_date": "2008/10/26",
      "office": "San Francisco",
      "extn": "2860"
    },
    {
      "id": "35",
      "name": "Martena Mccray",
      "position": "Post-Sales support",
      "salary": "$324,050",
      "start_date": "2011/03/09",
      "office": "Edinburgh",
      "extn": "8240"
    },
    {
      "id": "36",
      "name": "Unity Butler",
      "position": "Marketing Designer",
      "salary": "$85,675",
      "start_date": "2009/12/09",
      "office": "San Francisco",
      "extn": "5384"
    },
    {
      "id": "37",
      "name": "Howard Hatfield",
      "position": "Office Manager",
      "salary": "$164,500",
      "start_date": "2008/12/16",
      "office": "San Francisco",
      "extn": "7031"
    },
    {
      "id": "38",
      "name": "Hope Fuentes",
      "position": "Secretary",
      "salary": "$109,850",
      "start_date": "2010/02/12",
      "office": "San Francisco",
      "extn": "6318"
    },
    {
      "id": "39",
      "name": "Vivian Harrell",
      "position": "Financial Controller",
      "salary": "$452,500",
      "start_date": "2009/02/14",
      "office": "San Francisco",
      "extn": "9422"
    },
    {
      "id": "40",
      "name": "Timothy Mooney",
      "position": "Office Manager",
      "salary": "$136,200",
      "start_date": "2008/12/11",
      "office": "London",
      "extn": "7580"
    },
    {
      "id": "41",
      "name": "Jackson Bradshaw",
      "position": "Director",
      "salary": "$645,750",
      "start_date": "2008/09/26",
      "office": "New York",
      "extn": "1042"
    },
    {
      "id": "42",
      "name": "Olivia Liang",
      "position": "Support Engineer",
      "salary": "$234,500",
      "start_date": "2011/02/03",
      "office": "Singapore",
      "extn": "2120"
    },
    {
      "id": "43",
      "name": "Bruno Nash",
      "position": "Software Engineer",
      "salary": "$163,500",
      "start_date": "2011/05/03",
      "office": "London",
      "extn": "6222"
    },
    {
      "id": "44",
      "name": "Sakura Yamamoto",
      "position": "Support Engineer",
      "salary": "$139,575",
      "start_date": "2009/08/19",
      "office": "Tokyo",
      "extn": "9383"
    },
    {
      "id": "45",
      "name": "Thor Walton",
      "position": "Developer",
      "salary": "$98,540",
      "start_date": "2013/08/11",
      "office": "New York",
      "extn": "8327"
    },
    {
      "id": "46",
      "name": "Finn Camacho",
      "position": "Support Engineer",
      "salary": "$87,500",
      "start_date": "2009/07/07",
      "office": "San Francisco",
      "extn": "2927"
    },
    {
      "id": "47",
      "name": "Serge Baldwin",
      "position": "Data Coordinator",
      "salary": "$138,575",
      "start_date": "2012/04/09",
      "office": "Singapore",
      "extn": "8352"
    },
    {
      "id": "48",
      "name": "Zenaida Frank",
      "position": "Software Engineer",
      "salary": "$125,250",
      "start_date": "2010/01/04",
      "office": "New York",
      "extn": "7439"
    },
    {
      "id": "49",
      "name": "Zorita Serrano",
      "position": "Software Engineer",
      "salary": "$115,000",
      "start_date": "2012/06/01",
      "office": "San Francisco",
      "extn": "4389"
    },
    {
      "id": "50",
      "name": "Jennifer Acosta",
      "position": "Junior Javascript Developer",
      "salary": "$75,650",
      "start_date": "2013/02/01",
      "office": "Edinburgh",
      "extn": "3431"
    },
    {
      "id": "51",
      "name": "Cara Stevens",
      "position": "Sales Assistant",
      "salary": "$145,600",
      "start_date": "2011/12/06",
      "office": "New York",
      "extn": "3990"
    },
    {
      "id": "52",
      "name": "Hermione Butler",
      "position": "Regional Director",
      "salary": "$356,250",
      "start_date": "2011/03/21",
      "office": "London",
      "extn": "1016"
    },
    {
      "id": "53",
      "name": "Lael Greer",
      "position": "Systems Administrator",
      "salary": "$103,500",
      "start_date": "2009/02/27",
      "office": "London",
      "extn": "6733"
    },
    {
      "id": "54",
      "name": "Jonas Alexander",
      "position": "Developer",
      "salary": "$86,500",
      "start_date": "2010/07/14",
      "office": "San Francisco",
      "extn": "8196"
    },
    {
      "id": "55",
      "name": "Shad Decker",
      "position": "Regional Director",
      "salary": "$183,000",
      "start_date": "2008/11/13",
      "office": "Edinburgh",
      "extn": "6373"
    },
    {
      "id": "56",
      "name": "Michael Bruce",
      "position": "Javascript Developer",
      "salary": "$183,000",
      "start_date": "2011/06/27",
      "office": "Singapore",
      "extn": "5384"
    },
    {
      "id": "57",
      "name": "Donna Snider",
      "position": "Customer Support",
      "salary": "$112,000",
      "start_date": "2011/01/25",
      "office": "New York",
      "extn": "4226"
    }
  ]
};

function complexTable() {
  var tableref;
    // buildDashBoardTable("1", "dashboard-products-list", "dashboard-list", "dashboard-products-list-1", false, "", false, tableref, false, true, false);
    buildDashBoardTable("1", "dashboard-products-list", firstTable, "dashboard-products-list-1", true, "", false, tableref, false, false, true, false);
    buildDashBoardTable("2", "dashboard-products-list", firstTable, "dashboard-products-list-2", false, "", true, tableref, true, false, false, true);
    buildDashBoardTable("3", "dashboard-products-list", firstTable, "dashboard-products-list-3", false , "", true, tableref, true, true, true, true);
    buildDashBoardTable("4", "dashboard-products-list", firstTable, "dashboard-products-list-4", false, "", false, tableref, false, false, false);
}

function customizeTable() {
    var tableref;
    // buildDashBoardTable(dIndex, tableId, jsonName, tableFullId, filterFlag, displayflag, checkFlag, tableref, colEnable)
    // buildDashBoardTable("1", "dashboard-products-list", "customize", "dashboard-products-list-1", false , "", true, tableref, true, true, true, true);
    // buildDashBoardTable("2", "dashboard-products-list", "customize", "dashboard-products-list-2", false, "", true, tableref, true, true, true, true);
}

function mobileHeaderEvent() {
    $(".mobile-view-class li > a").off("click").on("click", function(){
        var _this = $(this);
        if($(_this).next("ul").length > 0) {
            if($(_this).next("ul").hasClass("display-none")) {
                $(_this).next("ul").removeClass("display-none");
                $(_this).addClass("ocean");
                $(_this).next("ul").addClass("border-bottom-gray");
                $(_this).children().removeClass("plus-icon").addClass("minus-icon");
            } else {
                $(_this).next("ul").addClass("display-none");
                $(_this).removeClass("ocean");
                $(_this).next("ul").removeClass("border-bottom-gray");
                $(_this).children().removeClass("minus-icon").addClass("plus-icon");
            }

        } else {
            var className = $(_this).attr("class");
            $.get("templates/"+className+".html", function(data) {
                $(".outerwrapper-b").html("");
                $(".outerwrapper-b").html(data);
            });
        }
    });
    $(".search-ico-anchor").off("click").on("click", function(){
        $(this).css("display", "none");
        $(".search-ico-text").removeClass("display-none");
        $(".close-button").removeClass("display-none");
    });
    $(".search-ico-text").off("blur").on("blur", function(){
        $(this).addClass("display-none");
        $(".search-ico-anchor").css("display", "block");
        $(".close-button").addClass("display-none");
    });
}


function bindHomePageEvent () {
    if(window.location.href.indexOf("how-to-use") !== -1) {
        var goTo=0;
        goTo = $($(".getting-started")[4]).height() + $("header").height() - 40;
        setTimeout(function(){
            $(window).scrollTop(goTo);
        }, 500);
    }
    if(window.location.href.indexOf("browser-devices") !== -1) {
        var goTo=0;
        goTo = $($(".getting-started")[4]).height() + $("header").height() + 900;
        setTimeout(function(){
            $(window).scrollTop(goTo);
        }, 500);
    }
}

function allEventBind () {
    $(".all-table-search").off("keyup").on("keyup", function(){
        allTableSearch($(this));
    });
    $(".selectpicker").off("change").on("change", function() {
        showEntries($(this));
    });
    $(".table-cell-filter input[type='text']").off("keyup").on("keyup", function() {
        cellEditable($(this));
    });
}

function allTableSearch(getP) {
    var _this = getP;
    var currentValue = _this.val().toLowerCase();
    var getElement = _this.parents(".table-responsive");
    var count = parseInt(getElement.find(" .selectpicker").val());
    getElement.find(" tbody > tr").each(function(index, element){
        $(element).find(" > td").each(function(cindex, celement){
            if($(celement).text().toLowerCase().indexOf(currentValue) > -1) {
                $(element).removeClass("display-none");
                return false;
            } else {
                $(element).addClass("display-none");
            }
        });
    });
    // getElement.find(" .selectpicker").trigger("change", function(){
    //     showEntries($(this));
    // });
}

function showEntries(getP) {
    var _this = getP;
    var count = parseInt(_this.val());
    var currentValue = _this.parents(".table-responsive").find(" .all-table-search");
    var getElement = _this.parents(".table-responsive");
    getElement.find(" tbody > tr").each(function(index, element){
        if(currentValue && !$(element).hasClass("display-none") && index < count) {
            $(element).removeClass("display-none");
        } else if(index < count) {
            $(element).removeClass("display-none");
        } else {
            $(element).addClass("display-none");
        }
    });
}

function pagination() {
    var pageStart;
    var pageEnd;
    var pageSize;
    pageStart = (selVal - 1 * showEntries) + 1;
    pageEnd = selVal * showEntries;
}

function cellEditable(getP) {
    var _this = getP;
    var currentValue = _this.val().toLowerCase();
    var currentIndex = _this.parent().index();
    var getElement = _this.closest("tr").siblings();
    getElement.each(function(index, element){
        if($(element).find(" > td:nth-child("+(currentIndex+1)+")").text().toLowerCase().indexOf(currentValue) > -1) {
            $(element).removeClass("display-none");
        } else {
            $(element).addClass("display-none");
        }
    });
}

function buildDashBoardTable(dIndex, tableId, jsonName, tableFullId, filterFlag, displayflag, checkFlag, tableref, colEnable, editable, goToPage) {
    var rows_selected = [];
    var table = tableref;
    var columns = [];
    var columnDefs = [];
    if(checkFlag && editable) {
        columns = [
        { "data": "id" },
        {
            "data": "name", "render": function(data, type, row, meta){
                if(row.expandedList && row.expandedList.length > 0) {
                    return '<span>'+data+'</span><br><a class="show-more-block" href="javascript:void(0);">'+row.expandedList.length+' Others</a>';
                } else {
                    return '<span>'+data+'</span><a href="javascript:void(0);"></a>';
                }
            }
        },
        {
            "data": "position"
        },
        {
            "data": "office"
        },
        {
            "data": "salary"
        },
        {
            "data": "start_date",
            "type": "datetime"
        },
        {
            "data": null,
            "className": 'details-control',
            "defaultContent": '',
            "orderable": false,
            "render": function(data, type, row, meta){
                return '<span class="glyphicon glyphicon-pencil"></span>';
            }
        }];
        columnDefs = [{
            'targets': 0,
            'searchable': false,
            'orderable': false,
            'width': '15px',
            'className': 'dt-body-center',
            'render': function(data, type, full, meta) {
                return '<input type="checkbox">';
            }
        }];
    } else if (checkFlag) {
        columns = [
        { "data": "id" },
        {
            "data": "name", "render": function(data, type, row, meta){
                if(row.expandedList && row.expandedList.length > 0) {
                    return '<span>'+data+'</span><br><a class="show-more-block" href="javascript:void(0);">'+row.expandedList.length+' Others</a>';
                } else {
                    return '<span>'+data+'</span><a href="javascript:void(0);"></a>';
                }
            }
        },
        {
            "data": "position"
        },
        {
            "data": "office"
        },
        {
            "data": "salary"
        },
        {
            "data": "start_date",
            "type": "datetime"
        }];
        columnDefs = [{
            'targets': 0,
            'searchable': false,
            'orderable': false,
            'width': '15px',
            'className': 'dt-body-center',
            'render': function(data, type, full, meta) {
                return '<input type="checkbox">';
            }
        }];
    }  else if (editable) {
        columns = [
        {
            "data": "name", "render": function(data, type, row, meta){
                if(row.expandedList && row.expandedList.length > 0) {
                    return '<span>'+data+'</span><br><a class="show-more-block" href="javascript:void(0);">'+row.expandedList.length+' Others</a>';
                } else {
                    return '<span>'+data+'</span><a href="javascript:void(0);"></a>';
                }
            }
        },
        {
            "data": "position"
        },
        {
            "data": "office"
        },
        {
            "data": "salary"
        },
        {
            "data": "start_date",
            "type": "datetime"
        },
        {
            "data": null,
            "className": 'details-control',
            "defaultContent": '',
            "orderable": false,
            "render": function(data, type, row, meta){
                return '<span class="glyphicon glyphicon-pencil"></span><span class="glyphicon glyphicon-floppy-disk display-none"></span>';
            }
        }];
        columnDefs = [{
            'targets': 0,
            'searchable': false,
            'orderable': false
        }];
    } else {
        columns = [{
            "data": "name"
        },
        {
            "data": "position"
        },
        {
            "data": "office"
        },
        {
            "data": "salary"
        },
        {
            "data": "start_date",
            "type": "datetime"
        }];
        columnDefs = [{
            'targets': 0
        }];
    }
    table = $('#' + tableFullId).DataTable({
        "data": jsonName.data,
        "columns": columns,
        "paging": true,
        autoWidth: false,
        "dom": '<"top"flp>rt<"bottom"i><"clear">',
        "language": {
            "sInfo": "_START_ - _END_ of _TOTAL_ Results",
            "infoFiltered": "",
            "sSearch": "",
            searchPlaceholder: "Search",
            "sLengthMenu": "Showing _MENU_ entries",
            "paginate": {
              "previous": "<",
              "next": ">"
            }
        },
        // "lengthMenu": [[10, 25, 50, -1, -1, -1], [1, 2, 3, 4, 5, 6]],
        "responsive": true,
        'columnDefs': columnDefs
    });

    $('#' + tableFullId).dataTable().fnDraw();
    if (checkFlag) {
        addShowMoreEvent('#' + tableFullId, table, false);
    }

    if (filterFlag) {
        setTimeout(function() {
            var innerHtml = "<tr>";
            $('#'+tableFullId+' thead tr:eq(0) th').each( function () {
                var title = $('#'+tableFullId+' thead tr:eq(0) th').eq( $(this).index() ).text();
                innerHtml += '<td><input type="text" placeholder="Search '+title+'" /></td>';
            } );
            innerHtml += '</tr>';
            $('#'+tableFullId+' thead tr:eq(0)').after(innerHtml);
            $( table.table().container() ).on( 'keyup', '#'+tableFullId+' thead tr:eq(1) input[type="text"]', function () {
                table
                    .column( $(this).parent().index() )
                    .search( this.value )
                    .draw();
            } );
        }, 500);
    }
    $('#' + tableFullId).off("click").on( 'click', 'tbody td:not(:first-child)', function (e) {
        console.log("in")
    } );

    window.onresize = function() {
        table.columns.adjust().responsive.recalc();
    }; 

    if(editable) {
        var bindChild = checkFlag ? " td:not(:first-child)" : " td";
        $('#' + tableFullId).off("click").on('click', 'td.details-control', function () {
            var tr = $(this).closest('tr');
            var row = table.row( tr );
            if ($(tr).attr("edit") === "true") {
              $(tr).find(" td .glyphicon").removeClass("glyphicon-floppy-disk").addClass("glyphicon-pencil");
                $(tr).attr("edit", false);
                $(tr).find(bindChild).each(function(index, element){
                    if (index < $(tr).find(bindChild).length - 1) {
                        var text = $(element).find(" input[type='text']").val();
                        $(element).html(text);
                        $(element).find(" input[type='text']").val(text);
                    }
                });
            } else {
                $(tr).attr("edit", true);
                $(tr).find(" td .glyphicon").removeClass("glyphicon-pencil").addClass("glyphicon-floppy-disk");
                $(tr).find(bindChild).each(function(index, element){
                    if (index < $(tr).find(bindChild).length - 1) {
                        var text = $(element).text();
                        $(element).html("<input type='text' class='edit-input'>");
                        $(element).find(" input[type='text']").val(text);
                    }
                });
            }
        } );
    }

    // Handle click on checkbox
    // $('#' + tableId + '-' + dIndex + ' tbody').off("click").on('click', 'input[type="checkbox"]', function(e) {
    //     var $row = $(this).closest('tr');
    //     // Get row data
    //     var data = table.row($row).data();

    //     // Get row ID
    //     var rowId = data && data.id;

    //     // Determine whether row ID is in the list of selected row IDs
    //     var index = $.inArray(rowId, rows_selected);

    //     // If checkbox is checked and row ID is not in list of selected row IDs
    //     if (this.checked && index === -1) {
    //         rows_selected.push(rowId);

    //         // Otherwise, if checkbox is not checked and row ID is in list of selected row IDs
    //     } else if (!this.checked && index !== -1) {
    //         rows_selected.splice(index, 1);
    //     }

    //     if (this.checked) {
    //         $row.addClass('selected-row');
    //     } else {
    //         $row.removeClass('selected-row');
    //     }
    //     // counterUpdates(rows_selected);
    //     // Update state of "Select all" control
    //     updateDataTableSelectAllCtrl(table);

    //     // Prevent click event from propagating to parent
    //     e.stopPropagation();
    // });

    // Handle click on table cells with checkboxes
    // $('#' + tableId + "-" + dIndex).on('click', 'tbody td, thead th:first-child', function(e) {
    //     $(this).parent().find('input[type="checkbox"]').trigger('click');
    // });

    // Handle click on "Select all" control
    $('#' + tableId + '-' + dIndex + ' thead input[name="select_all"]', table.table().container()).on('click', function(e) {
        if (this.checked) {
            $('#' + tableId + '-' + dIndex + ' tbody input[type="checkbox"]:not(:checked)').trigger('click');
        } else {
            $('#' + tableId + '-' + dIndex + ' tbody input[type="checkbox"]:checked').trigger('click');
        }
        // counterUpdates(rows_selected);

        // Prevent click event from propagating to parent
        e.stopPropagation();
    });
    var temp = $('#' + tableId + '-' + dIndex + '_wrapper .dataTables_paginate').detach();
    $('#' + tableId + '-' + dIndex + '_wrapper .bottom').append(temp);
    $('#' + tableId + '-' + dIndex + '_wrapper .dataTables_paginate').addClass("col-md-12 col-xs-12 padding-zero");
    $('#' + tableId + '-' + dIndex + '_wrapper .dataTables_paginate').before('<div class="col-md-4 col-sm-3 col-xs-2"></div>');
    $('#' + tableId + '-' + dIndex + '_wrapper .dataTables_info').addClass("col-md-3 padding-zero width-auto");
    $('#' + tableId + '-' + dIndex + '_wrapper .dataTables_length').addClass("col-md-4 col-sm-6 col-xs-8 padding-zero");
    $('#' + tableId + '-' + dIndex + '_wrapper .top').append($('#' + tableId + '-' + dIndex + '_wrapper .dataTables_info').detach());
    $('#' + tableId + '-' + dIndex + '_wrapper .top').addClass("col-xs-12 padding-zero");
    $('#' + tableId + '-' + dIndex + '_wrapper .top .dataTables_filter').addClass("col-md-4 col-xs-12");


    if (colEnable) {
        var innerHtml = "";
        innerHtml += '<div class="button-group">';
        innerHtml += '<button type="button" class="btn btn-default btn-sm dropdown-toggle col-xs-6 col-sm-6 pull-right" data-toggle="dropdown">Display<span class="caret"></span></button>';
        innerHtml += '<ul class="dropdown-menu col-xs-8">';
        innerHtml += '<li><a href="javascript:void();" class="small toggle-vis" data-value="option1" tabIndex="-1" data-column="1"><input type="checkbox"/>Name</a></li>';
        innerHtml += '<li><a href="javascript:void();" class="small toggle-vis" data-value="option2" tabIndex="-1" data-column="2"><input type="checkbox"/>SOEID</a></li>';
        innerHtml += '<li><a href="javascript:void();" class="small toggle-vis" data-value="option3" tabIndex="-1" data-column="3"><input type="checkbox"/>Product</a></li>';
        innerHtml += '<li><a href="javascript:void();" class="small toggle-vis" data-value="option4" tabIndex="-1" data-column="4"><input type="checkbox"/>Status</a></li>';
        innerHtml += '<li><a href="javascript:void();" class="small toggle-vis" data-value="option5" tabIndex="-1" data-column="5"><input type="checkbox"/>Date</a></li>';
        innerHtml += '</ul>';
        innerHtml += '</div>';
        $('#' + tableId + '-' + dIndex + '_wrapper .top .dataTables_filter').before("<div class='col-md-4 col-xs-5 col-sm-6 filter-by-block pull-right padding-right-0'>"+innerHtml+"</div>");

        $('#' + tableId + '-' + dIndex + '_wrapper .top  a.toggle-vis').on( 'click', function (e) {
            e.preventDefault();
            var _this = $(this);
            if (_this.find("input[type='checkbox']").is(":checked")) {
                _this.find("input[type='checkbox']").attr("checked", "");
                _this.find("input[type='checkbox']").prop("checked", false);
            } else {
                _this.find("input[type='checkbox']").attr("checked", "checked");
                _this.find("input[type='checkbox']").prop("checked", true);
            }
            // Get the column API object
            var column = table.column( $(this).attr('data-column') );

            // Toggle the visibility
            column.visible( ! column.visible() );
        } );
    }

    if(goToPage) {
        var pageCount = table.page.info().pages;
        var innerHtml = "";
        innerHtml += '<div class="col-xs-3 goto-page-block pull-right padding-right-0">';
        innerHtml += '<div class="pull-right">';
        innerHtml += '<label>Go to page:</label>';
        // innerHtml += ' <select class="go-to-page form-control input-sm">';
        // for (var i = 0; i < pageCount; i++) {
        //     innerHtml += '<option>'+(i+1)+'</option>';
        // }
        // innerHtml += '</select>';
        innerHtml += '<input type="text" value="1" class="go-to-page form-control input-sm">';
        innerHtml += '</div>';
        innerHtml += '</div>';
        if(colEnable) {
            $('#' + tableId + '-' + dIndex + '_wrapper .bottom > div:first-child').append(innerHtml);
            $('#' + tableId + '-' + dIndex + '_wrapper .bottom > div:first-child').addClass("padding-left-0");
            $('#' + tableId + '-' + dIndex + '_wrapper .bottom .goto-page-block').removeClass("col-xs-3").addClass("col-xs-12 padding-left-0");
            $('#' + tableId + '-' + dIndex + '_wrapper .bottom .goto-page-block > div').removeClass("pull-right").addClass("pull-left");
            $('#' + tableId + '-' + dIndex + '_wrapper .dataTables_paginate').addClass("col-md-8 col-xs-12 padding-zero");
        } else {
            $('#' + tableId + '-' + dIndex + '_wrapper .top .dataTables_filter').after(innerHtml);
        }

        $('#' + tableId + '-' + dIndex + '_wrapper .goto-page-block input[type="text"].go-to-page').off('keyup').on( 'keyup', function () {
            var _this = $(this);
            var val = parseInt(_this.val());
            if (val && val <= pageCount > 0) {
              table.page( val - 1 ).draw( 'page' );
            } else {
              table.page( 0 ).draw( 'page' );
              _this.val("");
            }
        } );
    }

}

function addShowMoreEvent(element, table, flag) {
    $(element).off('click').on('click', 'td .show-more-block', function () {
        var tr = $(this).closest('tr');
        var row = table.row( tr );

        if ( row.child.isShown() ) {
            // This row is already open - close it
            row.child.hide();
            tr.removeClass('shown');
            // $(tr).next().removeClass('odd').removeClass('even');
        }
        else {
            // Open this row
            row.child( format(row.data(), flag) ).show();
            tr.addClass('shown');
            tr.find(".show-more-block").addClass("display-none");
            if($(tr).hasClass("odd")) {
                $(tr).next().addClass('odd').addClass("expanded-row");
            } else {
                $(tr).next().addClass('even').addClass("expanded-row");
            }
            if($(tr).next().hasClass("expanded-row")) {
                $(tr).find(" .row-span-list").css("opacity", "0");
            }
            if(flag){
                $(tr).find(" td:not(:first-of-type)").addClass("apply-border");
            }
            $(tr).next().find("td .show-less-block").off("click").on("click", function() {
                if ( row.child.isShown() ) {
                    row.child.hide();
                    tr.removeClass('shown');
                    tr.find(".show-more-block").removeClass("display-none");
                    $(tr).find(" td:not(:first-of-type)").removeClass("apply-border");
                    $(tr).find(" .row-span-list").css("opacity", "1");
                }
            });
            $(".view-more-hover, .select-drop-table, .hover-layer-table").hover(
                function(){
                    $(".select-drop-table").removeClass("display-none");
                },
                function () {
                    $(".select-drop-table").addClass("display-none");
                });
        }
    } );

}

function format ( d , flag ) {
    var template = "";
    if(flag){
        template += '<h4 class="product-ownership">Product Ownership</h4>';
    }
    template += '<table cellpadding="5" cellspacing="0" border="0" class="table expanded-list-table">';
    template += '<thead>';
    for(var i =0; i < d.headersList.length;i++) {
        template += '<th>'+d.headersList[i].headername+'</th>';
    }
    template += '</thead>';
    template += '<tbody>';
    if(flag){
        for(var i =0; i < d.expandedList.length;i++) {
            template += '<tr class="right-arrow">';
            template += '<td><input type="checkbox" class="margin-right-10">'+d.expandedList[i].category+'</td>';
            template += '<td>'+d.expandedList[i].endate+'</td>';
            template += '<td>'+d.expandedList[i].Location;
            if(d.expandedList[i].viewmore) {
                template  += '<div class="select-drop-table display-none">';
                template  += '<div class="down-green-block"><span>Yet to add</span></div>';
                template  += '</div>';
                template  += '<div class="hover-layer-table"></div>';
            }
            template += '</td>';
            template += '</tr>';
        }
    } else {
        for(var i =0; i < d.expandedList.length;i++) {
            template += '<tr>';
            template += '<td><input type="checkbox"></td>';
            template += '<td>'+d.expandedList[i].ProductOwner+'</td>';
            template += '<td>'+d.expandedList[i].office+'</td>';
            template += '<td><a href="mailto:"'+d.expandedList[i].Email+'>'+d.expandedList[i].Email+'</a></td>';
            template += '<td>'+d.expandedList[i].start_date+'</td>';
            template += '<td>'+d.expandedList[i].position+'</td>';
            // if (i === 0) {
            //     template += '<td rowspan='+d.expandedList.length+'>'+d.ProductCategory+'</td>';
            //     template += '<td rowspan='+d.expandedList.length+'><span class="col-span-list">'+d.start_date+'</span></td>';
            // }
            template += '</tr>';
        }
    }
    if(d.expandedList.length > 1) {
        template += '<tr class="show-less-block">';
        if(flag){
            template += '<td colspan="3"><a>Show Less</a></td>';
        } else {
            template += '<td></td>';
            template += '<td colspan="5"><a>Show Less</a></td>';
        }
        template += '</tr>';
    }
    template += '</tbody>';
    template += '</table>';

    return template;
}

function updateDataTableSelectAllCtrl(table){
   var $table             = table.table().node();
   var $chkbox_all        = $('tbody input[type="checkbox"]', $table);
   var $chkbox_checked    = $('tbody input[type="checkbox"]:checked', $table);
   var chkbox_select_all  = $('thead input[name="select_all"]', $table).get(0);

   // If none of the checkboxes are checked
   if($chkbox_checked.length === 0){
      chkbox_select_all.checked = false;
      if('indeterminate' in chkbox_select_all){
         chkbox_select_all.indeterminate = false;
      }

   // If all of the checkboxes are checked
   } else if ($chkbox_checked.length === $chkbox_all.length){
      chkbox_select_all.checked = true;
      if('indeterminate' in chkbox_select_all){
         chkbox_select_all.indeterminate = false;
      }

   // If some of the checkboxes are checked
   } else {
      chkbox_select_all.checked = true;
      if('indeterminate' in chkbox_select_all){
         chkbox_select_all.indeterminate = true;
      }
   }
}

