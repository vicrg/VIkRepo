==================================================================

CITI WEB APPLICATION TOOLKIT ICON LIBRARY 1.1 

==================================================================

Version 1.1 Citi Web Application Toolkit Icon Library 
Released November 30, 2017

------------------------------------------------------------------

Hi there! Since we can no longer use Font Awesome at Citi, we brought 
you an alternative, and it's Citi branded!! This free icon set is 
available in png and svg format. 

All icons are offered in 512px512px. 

These icons are an extract of the Citi Web Application Toolkit 2.0. 
They were created by CTO Digital Studio (2017) and designed per Global 
Branding Guidelines released in May 2017.

To ask a question or suggest an enhanmcent visit our Collabroate site:  
- https://collaborate.citi.net/groups/cto-digital-studio/projects/web-application-toolkit 

For more on the Citi Web Application Toolkit, visit our website: 

- http://toolkit.nam.nsroot.net


* UPDATES
------------------------------------------------------------------
In this package, we've added about 30 more icons to the library, including: 

- Added icons for text editors including text alignment, bullet list, unordered list, color picker

- Added common system icons inclding server, firewall, application, etc. 

- Added calendar, plus, minus, link, unlink icons and more! 


* GENERAL USAGE
------------------------------------------------------------------
In this package, you will find an icon set of 80+ icons in two 
styles: 

- Circle : This is the primary icon choice and should be used in 
the majority of situations.

- Outlined: When there are multiple icons or other graphic elements 
that will clutter the interface, use the outlined version.


* REFERENCES ON SVG USAGE
------------------------------------------------------------------

- https://www.lifewire.com/svg-file-4120603 

- https://svgontheweb.com/


* FOR INTERNAL USE ONLY
------------------------------------------------------------------

These icons were made for the Citi Web Application Toolkit for 
internal application development. For more information on icons,
please visit Brand Central at: https://brandcentral.citi.com/


* CONTACT INFORMATION
------------------------------------------------------------------

Here at CTO Digital Studio, we aim to foster and support the 
production of modern, engaging, transformative products & 
experiences through strategic marketing, digital communication, 
innovation and design services.

Visit us on our website: 
https://collaborate.citi.net/groups/cto-digital-studio

==================================================================

Copyright (C) 2017. Citigroup Inc. 
Citigroup.com is the global source of information about and access 
to financial services provided by the Citigroup companies.