
package sans;

import com.ibm.mq.jms.MQQueue;
import com.ibm.msg.client.jms.JmsConnectionFactory;
import com.ibm.msg.client.jms.JmsFactoryFactory;
import java.util.ArrayList;
import javax.jms.Connection;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;

public class SansQueue {
    private SansConfig config = null;

    public SansQueue(SansConfig config) {
        this.config = config;
    }

    public ArrayList<String> sendToMQ(ArrayList<String> sReqs) throws Exception {
        Connection connection = null;
        Session session = null;
        Destination destination = null;
        Destination replyTo = null;
        MessageProducer producer = null;

        try {
            System.out.println("Sender:Initializing Factory");
            JmsFactoryFactory ff = JmsFactoryFactory.getInstance("com.ibm.msg.client.wmq");
            System.out.println("Sender:Creating Connection Factory");
            JmsConnectionFactory cf = ff.createConnectionFactory();
            System.out.println("Sender:Initializing Connection");
            cf.setStringProperty("XMSC_WMQ_HOST_NAME", this.config.SANSOutQueueServer);
            cf.setIntProperty("XMSC_WMQ_PORT", Integer.parseInt(this.config.SANSOutQueuePort));
            cf.setStringProperty("XMSC_WMQ_CHANNEL", this.config.SANSOutQueueChannel);
            cf.setIntProperty("XMSC_WMQ_CONNECTION_MODE", 1);
            cf.setStringProperty("XMSC_WMQ_QUEUE_MANAGER", this.config.SANSOutQueueManager);
            System.out.println("Sender:Creating Connection");
            connection = cf.createConnection();
            System.out.println("Sender:Creating Session");
            session = connection.createSession(false, 1);
            System.out.println("Sender:Creating Queue");
            destination = session.createQueue(this.config.SANSOutQueue);
            ((MQQueue)destination).setTargetClient(1);
            System.out.println("Sender:Creating ReplyTo Queue");
            replyTo = session.createQueue(this.config.SANSOutQueueReplyTo);
            System.out.println("Sender:Creating Producer");
            producer = session.createProducer(destination);
            System.out.println("Sender:Starting Connection");
            connection.start();

            for(int i = 0; i < sReqs.size(); ++i) {
                System.out.println("Sender:Creating Message[" + ((String)sReqs.get(i)).length() + "][" + (String)sReqs.get(i) + "]");
                TextMessage message = session.createTextMessage((String)sReqs.get(i));
                message.setJMSReplyTo(replyTo);
                System.out.println("Sender:Sending Message");
                producer.send(message);
                System.out.println("Sender:Sent message");
                sReqs.set(i, "SENT");
            }
        } catch (Exception var27) {
            var27.printStackTrace();
        } finally {
            if (producer != null) {
                try {
                    producer.close();
                } catch (JMSException var26) {
                    System.out.println("Sender:Producer could not be closed.");
                }
            }

            if (session != null) {
                try {
                    session.close();
                } catch (JMSException var25) {
                    System.out.println("Sender:Session could not be closed.");
                }
            }

            if (connection != null) {
                try {
                    connection.close();
                } catch (JMSException var24) {
                    System.out.println("Sender:Connection could not be closed.");
                }
            }

        }

        return sReqs;
    }

    public ArrayList<String> readFromMQ() throws Exception {
        int timeout = 5000;
        Connection connection = null;
        Session session = null;
        Destination destination = null;
        MessageConsumer consumer = null;
        ArrayList response = new ArrayList();

        try {
            System.out.println("Receiver:Initializing Factory");
            JmsFactoryFactory ff = JmsFactoryFactory.getInstance("com.ibm.msg.client.wmq");
            System.out.println("Receiver:Creating Connection Factory");
            JmsConnectionFactory cf = ff.createConnectionFactory();
            System.out.println("Receiver:Initializing Connection");
            cf.setStringProperty("XMSC_WMQ_HOST_NAME", this.config.SANSInQueueServer);
            cf.setIntProperty("XMSC_WMQ_PORT", Integer.parseInt(this.config.SANSInQueuePort));
            cf.setStringProperty("XMSC_WMQ_CHANNEL", this.config.SANSInQueueChannel);
            cf.setIntProperty("XMSC_WMQ_CONNECTION_MODE", 1);
            cf.setStringProperty("XMSC_WMQ_QUEUE_MANAGER", this.config.SANSInQueueManager);
            System.out.println("Receiver:Creating Connection");
            connection = cf.createConnection();
            System.out.println("Receiver:Creating Session");
            session = connection.createSession(false, 1);
            System.out.println("Receiver:Creating Queue");
            destination = session.createQueue(this.config.SANSInQueue);
            System.out.println("Receiver:Creating Consumer");
            consumer = session.createConsumer(destination);
            System.out.println("Receiver:Starting Connection");
            connection.start();
            System.out.println("Receiver:Receiving Message");
            boolean anyMessageReceived = false;

            for(Message message = consumer.receive((long)timeout); message != null; anyMessageReceived = true) {
                String text = ((TextMessage)message).getText();
                if (text != null) {
                    System.out.println("Receiver:Received message:[" + text.length() + "][" + text + "]");
                } else {
                    System.out.println("Receiver:Received message:[" + text + "]");
                }

                response.add(((TextMessage)message).getText());
                message = consumer.receive((long)timeout);
            }

            if (!anyMessageReceived) {
                System.out.println("Receiver:No message received");
            }
        } catch (JMSException var28) {
            var28.printStackTrace();
        } finally {
            if (consumer != null) {
                try {
                    consumer.close();
                } catch (JMSException var27) {
                    System.out.println("Receiver:Consumer could not be closed.");
                }
            }

            if (session != null) {
                try {
                    session.close();
                } catch (JMSException var26) {
                    System.out.println("Receiver:Session could not be closed.");
                }
            }

            if (connection != null) {
                try {
                    connection.close();
                } catch (JMSException var25) {
                    System.out.println("Receiver:Connection could not be closed.");
                }
            }

        }

        return response;
    }

    public static void main(String[] args) throws Exception {
        SansConfig config = new SansConfig("sans.config");
        SansQueue sansQueue = new SansQueue(config);
        System.out.println(sansQueue.readFromMQ());
    }
}
