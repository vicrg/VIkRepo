
package sans;

public class SansResponseModel {
    private String data = null;
    private String name = null;
    private int beginIndex = -1;
    private int endIndex = -1;
    private boolean indexIsWithHeader = false;

    public SansResponseModel(String name, int beginIndex, int endIndex, boolean indexIsWithHeader) {
        this.name = name;
        this.indexIsWithHeader = indexIsWithHeader;
        if (indexIsWithHeader) {
            this.beginIndex = beginIndex - 1;
            this.endIndex = endIndex;
        } else {
            this.beginIndex = beginIndex + 5;
            this.endIndex = endIndex + 6;
        }

    }

    public String parse(String message) {
        this.data = message.substring(this.beginIndex, this.endIndex);
        if (this.indexIsWithHeader) {
            System.out.println((this.name + "                                                 ").substring(0, 50) + "[" + (this.beginIndex + 1) + "," + this.endIndex + "] = [" + this.data.length() + "][" + this.data + "]");
        } else {
            System.out.println((this.name + "                                                 ").substring(0, 50) + "[" + (this.beginIndex - 5) + "," + (this.endIndex - 6) + "] = [" + this.data.length() + "][" + this.data + "]");
        }

        return this.data;
    }

    public String toString() {
        return this.data;
    }

    public static void main(String[] args) {
    }
}
