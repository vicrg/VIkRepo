package sans;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;

public class Sans {
    public SansConfig config = null;
    SansQueue sansQueue = null;
    public HashMap<String, String> txnSent = new HashMap();
    HashMap<String, String> transax = new HashMap();

    public Sans(String configPath) throws Exception {
        this.config = new SansConfig(configPath);
        this.sansQueue = new SansQueue(this.config);
    }

    public Connection getDBConnection() throws Exception {
        Class.forName("oracle.jdbc.driver.OracleDriver");
        Connection connection = null;
        connection = DriverManager.getConnection(this.config.DBConnStr, this.config.DBUserName, this.config.DBPassword);
        return connection;
    }

    public int setDBInsertClientes(Connection conn, String cuenta, String tipoCuenta, String numCliente, String nombreCliente, String rfc, String idMessage, String transax) throws Exception {
        PreparedStatement stmt = null;
        stmt = conn.prepareStatement("INSERT INTO CLOUDAPP.CDAS_BANXICO_016  (NUMERO_CUENTA, TIPO_CUENTA, NUMERO_CLIENTE, NOMBRE_CLIENTE, RFC_CLIENTE, ID_MENSAJE, CADENA_016) VALUES (?,?,?,?,?,?,?)");
        stmt.setString(1, cuenta);
        stmt.setString(2, tipoCuenta);
        stmt.setString(3, numCliente);
        stmt.setString(4, nombreCliente);
        stmt.setString(5, rfc);
        stmt.setString(6, idMessage);
        stmt.setString(7, transax);
        int recordsAffected = stmt.executeUpdate();
        this.sop("Records Affected : " + recordsAffected);
        stmt.close();
        return recordsAffected;
    }

    public int setDBStatusUpdate(Connection conn, String TxnId, String status) throws Exception {
        Statement stmt = null;
        String query = "UPDATE CLOUDAPP.CDAS_UNIQ_BANXICO_BENEF SET ESTATUS = '" + status + "' WHERE ID= '" + TxnId + "'";
        this.sop(query);
        stmt = conn.createStatement();
        int recordsAffected = stmt.executeUpdate(query);
        this.sop("Records Affected : " + recordsAffected);
        stmt.close();
        return recordsAffected;
    }

    public void sop(Object msg) {
        if (this.config == null) {
            System.out.println(msg);
        } else {
            System.out.println(this.config.AppName + ":" + msg);
        }

    }

    public void doSend() throws Exception {
        try {
            this.guardaDb();
        } catch (Exception var2) {
            var2.printStackTrace();
        }

    }

    public void doRecv() throws Exception {
        Connection conn = null;

        try {
            this.sop("-----------------------STARTING-----------------------");
            this.sop("-----------------------GET RESPONSE FROM QUEUE-----------------------");
            new ArrayList();
            ArrayList<String> response = this.sansQueue.readFromMQ();
            this.sop("Received Responses : " + response.size());
            if (response.size() > 0) {
                this.sop("-----------------------CONNECTING TO DB-----------------------");
                conn = this.getDBConnection();

                for(int i = 0; i < response.size(); ++i) {
                    new SansResponseSuccessFormat();
                    String originalMessage = (String)response.get(i);
                    String message = "cadena original " + (String)response.get(i);
                    boolean noExiste = false;
                    boolean datIncorrectos = false;
                    String cuenta = "";
                    String tipoCuenta = "";
                    String numCliente = "";
                    String nombreCliente = "";
                    String rfc = "";
                    String idMessage = "";
                    String cadenaCompleta = "";
                    this.sop("-----------------------RESPONSE FROM CDAS-----------------------");
                    this.sop("[" + message + "]");
                    this.sop("-----------------------PARSING RESPONSE-----------------------");
                    noExiste = originalMessage.contains("REGISTRO NO EXISTE EN LA BASE CONT.");
                    datIncorrectos = originalMessage.contains("DATOS");
                    if (!noExiste && !datIncorrectos && message.length() > 300) {
                        cuenta = message.substring(169, 181);
                        tipoCuenta = message.substring(68, 70);
                        numCliente = message.substring(169, 181);
                        nombreCliente = message.substring(181, 220).trim();
                        rfc = message.substring(374, 387);
                        idMessage = message.substring(114, 122);
                        cadenaCompleta = message.substring(0, 450).replace("cadena original ", "");
                        this.setDBStatusUpdate(conn, idMessage, "1");
                    }

                    this.sop("RESPONSE RECEIVED FROM CDAS: [" + originalMessage + "]");
                    if (!cuenta.equals("") && !rfc.equals("")) {
                        this.transax.put(cuenta, tipoCuenta + "|" + numCliente + "|" + nombreCliente + "|" + rfc + "|" + idMessage + "|" + cadenaCompleta);
                        this.guardaDb();
                    } else {
                        this.sop("-----------------------ERRRRRRRRRRRRRRRRRRRRRRRR-----------------------");
                        if (originalMessage.length() > 122) {
                            idMessage = message.substring(114, 122);
                        }

                        if (noExiste && !datIncorrectos) {
                            idMessage = message.substring(114, 122);
                            this.setDBStatusUpdate(conn, idMessage, "2");
                        } else if (!noExiste && datIncorrectos) {
                            this.setDBStatusUpdate(conn, idMessage, "3");
                        } else {
                            this.setDBStatusUpdate(conn, idMessage, "4");
                        }
                    }
                }
            }
        } catch (Exception var24) {
            var24.printStackTrace();
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (Exception var23) {
                    this.sop("Connection could not be closed.");
                }
            }

        }

    }

    public void guardaDb() throws Exception {
        Connection conn = null;
        String cuenta = "";
        String tipoCuenta = "";
        String numCliente = "";
        String nombreCliente = "";
        String rfc = "";
        String idMessage = "";
        String tranx = "";

        try {
            conn = this.getDBConnection();
            if (this.transax.size() > 0) {
                Iterator var10 = this.transax.entrySet().iterator();

                while(var10.hasNext()) {
                    Entry<String, String> entry = (Entry)var10.next();
                    cuenta = (String)entry.getKey();
                    String[] parts = ((String)entry.getValue()).split("\\|");
                    tipoCuenta = parts[0];
                    numCliente = parts[1];
                    nombreCliente = parts[2];
                    rfc = parts[3];
                    idMessage = parts[4];
                    tranx = parts[5].trim();
                    this.sop("CDAS PARSING:-----------------------SEND TO DB CLIENTES16-----------------------");
                    this.setDBInsertClientes(conn, cuenta, tipoCuenta, numCliente, nombreCliente, rfc, idMessage, tranx);
                    this.transax.remove(cuenta);
                }
            } else {
                this.sop("Mapa Buffer vacio ->" + this.transax.size());
            }
        } catch (Exception var20) {
            var20.printStackTrace();
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (Exception var19) {
                    this.sop("Connection could not be closed.");
                }
            }

        }

    }

    public static void main(String[] args) throws Exception {
        Sans sans = new Sans("sans.config");

        while(true) {
            sans.doRecv();
            Thread.sleep((long)(Integer.parseInt(sans.config.IntervalInSeconds) * 1000));
        }
    }
}
