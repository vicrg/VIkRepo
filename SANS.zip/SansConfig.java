
package sans;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

public class SansConfig {
    public String AppName = null;
    public String IntervalInSeconds = null;
    public String DBConnStr = null;
    public String DBUserName = null;
    public String DBPassword = null;
    public String SANSOutQueueManager = null;
    public String SANSOutQueue = null;
    public String SANSOutQueueServer = null;
    public String SANSOutQueuePort = null;
    public String SANSOutQueueChannel = null;
    public String SANSOutQueueUser = null;
    public String SANSOutQueuePassword = null;
    public String SANSOutQueueReplyTo = null;
    public String SANSInQueueManager = null;
    public String SANSInQueue = null;
    public String SANSInQueueServer = null;
    public String SANSInQueuePort = null;
    public String SANSInQueueChannel = null;
    public String SANSInQueueUser = null;
    public String SANSInQueuePassword = null;
    public String SANSInQueueReplyTo = null;

    public SansConfig(String configPath) throws Exception {
        Properties prop = new Properties();
        InputStream input = null;
        input = new FileInputStream(configPath);
        prop.load(input);
        this.AppName = this.getProperty(prop, "AppName", true);
        this.IntervalInSeconds = this.getProperty(prop, "IntervalInSeconds", true);
        this.DBConnStr = this.getProperty(prop, "DBConnStr", true);
        this.DBUserName = this.getProperty(prop, "DBUserName", true);
        this.DBPassword = this.getProperty(prop, "DBPassword", true);
        this.SANSOutQueueManager = this.getProperty(prop, "SANSOutQueueManager", true);
        this.SANSOutQueue = this.getProperty(prop, "SANSOutQueue", true);
        this.SANSOutQueueServer = this.getProperty(prop, "SANSOutQueueServer", true);
        this.SANSOutQueuePort = this.getProperty(prop, "SANSOutQueuePort", true);
        this.SANSOutQueueChannel = this.getProperty(prop, "SANSOutQueueChannel", true);
        this.SANSOutQueueReplyTo = this.getProperty(prop, "SANSOutQueueReplyTo", true);
        this.SANSInQueueManager = this.getProperty(prop, "SANSInQueueManager", true);
        this.SANSInQueue = this.getProperty(prop, "SANSInQueue", true);
        this.SANSInQueueServer = this.getProperty(prop, "SANSInQueueServer", true);
        this.SANSInQueuePort = this.getProperty(prop, "SANSInQueuePort", true);
        this.SANSInQueueChannel = this.getProperty(prop, "SANSInQueueChannel", true);
        input.close();
    }

    public String getProperty(Properties prop, String name, boolean print) {
        String value = prop.getProperty(name);
        if (print) {
            System.out.println(name + "=" + value);
        }

        return value;
    }
}
