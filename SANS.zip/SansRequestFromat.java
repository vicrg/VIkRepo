
package sans;

import java.text.DecimalFormat;

public class SansRequestFromat {
    private String txnId = null;
    private String PREFIJO_DEL_HEADER_X_01 = "F";
    private String PREFIJO_APLICACION_DESTINO_X_01 = "0";
    private String CSI_DESTINO_9_02 = "32";
    private String NUMERO_DE_ESTACION_LSN_X_04 = "0001";
    private String TIPO_DE_TERMINAL_X_01 = "Y";
    private String SUCURSAL_9_04 = "9855";
    private String PRIVILEGIO_DE_TERMINAL_X_01 = "U";
    private String CAJA_X_02 = "01";
    private String CSI_ORIGEN_9_02 = "32";
    private String NODO_ORIGEN_9_02 = "32";
    private String FACULTAD_DE_TERMINALISTA_X_02 = "0G";
    private String PREFIJO_DE_APLICACION_ORIGEN_X_01 = "0";
    private String RESULTADO_9_02 = "07";
    private String NOMBRE_DE_MASCARA_X_05 = "     ";
    private String CVE_DE_SEGURIDAD_DEL_OPERADOR_X_06 = "      ";
    private String PREFIJO_AMPLIADO_DESTINO_9_06 = "047010";
    private String PREFIJO_AMPLIADO_ORIGEN_9_06 = "026417";
    private String DESTINO_SISTEMA_9_04 = "0470";
    private String DESTINO_CODIGO_DE_SERVICIO_9_02 = "02";
    private String DESTINO_SUBCODIGO_DE_SERVICIO_9_03 = "001";
    private String ORIGEN_SISTEMA_9_04 = "0264";
    private String ORIGEN_CODIGO_DE_SERVICIO_9_02 = "17";
    private String ORIGEN_SUBCODIGO_DE_SERVICIO_9_03 = "999";
    private String DIRECCION_9_01 = "1";
    private String LONGITUD_DE_MENSAJE_9_04 = "0544";
    private String TIEMPO_DE_ESPERA_9_05 = "00090";
    private String RESULTADO_DE_ICA_9_02 = "00";
    private String IDENTIFICACION_9_02 = "00";
    private String RECONOCIMIENTO_9_01 = "0";
    private String VERSION_DEL_FORMATO_X_01 = "B";
    private String CLASE_DE_MENSAJE_9_01 = "0";
    private String RESULTADO_9_01 = "0";
    private String MODO_DE_OPERAR_9_01 = "1";
    private String ENTIDAD_ORIGEN_9_04 = "0100";
    private String CAJA_ORIGEN_X_03 = "A59";
    private String NUMERO_DE_TRANSACCION_9_08 = "70000001";
    private String D_FECHA_HORA_DE_GENERACION_9_12 = "51213050030";
    private String MODALIDAD_9_02 = "01";
    private String IDENTIFICADOR_DEL_OPERADOR_X_10 = "0000000000";
    private String VERSION_DE_DATOS_OPCIONALES_X_01 = "B";
    private String Country_X_02 = "MX";
    private String Legal_vehicle_X_10 = "Banamex   ";
    private String Agency_X_10 = "0870      ";
    private String User_X_10 = "S264-6601 ";
    private String Proceso_X_10 = "S264      ";
    private String Subproceso_X_10 = "17        ";
    private String Clave_de_transaccion_X_15 = "000000000006601";
    private String Otros_X_30 = "                              ";
    private String Customer_number_9_12 = "000000000000";
    private String Approval_number_9_12 = "000000000000";
    private String D_Reference_number_X_30 = "000000000000000000000100000001";
    private String D_Process_date_X_08 = "20131205";
    private String D_Process_time_X_08 = "53030000";
    private String Attempt_9_04 = "0001";
    private String Sim_flag_X_01 = "N";
    private String D_Name_X_200 = "MAXIMINA,GARCIA/ARELLANO                                                                                                                                                                                ";
    private String I_E_X_01 = "E";
    private String D_Date_of_birth_X_08 = "        ";
    private String Id_number_X_30 = "NO                            ";
    private String Nationality_X_02 = "  ";
    private String D_Detalle_del_concepto_X_1_40 = "<C00><C70DE>TRANSF DE NOMINA ART 18     ";
    private String tag_inicio_texto_libre_X_04 = "<C00>";
    private String tag_inicio_de_detalle_de_concepto_X_07 = "<C70DE>";
    private String D_Detalle_del_concepto_X_2_40 = "TRANSF DE NOMINA ART 18                                                                                                                                                                                           ";
    private String tag_fin_de_detalle_de_concepto_X_08 = "</C70DE>";
    private String tag_inicio_campo_Importe_de_la_Operacion_Original_X_07 = "<C33BI>";
    private String D_Importe_de_la_Operacion_Original_X_21 = "2160";
    private String tag_fin_campo_Importe_de_la_Operacion_Original_X_08 = "</C33BI>";
    private String tag_inicio_moneda_X_07 = "<C33BM>";
    private String descripcion_de_moneda_X_12 = "USD";
    private String tag_fin_moneda_X_08 = "</C33BM>";
    private String Tag_Fin_texto_libre_X_06 = "</C00>";

    public SansRequestFromat() {
    }

    public String getTxnId() {
        return this.txnId;
    }

    public void setTxnId(String txnId) {
        this.txnId = txnId;
    }

    public String getMessage() {
        String message = this.PREFIJO_DEL_HEADER_X_01 + this.PREFIJO_APLICACION_DESTINO_X_01 + this.CSI_DESTINO_9_02 + this.NUMERO_DE_ESTACION_LSN_X_04 + this.TIPO_DE_TERMINAL_X_01 + this.SUCURSAL_9_04 + this.PRIVILEGIO_DE_TERMINAL_X_01 + this.CAJA_X_02 + this.CSI_ORIGEN_9_02 + this.NODO_ORIGEN_9_02 + this.FACULTAD_DE_TERMINALISTA_X_02 + this.PREFIJO_DE_APLICACION_ORIGEN_X_01 + this.RESULTADO_9_02 + this.NOMBRE_DE_MASCARA_X_05 + this.CVE_DE_SEGURIDAD_DEL_OPERADOR_X_06 + this.PREFIJO_AMPLIADO_DESTINO_9_06 + this.PREFIJO_AMPLIADO_ORIGEN_9_06 + this.DESTINO_SISTEMA_9_04 + this.DESTINO_CODIGO_DE_SERVICIO_9_02 + this.DESTINO_SUBCODIGO_DE_SERVICIO_9_03 + this.ORIGEN_SISTEMA_9_04 + this.ORIGEN_CODIGO_DE_SERVICIO_9_02 + this.ORIGEN_SUBCODIGO_DE_SERVICIO_9_03 + this.DIRECCION_9_01 + this.LONGITUD_DE_MENSAJE_9_04 + this.TIEMPO_DE_ESPERA_9_05 + this.RESULTADO_DE_ICA_9_02 + this.IDENTIFICACION_9_02 + this.RECONOCIMIENTO_9_01 + this.VERSION_DEL_FORMATO_X_01 + this.CLASE_DE_MENSAJE_9_01 + this.RESULTADO_9_01 + this.MODO_DE_OPERAR_9_01 + this.ENTIDAD_ORIGEN_9_04 + this.CAJA_ORIGEN_X_03 + this.NUMERO_DE_TRANSACCION_9_08 + this.D_FECHA_HORA_DE_GENERACION_9_12 + this.MODALIDAD_9_02 + this.IDENTIFICADOR_DEL_OPERADOR_X_10 + this.VERSION_DE_DATOS_OPCIONALES_X_01 + this.Country_X_02 + this.Legal_vehicle_X_10 + this.Agency_X_10 + this.User_X_10 + this.Proceso_X_10 + this.Subproceso_X_10 + this.Clave_de_transaccion_X_15 + this.Otros_X_30 + this.Customer_number_9_12 + this.Approval_number_9_12 + this.D_Reference_number_X_30 + this.D_Process_date_X_08 + this.D_Process_time_X_08 + this.Attempt_9_04 + this.Sim_flag_X_01 + this.D_Name_X_200 + this.I_E_X_01 + this.D_Date_of_birth_X_08 + this.Id_number_X_30 + this.Nationality_X_02 + this.tag_inicio_texto_libre_X_04 + this.tag_inicio_de_detalle_de_concepto_X_07 + "       SANS N  I                                                                                                                                                                                                  " + this.tag_fin_de_detalle_de_concepto_X_08 + this.tag_inicio_campo_Importe_de_la_Operacion_Original_X_07 + this.D_Importe_de_la_Operacion_Original_X_21 + this.tag_fin_campo_Importe_de_la_Operacion_Original_X_08 + this.tag_inicio_moneda_X_07 + this.descripcion_de_moneda_X_12 + this.tag_fin_moneda_X_08 + this.Tag_Fin_texto_libre_X_06;
        (new StringBuilder("H1")).append(String.format("%04d", message.length() + 6)).append(message).toString();
        message = this.Country_X_02 + this.Legal_vehicle_X_10 + this.Agency_X_10 + this.User_X_10 + this.Proceso_X_10 + this.Subproceso_X_10 + this.Clave_de_transaccion_X_15 + this.Otros_X_30 + this.Customer_number_9_12 + this.Approval_number_9_12 + this.D_Reference_number_X_30 + this.D_Process_date_X_08 + this.D_Process_time_X_08 + this.Attempt_9_04 + this.Sim_flag_X_01 + this.D_Name_X_200 + this.I_E_X_01 + this.D_Date_of_birth_X_08 + this.Id_number_X_30 + this.Nationality_X_02 + this.tag_inicio_texto_libre_X_04 + this.tag_inicio_de_detalle_de_concepto_X_07 + this.D_Detalle_del_concepto_X_2_40 + this.tag_fin_de_detalle_de_concepto_X_08 + this.tag_inicio_campo_Importe_de_la_Operacion_Original_X_07 + this.D_Importe_de_la_Operacion_Original_X_21 + this.tag_fin_campo_Importe_de_la_Operacion_Original_X_08 + this.tag_inicio_moneda_X_07 + this.descripcion_de_moneda_X_12 + this.tag_fin_moneda_X_08 + this.Tag_Fin_texto_libre_X_06;
        return message;
    }

    public void setD_FECHA_HORA_DE_GENERACION_9_12(String d_FECHA_HORA_DE_GENERACION_9_12) {
        this.D_FECHA_HORA_DE_GENERACION_9_12 = d_FECHA_HORA_DE_GENERACION_9_12;
    }

    public void setD_Reference_number_X_30(String d_Reference_number_X_30) {
        d_Reference_number_X_30 = "000000000000000000000000000000" + d_Reference_number_X_30;
        this.D_Reference_number_X_30 = d_Reference_number_X_30.substring(d_Reference_number_X_30.length() - 30);
    }

    public void setD_Process_date_X_08(String d_Process_date_X_08) {
        this.D_Process_date_X_08 = d_Process_date_X_08;
    }

    public void setD_Process_time_X_08(String d_Process_time_X_08) {
        this.D_Process_time_X_08 = d_Process_time_X_08;
    }

    public void setD_Name_X_200(String d_Name_X_200) {
        d_Name_X_200 = d_Name_X_200 + "                                                                                                                                                                                                        ";
        this.D_Name_X_200 = d_Name_X_200.substring(0, 200);
    }

    public void setD_Date_of_birth_X_08(String d_Date_of_birth_X_08) {
        this.D_Date_of_birth_X_08 = d_Date_of_birth_X_08;
    }

    public void setD_Detalle_del_concepto_X_1_40(String d_Detalle_del_concepto_X_1_40) {
        d_Detalle_del_concepto_X_1_40 = d_Detalle_del_concepto_X_1_40 + "                                        ";
        this.D_Detalle_del_concepto_X_1_40 = d_Detalle_del_concepto_X_1_40.substring(0, 40);
    }

    public void setD_Detalle_del_concepto_X_2_40(String d_Detalle_del_concepto_X_2_40) {
        d_Detalle_del_concepto_X_2_40 = d_Detalle_del_concepto_X_2_40 + "                                                                                                                                                                                                                  ";
        this.D_Detalle_del_concepto_X_2_40 = d_Detalle_del_concepto_X_2_40.substring(0, 210);
    }

    public void setD_Importe_de_la_Operacion_Original_X_21(String d_Importe_de_la_Operacion_Original_X_21) {
        double d = Double.parseDouble(d_Importe_de_la_Operacion_Original_X_21);
        this.D_Importe_de_la_Operacion_Original_X_21 = (new DecimalFormat("##.00")).format(d);
    }

    public String getTrace() {
        String message = "D_Reference_number_X_30 = " + this.D_Reference_number_X_30 + ", " + "D_Process_date_X_08" + " = " + this.D_Process_date_X_08 + ", " + "D_Process_time_X_08" + " = " + this.D_Process_time_X_08 + ", " + "D_Name_X_200" + " = " + this.D_Name_X_200 + ", " + "D_Date_of_birth_X_08" + " = " + this.D_Date_of_birth_X_08 + ", " + "D_Detalle_del_concepto_X_1_40" + " = " + this.D_Detalle_del_concepto_X_1_40 + ", " + "D_Detalle_del_concepto_X_2_40" + " = " + this.D_Detalle_del_concepto_X_2_40 + ", " + "D_Importe_de_la_Operacion_Original_X_21" + " = " + this.D_Importe_de_la_Operacion_Original_X_21;
        return message;
    }
}
