package bnmx.mq;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.StringReader;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.jms.JMSException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;



public class salida {
	private String adena;
	private String key;
	
	  salidaQueue cdasQueue = null;
	  public HashMap<String, String> txnSent = new HashMap();
	  SimpleDateFormat dateFormat = new SimpleDateFormat("yyMMdd");
	  Date fecha = new Date();
	  SimpleDateFormat horaFormat = new SimpleDateFormat("HHmmss");
	  Date hora = new Date();
	  String strCuenta = null;
	  String strIdOper = null;
	  String strNumSuc = null;
	  String numCta = null;
	  String strTranId = null;
	  String StartEstatus = null;
	  String IncrementInterval = null;
	  String CtaTypeOne = null;
	  String CtaTypeTwo = null;
	  String StartId = null;
	  static String inicio = null;
	  int iCount;
	  int iTotal = 0;
	
	public salidaConfig config = null;
	salidaQueue sansQueue = null;
	  HashMap<String, String> transax = new HashMap<String, String>();

	public salida(String configPath) throws Exception {
		config = new salidaConfig(configPath);
		sansQueue = new salidaQueue(config);
	}

	public Connection getDBConnection() throws Exception {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection connection = null;
		connection = DriverManager.getConnection(this.config.DBConnStr,
				this.config.DBUserName, this.config.DBPassword);

		return connection;
	}

	
	public int setDBInsertClientes(Connection conn)
			throws Exception {
		
		//String nombreClie = null;
		//String transaxion;
		//sop("------- Nombre " + nombreClie );
		
		//nombreClie = nombreCliente.replace("\'" ,"'");
		//transaxion = transax.replace("\'", "'" );
		 PreparedStatement stmt = null;
		
		//sop(query);
		// Primer proceso
		//stmt = conn.prepareStatement("INSERT INTO CLOUDAPP.CDA_CTES_016 (NUMERO_CUENTA, TIPO_CUENTA, NUMERO_CLIENTE, NOMBRE_CLIENTE, RFC_CLIENTE, ID_MENSAJE, CADENA_016) VALUES (?,?,?,?,?,?,?)");
		//stmt = conn.prepareStatement("INSERT INTO CLOUDAPP.CDA_CTES_CUT_016  (NUMERO_CUENTA, TIPO_CUENTA, NUMERO_CLIENTE, NOMBRE_CLIENTE, RFC_CLIENTE, ID_MENSAJE, CADENA_016) VALUES (?,?,?,?,?,?,?)");
		 stmt = conn.prepareStatement("SELECT  B01_CDA_OPA_CVE, B01_CDA_FECHA, B01_CDA_TRACKINGKEY, B01_CDA_BANKID, B01_CDA_STATUS, B01_CDA_PAYMENTTYPENUMBER, B01_CDA_OPERATIONALDATESTAMP,B01_CDA_OPERATIONALDATE,B01_CDA_OPERATIONALHOUR,B01_CDA_CDABANKSENDERID,B01_CDA_BANKSENDERNAME,B01_CDA_CUSTOMERSENDERNAME,B01_CDA_CUSTOMERSENDERTYPEACC,B01_CDA_CUSTOMERSENDERACCNUM,B01_CDA_CUSTOMERSENDERID,B01_CDA_BENEFICIARYBANKNAME,B01_CDA_CUSTOMERBENEFNAME,B01_CDA_CUSTOMERBENEFTYPEACC,B01_CDA_CUSTOMERBENEFACCNUM,B01_CDA_CUSTOMERBENEFICIARYID,B01_CDA_PAYMENTDESCRIPTION,B01_CDA_PAYMENTTAXAMMOUNT,B01_CDA_PAYMENTAMMOUNT,B01_CDA_CERTIFICATENUMBER,B01_CDA_PAYMENTPACKAGENUMBER,B01_CDA_PAYMENTOPERATIONNUMBER,B01_CDA_DIGITALSIGNATURE WHERE B01_CDA_STATUS = '3'");
		 
		
		
		return 0;
	}

	public int setDBStatusUpdate(Connection conn, String TxnId, String status )
			throws Exception {
		Statement stmt = null;
		//Primer Proceso
		//String query = "UPDATE CLOUDAPP.CTAS_UNIQ_CHENTE SET ESTATUS = '" +  status  + "' WHERE ID= '"+ TxnId  + "'";
		//String query = "UPDATE CLOUDAPP.CTAS_UNIQ_CUT SET ESTATUS = '" +  status  + "' WHERE ID= '"+ TxnId  + "'";
		String query = "UPDATE CLOUDAPP.CDAS_UNIQ_BANXICO_BENEF SET ESTATUS = '" +  status  + "' WHERE ID= '"+ TxnId  + "'";
		sop(query);
		stmt = conn.createStatement();
		int recordsAffected = stmt.executeUpdate(query);
		sop("Records Affected : " + recordsAffected);
		stmt.close();
		return recordsAffected;
	}


	public void sop(Object msg) {
		if (this.config == null) {
			System.out.println(msg);
		} else {
			System.out.println(this.config.AppName + ":" + msg);
		}
	}

	/*public void doSend() throws Exception {
		
		try {
			guardaDb();
		} catch (Exception ex) {
			ex.printStackTrace();
		} 
	}*/
	
	public void doSend(int count) throws Exception {
		Connection conn = null;
		try {
			
			sop("-----------------------STARTING-----------------------");
			sop("-----------------------CONNECTING TO DB-----------------------");
			conn = getDBConnection();
			sop("-----------------------QUEUE PAYMENTS FOR Cdas-----------------------");
			sop("-----------------------GET PAYMENTS FROM DB-----------------------");
			ArrayList<CdasRequestFromat> payments = getDBCdas(conn,count);

			if (payments != null && payments.size() > 0) {
				sop("-----------------------SENDING TO Cdas QUEUE - "
						+ config.SANSOutQueueManager + "/"
						+ config.SANSOutQueue);

				ArrayList<String> requests = new ArrayList<String>();
				for (int i = 0; i < payments.size(); i++) {
					CdasRequestFromat p = payments.get(i);
					requests.add(p.getMessage());
					//sop(" -> Cdas [" + p.getMessage() + "]");
					
				}

				sansQueue.connectionMQ();
				ArrayList<String> requestStats = sansQueue.sendToMQ(requests);

				for (int i = 0; i < requests.size(); i++) {
					

					if (requestStats.get(i) == "SENT") {
						//sop("Transaction Id=" + i + ", Status="
						//		+ "SENT");
					} else {
						sop("Transaction Id=" + i + ", Status="
								+ "ERROR");
					}
					
					//setDBStatusUpdateContinue(conn, p.getTxnId());
				}
				sansQueue.closeMQ();
				sop("TOTAL DE REGISTROS ENVIADOS HASTA EL MOMENTO [ -----" + iTotal+"----]");
			} else {
				sop("No data found");
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (Exception jmsex) {
					sop("Connection could not be closed.");
				}
			}
		}
	}


	
	public void guardaDb() throws Exception{
		Connection conn = null;
		String cuenta = "";
		String tipoCuenta = "";
		String numCliente = "";
		String nombreCliente = "";
		String rfc ="";
		String idMessage ="";
		String tranx  ="";
		
		try {
			conn = getDBConnection();
			
			if (transax.size()>0){
				//transax.forEach((k,v) -> System.out.println("Key: " + k + ": Value: " + v));
				
//				for (Map.Entry<String, String> entry : transax.entrySet()) {
//				    //System.out.println("clave=" + entry.getKey() + ", valor=" + entry.getValue());
//					cuenta = entry.getKey();
//					String[] parts = entry.getValue().split("\\|");
//					tipoCuenta = parts [0];
//					numCliente = parts [1];
//					nombreCliente = parts [2];
//					rfc = parts [3];
//					idMessage = parts [4];
//					tranx = parts [5].trim();
//					sop("CDAS PARSING:-----------------------SEND TO DB CLIENTES16-----------------------");
					setDBInsertClientes(conn );
//					transax.remove(cuenta);
//					
//				}
			}else{
				sop("Mapa Buffer vacio ->" + transax.size());
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (Exception jmsex) {
					sop("Connection could not be closed.");
				}
			}
		}
		
		
	}


		  
		
		
		
//		while (true) {
//			
//			//sans.doSend();
//			///Thread.sleep(1000);
//			
//			sans.doRecv();
//			//System.out.println("-----------------------SLEEPING FOR "
//				//	+ sans.config.IntervalInSeconds
//				//	+ " SECONDS " + (new Date()) + " -----------------------");
//			Thread.sleep(Integer.parseInt(sans.config.IntervalInSeconds) * 1000);
//			
//
//		}

	
	public static Document loadXMLFromString(String xml) throws Exception
	{
	    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	    DocumentBuilder builder = factory.newDocumentBuilder();
	    InputStream  is = new    ByteArrayInputStream(xml.getBytes());
	    return builder.parse(is);
	}
	
	
	
	
	public ArrayList<CdasRequestFromat> getDBCdas(Connection conn, int count)
			throws Exception {
					Statement stmt = null;
					
					StartEstatus = config.StartEstatus;
					IncrementInterval = config.IncrementInterval;
					CtaTypeOne = config.CtaTypeOne;
					CtaTypeTwo = config.CtaTypeTwo;
			         
					if (count == 0)
					{
						StartId = config.StartId;
						sop("--StartId--"+StartId+"-------------");
					}
					else
					{
						sop("--StartId--"+StartId+"-------------");
					}
					
					String query = "SELECT B01_CDA_OPA_CVE, B01_CDA_FECHA, B01_CDA_TRACKINGKEY, B01_CDA_BANKID, B01_CDA_STATUS, B01_CDA_PAYMENTTYPENUMBER, B01_CDA_OPERATIONALDATESTAMP,B01_CDA_OPERATIONALDATE,B01_CDA_OPERATIONALHOUR,B01_CDA_CDABANKSENDERID,B01_CDA_BANKSENDERNAME,B01_CDA_CUSTOMERSENDERNAME,B01_CDA_CUSTOMERSENDERTYPEACC,B01_CDA_CUSTOMERSENDERACCNUM,B01_CDA_CUSTOMERSENDERID,B01_CDA_BENEFICIARYBANKNAME,B01_CDA_CUSTOMERBENEFNAME,B01_CDA_CUSTOMERBENEFTYPEACC,B01_CDA_CUSTOMERBENEFACCNUM,B01_CDA_CUSTOMERBENEFICIARYID,B01_CDA_PAYMENTDESCRIPTION,B01_CDA_PAYMENTTAXAMMOUNT,B01_CDA_PAYMENTAMMOUNT,B01_CDA_CERTIFICATENUMBER,B01_CDA_PAYMENTPACKAGENUMBER,B01_CDA_PAYMENTOPERATIONNUMBER,B01_CDA_DIGITALSIGNATURE FROM B01_DATA_CDA WHERE B01_CDA_STATUS = '3'";
					
					//String query = "SELECT NUMERO_CUENTA, TIPO_CUENTA, ID FROM CLOUDAPP.CTAS_UNIQ_CHENTE WHERE TIPO_CUENTA IN ("+CtaTypeOne+","+CtaTypeTwo+") AND ESTATUS ="+StartEstatus  
					//		+ " AND ID >" + StartId + " AND ROWNUM <=" + IncrementInterval + " ORDER BY ID";
					//String query = "SELECT NUMERO_CUENTA, TIPO_CUENTA, ID FROM CLOUDAPP.CTAS_UNIQ_CHENTE WHERE ID = 00135471";
					
					
					
								
					ArrayList<CdasRequestFromat> datos_cda = new ArrayList<CdasRequestFromat>();
			
					sop(query);
			
					stmt = conn.createStatement();
					ResultSet rs = stmt.executeQuery(query);

					iCount = 0;
					
					while (rs.next()) {
						
						 key = rs.getString("B01_CDA_PAYMENTPACKAGENUMBER") + rs.getString("B01_CDA_PAYMENTOPERATIONNUMBER") 
									+ rs.getString("B01_CDA_CDABANKSENDERID")   +  rs.getString("B01_CDA_TRACKINGKEY");
						  
						 adena = String.format("%1$-57s",key) 
									+ "||" +  calculaTipoOperacion( rs.getString("B01_CDA_CDABANKSENDERID"),rs.getString("B01_CDA_OPERATIONALHOUR")) + "|" + rs.getString("B01_CDA_OPERATIONALDATE") + "|" + rs.getString("B01_CDA_OPERATIONALDATE") + "|"
									+ rs.getString("B01_CDA_OPERATIONALHOUR") + "|" + rs.getString("B01_CDA_BANKID")  + "|" + rs.getString("B01_CDA_BANKSENDERNAME")  + "|"
									+ rs.getString("B01_CDA_CUSTOMERSENDERNAME")  + "|" + rs.getString("B01_CDA_CUSTOMERSENDERTYPEACC")  + "|"
									+  rs.getString("B01_CDA_CUSTOMERSENDERACCNUM")  + "|" + rs.getString("B01_CDA_CUSTOMERSENDERID")  + "|"
									+ rs.getString("B01_CDA_BENEFICIARYBANKNAME") + "|" + rs.getString("B01_CDA_CUSTOMERBENEFNAME")  + "|"
									+ rs.getString("B01_CDA_CUSTOMERBENEFTYPEACC")   + "|" + rs.getString("B01_CDA_CUSTOMERBENEFACCNUM")  + "|" + rs.getString("B01_CDA_CUSTOMERBENEFICIARYID")  
									+ "|" + rs.getString("B01_CDA_PAYMENTDESCRIPTION")  + "|" + rs.getString("B01_CDA_PAYMENTTAXAMMOUNT")  + "|" +   rs.getString("B01_CDA_PAYMENTAMMOUNT")  +  "|" + rs.getString("B01_CDA_CERTIFICATENUMBER") +"||" + System.lineSeparator();
						
						CdasRequestFromat datos_in = new CdasRequestFromat();
						
						//sop("--Num_CTA DB--"+rs.getString("NUMERO_CUENTA")+"------ID------"+rs.getString("ID")+"-------------");
						
						datos_in.setEnvio(adena);
						datos_cda.add(datos_in);

					}
			        
					
					rs.close();
					stmt.close();
			
					sop("Found records:" + datos_cda.size());
					iTotal = iTotal + datos_cda.size();
					
					return datos_cda;
				}

	  
		public static void main(String[] args) throws Exception {

			salida sans = new salida("CutCdas.config");
		
			
			inicio = sans.config.StartId;
			Integer iCount = 0;
			while (true) {
				sans.doSend(iCount);
				Thread.sleep(1000);

				System.out.println("-----------------------SLEEPING FOR "
						+ sans.config.IntervalInSeconds
						+ " SECONDS " + (new Date()) + " -----------------------");
				Thread.sleep(Integer.parseInt(sans.config.IntervalInSeconds) * 1000);
				iCount =  iCount +1;
				if(iCount % 75 == 0)
				{
					System.out.println("-----------------------SLEEPING FOR 2000 OPERATIONS FOR "
							+ sans.config.IntervalInSeconds
							+ " SECONDS " + (new Date()) + " -----------------------");
					Thread.sleep(Integer.parseInt(sans.config.IntervalInSeconds) * 4000);
				}
				System.out.println(iCount);

			}	 
			
		}
		
		 public String calculaTipoOperacion(String clave, String hora){
	    	  String resulta = "";
	    	  Integer tiempo = new Integer (Integer.parseInt(hora));
	    	  if ((clave.equals("2001")) &&  (tiempo >180000 && tiempo < 240000 )){
	    		  resulta = "12";
	    	  }else{
	    		  resulta = "1";
	    	  }
	    	  
	    	  
	    	  return resulta;
	      }
}
