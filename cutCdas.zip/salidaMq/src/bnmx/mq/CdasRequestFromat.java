package bnmx.mq;

public class CdasRequestFromat
{
  public String envio;
  
  
  
  
  public String getMessage()
  {
    String message = this.envio;
    
    message = "H10012" + message;
    
    return message;
  }




public String getEnvio() {
	return envio;
}




public void setEnvio(String envio) {
	this.envio = envio;
}
}
