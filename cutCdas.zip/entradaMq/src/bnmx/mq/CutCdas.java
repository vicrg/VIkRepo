package bnmx.mq;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.StringReader;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.jms.JMSException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import jdk.internal.org.xml.sax.InputSource;

//Last Updated 28Apr2016 1652 VDI Time
public class CutCdas {
	private String tipoEnvio;
	private String tipoOperacion;
	private String operNum;
	private String folioMco;
	private String fechaOperacion;
	private String horaOperacion;
	private String participanteEmisor;
	private String nombreEmisor;
	private String nombreOrdenante;
	private String tipoCuentaOrdenante;
	private String cuentaOrdenante;
	private String rfcOrdenante;
	private String cveReceptor;
	private String nombreBeneficiario;
	private String tipoCtaBeneficiario;
	private String ctaBeneficiario;
	private String rfcBeneficiario;
	private String conceptoPago;
	private String montoIva;
	private String monto;
	private String serCertificado;
	private String folioPaquete;
	private String folioOrden;
	private String cveRastreo;
	private String cveEmisor;
	private String nomReceptor;
	
	private String nombreCustomers;
	private String idCustomers;
	
	public CutCdasConfig config = null;
	CutCdasQueue sansQueue = null;
	public HashMap<String, String> txnSent = new HashMap<String, String>();		
	  HashMap<String, String> transax = new HashMap<String, String>();

	public CutCdas(String configPath) throws Exception {
		config = new CutCdasConfig(configPath);
		sansQueue = new CutCdasQueue(config);
	}

	public Connection getDBConnection() throws Exception {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection connection = null;
		connection = DriverManager.getConnection(this.config.DBConnStr,
				this.config.DBUserName, this.config.DBPassword);

		return connection;
	}

	
	public int setDBInsertClientes(Connection conn, String estatus)
			throws Exception {
		
		//String nombreClie = null;
		//String transaxion;
		//sop("------- Nombre " + nombreClie );
		
		//nombreClie = nombreCliente.replace("\'" ,"'");
		//transaxion = transax.replace("\'", "'" );
		 PreparedStatement stmt = null;
		
		//sop(query);
		// Primer proceso
		//stmt = conn.prepareStatement("INSERT INTO CLOUDAPP.CDA_CTES_016 (NUMERO_CUENTA, TIPO_CUENTA, NUMERO_CLIENTE, NOMBRE_CLIENTE, RFC_CLIENTE, ID_MENSAJE, CADENA_016) VALUES (?,?,?,?,?,?,?)");
		//stmt = conn.prepareStatement("INSERT INTO CLOUDAPP.CDA_CTES_CUT_016  (NUMERO_CUENTA, TIPO_CUENTA, NUMERO_CLIENTE, NOMBRE_CLIENTE, RFC_CLIENTE, ID_MENSAJE, CADENA_016) VALUES (?,?,?,?,?,?,?)");
		 stmt = conn.prepareStatement("INSERT INTO B01_DATA_CDA  (B01_CDA_OPA_CVE, B01_CDA_FECHA, B01_CDA_TRACKINGKEY, B01_CDA_BANKID, B01_CDA_STATUS, B01_CDA_PAYMENTTYPENUMBER, B01_CDA_OPERATIONALDATESTAMP,B01_CDA_OPERATIONALDATE,B01_CDA_OPERATIONALHOUR,B01_CDA_CDABANKSENDERID,B01_CDA_BANKSENDERNAME,B01_CDA_CUSTOMERSENDERNAME,B01_CDA_CUSTOMERSENDERTYPEACC,B01_CDA_CUSTOMERSENDERACCNUM,B01_CDA_CUSTOMERSENDERID,B01_CDA_BENEFICIARYBANKNAME,B01_CDA_CUSTOMERBENEFNAME,B01_CDA_CUSTOMERBENEFTYPEACC,B01_CDA_CUSTOMERBENEFACCNUM,B01_CDA_CUSTOMERBENEFICIARYID,B01_CDA_PAYMENTDESCRIPTION,B01_CDA_PAYMENTTAXAMMOUNT,B01_CDA_PAYMENTAMMOUNT,B01_CDA_CERTIFICATENUMBER,B01_CDA_PAYMENTPACKAGENUMBER,B01_CDA_PAYMENTOPERATIONNUMBER,B01_CDA_DIGITALSIGNATURE) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
		stmt.setString(1, this.folioMco);
		stmt.setString(2, this.fechaOperacion);
		stmt.setString(3, this.cveRastreo);
		stmt.setString(4, this.cveEmisor);
		//stmt.setString(5, (this.tipoOperacion.equals("1")? "1":"2"));
		stmt.setString(5, estatus);
		stmt.setString(6, this.tipoCuentaOrdenante);
		stmt.setString(7, this.horaOperacion);
		stmt.setString(8, fechaOperacion);
		stmt.setString(9, this.horaOperacion);
		stmt.setString(10, this.participanteEmisor);
		stmt.setString(11, this.nombreEmisor);
		stmt.setString(12, this.nombreOrdenante);
		stmt.setString(13, this.tipoCuentaOrdenante);
		stmt.setString(14, this.cuentaOrdenante);
		stmt.setString(15, this.rfcOrdenante);
		stmt.setString(16, this.cveReceptor);
		stmt.setString(17, this.nombreBeneficiario);
		stmt.setString(18, this.tipoCtaBeneficiario);
		stmt.setString(19, this.ctaBeneficiario);
		stmt.setString(20, this.rfcBeneficiario);
		stmt.setString(21, this.conceptoPago);
		stmt.setString(22, this.montoIva);
		stmt.setString(23, this.monto);
		stmt.setString(24, this.serCertificado);
		stmt.setString(25, this.folioPaquete);
		stmt.setString(26, this.folioOrden);
		stmt.setString(27, "");
		int recordsAffected = stmt.executeUpdate();
		sop("Records Affected : " + recordsAffected);
		stmt.close();
		return recordsAffected;
	}

	public int setDBStatusUpdate(Connection conn, String TxnId, String status )
			throws Exception {
		Statement stmt = null;
		//Primer Proceso
		//String query = "UPDATE CLOUDAPP.CTAS_UNIQ_CHENTE SET ESTATUS = '" +  status  + "' WHERE ID= '"+ TxnId  + "'";
		//String query = "UPDATE CLOUDAPP.CTAS_UNIQ_CUT SET ESTATUS = '" +  status  + "' WHERE ID= '"+ TxnId  + "'";
		String query = "UPDATE CLOUDAPP.CDAS_UNIQ_BANXICO_BENEF SET ESTATUS = '" +  status  + "' WHERE ID= '"+ TxnId  + "'";
		sop(query);
		stmt = conn.createStatement();
		int recordsAffected = stmt.executeUpdate(query);
		sop("Records Affected : " + recordsAffected);
		stmt.close();
		return recordsAffected;
	}
	
	
	public int setExisteDB(Connection conn, String numero  )
			throws Exception {
		Statement stmt = null;
		//Primer Proceso
		String query = "SELECT B02_CTES_CUSTOMERNAME, B02_CTES_CUSTOMERID FROM B02_COSTUMER" + " WHERE B02_CTES_ORIGINALACCOUNTNUMBER= '"+ numero  + "'";
		sop(query);
		
		
		stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery(query);
		int records =0;
		
		
		while (rs.next()) {
			this.nombreCustomers = rs.getString("B02_CTES_CUSTOMERNAME");
			this.idCustomers = rs.getString("B02_CTES_CUSTOMERID");
			records++;
		}
		stmt.close();
		return records;
	}

	public void sop(Object msg) {
		if (this.config == null) {
			System.out.println(msg);
		} else {
			System.out.println(this.config.AppName + ":" + msg);
		}
	}

	public void doSend() throws Exception {
		
		try {
			guardaDb();
		} catch (Exception ex) {
			ex.printStackTrace();
		} 
	}

	public void doRecv() throws Exception {
		Connection conn = null;
		Document xmlDoc = null;
		try {
			sop("-----------------------STARTING-----------------------");

			sop("-----------------------GET RESPONSE FROM QUEUE-----------------------");

			ArrayList<String> response = new ArrayList<String>();

			response = sansQueue.readFromMQ();
			sop("Received Responses : " + response.size());
			//response.add("0001MXBanamex   0870      S264-6503 S264      17        000000000006503                              00000000000000000000000000000000010000000000001409306020161804161257590001NS    AS0                                                                                                                                                                                      00000000010000000000001409152400");

			if (response.size() > 0) {
				sop("-----------------------CONNECTING TO DB-----------------------");
				conn = getDBConnection();

				for (int i = 0; i < response.size(); i++) {
					
					// adding a hardcoded header coz parser is designed to use
					// header but response does not have a header , instead it
					// has 0001 before the message	
					//String originalMessage = response.get(i);
					String originalMessage = response.get(i);
					String message = "cadena original " +response.get(i) ;
					xmlDoc = loadXMLFromString(response.get(i));
					obtenXml(xmlDoc);
					boolean noExiste = false;
					boolean datIncorrectos = false;
					String cuenta = "";
					String tipoCuenta = "";
					String numCliente = "";
					String nombreCliente = "";
					String rfc = "";
					String idMessage="";
					String cadenaCompleta="";
					sop("-----------------------RESPONSE FROM CDAS-----------------------");
					sop("[" + message + "]");
					sop("-----------------------PARSING RESPONSE-----------------------");
					
					noExiste = originalMessage.contains("REGISTRO NO EXISTE EN LA BASE CONT.");
					datIncorrectos = originalMessage.contains("DATOS");
					
					if ((!noExiste) && (!datIncorrectos) && message.length()>300 ){
						//cuenta = message.substring(64,84);
						cuenta = message.substring(169,181);
						tipoCuenta = message.substring(68,70);
						numCliente = message.substring(169,181);
						nombreCliente = message.substring(181,220).trim();
						//rfc = message.substring(358,371);
						rfc = message.substring(374,387);
						idMessage = message.substring(114,122);
						cadenaCompleta=message.substring(0,450).replace("cadena original ", "");
						//setDBStatusUpdate(conn,idMessage ,"1" );
						
					}else {
						 
						
					}
					

					sop("RESPONSE RECEIVED FROM CDAS: [" + originalMessage + "]");
					
					if (cuenta.equals("") || rfc.equals("")) {
						sop("-----------------------ERRRRRRRRRRRRRRRRRRRRRRRR-----------------------");
						if (originalMessage.length() > 122) {
							idMessage = message.substring(114, 122);
						}
						if (noExiste && !datIncorrectos){
							idMessage = message.substring(114,122);
							//setDBStatusUpdate(conn,idMessage ,"2" );
						}else{
							if (!noExiste && datIncorrectos){
								//setDBStatusUpdate(conn,idMessage ,"3" );	
							}else{
								//setDBStatusUpdate(conn,idMessage ,"4" );
							}
							
						}
		
					} else {
							transax.put(cuenta, tipoCuenta+ "|" + numCliente + "|" + nombreCliente+"|"+rfc + "|" + idMessage + "|" + cadenaCompleta);
							guardaDb(); 
					}
			}
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (Exception jmsex) {
					sop("Connection could not be closed.");
				}
			}
		}
	}
	
	public void guardaDb() throws Exception{
		Connection conn = null;
		String cuenta = "";
		String tipoCuenta = "";
		String numCliente = "";
		String nombreCliente = "";
		String rfc ="";
		String idMessage ="";
		String tranx  ="";
		
		try {
			conn = getDBConnection();
			
			if (transax.size()>0){
			
					if (setExisteDB(conn, this.ctaBeneficiario)==0) {
						setDBInsertClientes(conn, "3");
					}else {
						setDBInsertClientes(conn, "1");
					}

			}else{
				sop("Mapa Buffer vacio ->" + transax.size());
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (Exception jmsex) {
					sop("Connection could not be closed.");
				}
			}
		}
		
		
	}

	public static void main(String[] args) throws Exception {

		CutCdas sans = new CutCdas("CutCdas.config");

		while (true) {
			
			//sans.doSend();
			///Thread.sleep(1000);
			
			sans.doRecv();
			//System.out.println("-----------------------SLEEPING FOR "
				//	+ sans.config.IntervalInSeconds
				//	+ " SECONDS " + (new Date()) + " -----------------------");
			Thread.sleep(Integer.parseInt(sans.config.IntervalInSeconds) * 1000);
			

		}
	}
	
	public static Document loadXMLFromString(String xml) throws Exception
	{
	    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	    DocumentBuilder builder = factory.newDocumentBuilder();
	    InputStream  is = new    ByteArrayInputStream(xml.getBytes());
	    return builder.parse(is);
	}
	
	public void obtenXml(Document doc) {
    	String folio= "";
    	String cveRas= "";
        try {

    	doc.getDocumentElement().normalize();
    	NodeList nList = doc.getElementsByTagName("TRANSACCION");

    	for (int temp = 0; temp < nList.getLength(); temp++) {

    		Node nNode = nList.item(temp);

    		if (nNode.getNodeType() == Node.ELEMENT_NODE) {
    			Element eElement = (Element) nNode; 
    			        this.tipoEnvio= eElement.getElementsByTagName("TIPOENVIO").item(0).getTextContent();
    					this.tipoOperacion= eElement.getElementsByTagName("TIPOOPERMCO").item(0).getTextContent();
    					this.operNum=eElement.getElementsByTagName("OPERNUM").item(0).getTextContent();
    					this.folioMco=eElement.getElementsByTagName("FolioMCO").item(0).getTextContent();
    					this.fechaOperacion= eElement.getElementsByTagName("FechaOper").item(0).getTextContent();
    					this.horaOperacion= eElement.getElementsByTagName("HoraOper").item(0).getTextContent();
    					this.participanteEmisor= eElement.getElementsByTagName("PartiEmisor").item(0).getTextContent();
    					this.nombreEmisor= eElement.getElementsByTagName("PartiEmisorOper").item(0).getTextContent();
    					this.nombreOrdenante=  eElement.getElementsByTagName("NombreOrdenante").item(0).getTextContent();
    					this.tipoCuentaOrdenante=  eElement.getElementsByTagName("TipoCtaOrdenante").item(0).getTextContent();
    					this.cuentaOrdenante= eElement.getElementsByTagName("CtaOrdenante").item(0).getTextContent();
    					this.rfcOrdenante=  eElement.getElementsByTagName("RFCOrdenante").item(0).getTextContent();
    					this.cveReceptor= eElement.getElementsByTagName("NombreBeneficiario").item(0).getTextContent();
    					this.nombreBeneficiario= eElement.getElementsByTagName("NombreBeneficiario").item(0).getTextContent();
    					this.tipoCtaBeneficiario= eElement.getElementsByTagName("TipoCtaBeneficiario").item(0).getTextContent();
    					this.ctaBeneficiario= eElement.getElementsByTagName("CtaBeneficiario").item(0).getTextContent();
    					this.rfcBeneficiario= eElement.getElementsByTagName("RFCBeneficiario").item(0).getTextContent();
    					this.conceptoPago= eElement.getElementsByTagName("ConceptoPago").item(0).getTextContent();
    					this.montoIva= eElement.getElementsByTagName("MontoIva").item(0).getTextContent();
    					this.monto= eElement.getElementsByTagName("MontoPago").item(0).getTextContent();
    					this.serCertificado= eElement.getElementsByTagName("Certificado").item(0).getTextContent();
    					this.folioPaquete= eElement.getElementsByTagName("FolioPaquete").item(0).getTextContent();
    					this.folioOrden= eElement.getElementsByTagName("FolioOrden").item(0).getTextContent();
    					this.cveRastreo= eElement.getElementsByTagName("CveRastreo").item(0).getTextContent();
    					//this.cveEmisor= eElement.getElementsByTagName("Cve_Emisor").item(0).getTextContent();
    					//this.nomReceptor= eElement.getElementsByTagName("Nombre_Receptor").item(0).getTextContent();
    		
    		}
    	}
        } catch (Exception e) {
    	e.printStackTrace();
        }
        
      }
}
