package bnmx.mq;

public class CdasRequestFromat
{
  public int ID_Envio;
  private String Hdr_Prefijo = "F";
  private String Hdr_Aplicacion_Destino = "0";
  private String Hdr_CSI_Destino = "10";
  private String Hdr_Num_Estacion = "0001";
  private String Hdr_Tipo = "Y";
  private String Hdr_Departamento = "0264";
  private String Hdr_Privilegios = "P";
  private String Hdr_Secuencial = "01";
  private String Hdr_CSI_Origen = "29";
  private String Hdr_CSI_Original = "29";
  private String Hdr_Seguridad = "G0";
  private String Hdr_Aplicacion_Origen = "0";
  private String Hdr_Tipo_de_Accion = "02";
  private String Hdr_Nombre_Mascara = "00000";
  private String Hdr_Nomina_Encriptada = "000000";
  private String Sa2_Destino = "001644";
  private String Sa2_Origen = "026480";
  private String Sa2_Dest_Aplicacion = "0016";
  private String Sa2_Dest_Codigo = "44";
  private String Sa2_Dest_Subcodigo = "000";
  private String Sa2_Ori_Aplicacion = "0264";
  private String Sa2_Ori_Codigo = "80";
  private String Sa2_Ori_Subcodigo = "000";
  private String Sa2_Direccion = "1";
  private String Sa2_Longitud = "0183";
  private String Sa2_Tiempo_de_Espera = "00180";
  private String Sa2_Codigo_Respuesta = "01";
  private String Sa2_Identificacion_Msg = "000";
  private String Sa2_Version = "B";
  private String Sa2_Clase = "0";
  private String Sa2_Estado = "0";
  private String Sa2_Modo = "1";
  private String Sa2_Iden_Origen = "0264";
  private String Sa2_Iden_Codigo_Origen = "000";
  public String Sa2_Iden_Numero = "";
  public String Sa2_Iden_Fecha = "";
  public String Sa2_Iden_Hora = "";
  private String Sa2_Iden_Modalidad = "22";
  private String Sa2_Iden_Operador = "0000000000";
  private String Sa2_Iden_Version_Mensaje = "A";
  private String Cte_Transaccion = "FDC001";
  private String Cte_Opcion = "0";
  private String Cte_Version = "3";
  private String Cte_Filler = "00000000000000";
  private String Cte_Codigo = "000000000000";
  private String Cte_SubCodigo = "0000";
  private String Cte_SubSubCodigo = "0000";
  public String Cte_Num_Cuenta = "";
  
  public int getID_Envio()
  {
    return this.ID_Envio;
  }
  
  public void setID_Envio(int iD_Envio)
  {
    this.ID_Envio = iD_Envio;
  }
  
  public String getSa2_Iden_Numero()
  {
    return this.Sa2_Iden_Numero;
  }
  
  public void setSa2_Iden_Numero(String sa2_Iden_Numero)
  {
    this.Sa2_Iden_Numero = sa2_Iden_Numero;
  }
  
  public String getSa2_Iden_Fecha()
  {
    return this.Sa2_Iden_Fecha;
  }
  
  public void setSa2_Iden_Fecha(String sa2_Iden_Fecha)
  {
    this.Sa2_Iden_Fecha = sa2_Iden_Fecha;
  }
  
  public String getSa2_Iden_Hora()
  {
    return this.Sa2_Iden_Hora;
  }
  
  public void setSa2_Iden_Hora(String sa2_Iden_Hora)
  {
    this.Sa2_Iden_Hora = sa2_Iden_Hora;
  }
  
  public String getCte_Num_Cuenta()
  {
    return this.Cte_Num_Cuenta;
  }
  
  public void setCte_Num_Cuenta(String cte_Num_Cuenta)
  {
    this.Cte_Num_Cuenta = cte_Num_Cuenta;
  }
  
  public String getMessage()
  {
    String message = this.Hdr_Prefijo + this.Hdr_Aplicacion_Destino + this.Hdr_CSI_Destino + this.Hdr_Num_Estacion + this.Hdr_Tipo + this.Hdr_Departamento + 
      this.Hdr_Privilegios + this.Hdr_Secuencial + this.Hdr_CSI_Origen + this.Hdr_CSI_Original + this.Hdr_Seguridad + this.Hdr_Aplicacion_Origen + 
      this.Hdr_Tipo_de_Accion + this.Hdr_Nombre_Mascara + this.Hdr_Nomina_Encriptada + this.Sa2_Destino + this.Sa2_Origen + this.Sa2_Dest_Aplicacion + 
      this.Sa2_Dest_Codigo + this.Sa2_Dest_Subcodigo + this.Sa2_Ori_Aplicacion + this.Sa2_Ori_Codigo + this.Sa2_Ori_Subcodigo + this.Sa2_Direccion + 
      this.Sa2_Longitud + this.Sa2_Tiempo_de_Espera + this.Sa2_Codigo_Respuesta + this.Sa2_Identificacion_Msg + this.Sa2_Version + this.Sa2_Clase + 
      this.Sa2_Estado + this.Sa2_Modo + this.Sa2_Iden_Origen + this.Sa2_Iden_Codigo_Origen + this.Sa2_Iden_Numero + 
      this.Sa2_Iden_Fecha + this.Sa2_Iden_Hora + this.Sa2_Iden_Modalidad + this.Sa2_Iden_Operador + this.Sa2_Iden_Version_Mensaje + 
      this.Cte_Transaccion + this.Cte_Opcion + this.Cte_Version + this.Cte_Filler + this.Cte_Codigo + this.Cte_SubCodigo + this.Cte_SubSubCodigo + 
      this.Cte_Num_Cuenta;
    
    message = "H10012" + message;
    
    return message;
  }
}
