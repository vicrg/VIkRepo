package bnmx.mq;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.StringReader;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.jms.JMSException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;



public class validacion {
	private String tipoEnvio;
	private String tipoOperacion;
	private String operNum;
	private String folioMco;
	private String fechaOperacion;
	private String horaOperacion;
	private String participanteEmisor;
	private String nombreEmisor;
	private String nombreOrdenante;
	private String tipoCuentaOrdenante;
	private String cuentaOrdenante;
	private String rfcOrdenante;
	private String cveReceptor;
	private String nombreBeneficiario;
	private String tipoCtaBeneficiario;
	private String ctaBeneficiario;
	private String rfcBeneficiario;
	private String conceptoPago;
	private String montoIva;
	private String monto;
	private String serCertificado;
	private String folioPaquete;
	private String folioOrden;
	private String cveRastreo;
	private String cveEmisor;
	private String nomReceptor;
	
	  validacionQueue CdasQueue = null;
	  public HashMap<String, String> txnSent = new HashMap();
	  SimpleDateFormat dateFormat = new SimpleDateFormat("yyMMdd");
	  Date fecha = new Date();
	  SimpleDateFormat horaFormat = new SimpleDateFormat("HHmmss");
	  Date hora = new Date();
	  String strCuenta = null;
	  String strIdOper = null;
	  String strNumSuc = null;
	  String numCta = null;
	  String strTranId = null;
	  String StartEstatus = null;
	  String IncrementInterval = null;
	  String CtaTypeOne = null;
	  String CtaTypeTwo = null;
	  String StartId = null;
	  static String inicio = null;
	  int iCount;
	  int iTotal = 0;
	
	public validacionConfig config = null;
	validacionQueue sansQueue = null;
	  HashMap<String, String> transax = new HashMap<String, String>();

	public validacion(String configPath) throws Exception {
		config = new validacionConfig(configPath);
		sansQueue = new validacionQueue(config);
	}

	public Connection getDBConnection() throws Exception {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection connection = null;
		connection = DriverManager.getConnection(this.config.DBConnStr,
				this.config.DBUserName, this.config.DBPassword);

		return connection;
	}

	
	public int setDBInsertClientes(Connection conn)
			throws Exception {
		
		//String nombreClie = null;
		//String transaxion;
		//sop("------- Nombre " + nombreClie );
		
		//nombreClie = nombreCliente.replace("\'" ,"'");
		//transaxion = transax.replace("\'", "'" );
		 PreparedStatement stmt = null;
		
		//sop(query);
		// Primer proceso
		//stmt = conn.prepareStatement("INSERT INTO CLOUDAPP.CDA_CTES_016 (NUMERO_CUENTA, TIPO_CUENTA, NUMERO_CLIENTE, NOMBRE_CLIENTE, RFC_CLIENTE, ID_MENSAJE, CADENA_016) VALUES (?,?,?,?,?,?,?)");
		//stmt = conn.prepareStatement("INSERT INTO CLOUDAPP.CDA_CTES_CUT_016  (NUMERO_CUENTA, TIPO_CUENTA, NUMERO_CLIENTE, NOMBRE_CLIENTE, RFC_CLIENTE, ID_MENSAJE, CADENA_016) VALUES (?,?,?,?,?,?,?)");
		 stmt = conn.prepareStatement("INSERT INTO B01_DATA_CDA  (B01_CDA_OPA_CVE, B01_CDA_FECHA, B01_CDA_TRACKINGKEY, B01_CDA_BANKID, B01_CDA_STATUS, B01_CDA_PAYMENTTYPENUMBER, B01_CDA_OPERATIONALDATESTAMP,B01_CDA_OPERATIONALDATE,B01_CDA_OPERATIONALHOUR,B01_CDA_CDABANKSENDERID,B01_CDA_BANKSENDERNAME,B01_CDA_CUSTOMERSENDERNAME,B01_CDA_CUSTOMERSENDERTYPEACC,B01_CDA_CUSTOMERSENDERACCNUM,B01_CDA_CUSTOMERSENDERID,B01_CDA_BENEFICIARYBANKNAME,B01_CDA_CUSTOMERBENEFNAME,B01_CDA_CUSTOMERBENEFTYPEACC,B01_CDA_CUSTOMERBENEFACCNUM,B01_CDA_CUSTOMERBENEFICIARYID,B01_CDA_PAYMENTDESCRIPTION,B01_CDA_PAYMENTTAXAMMOUNT,B01_CDA_PAYMENTAMMOUNT,B01_CDA_CERTIFICATENUMBER,B01_CDA_PAYMENTPACKAGENUMBER,B01_CDA_PAYMENTOPERATIONNUMBER,B01_CDA_DIGITALSIGNATURE) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
		stmt.setString(1, this.folioMco);
		stmt.setString(2, this.fechaOperacion);
		stmt.setString(3, this.cveRastreo);
		stmt.setString(4, this.cveEmisor);
		stmt.setString(5, (this.tipoOperacion.equals("1")? "1":"2"));
		stmt.setString(6, this.tipoCuentaOrdenante);
		stmt.setString(7, this.horaOperacion);
		stmt.setString(8, fechaOperacion);
		stmt.setString(9, this.horaOperacion);
		stmt.setString(10, this.participanteEmisor);
		stmt.setString(11, this.nombreEmisor);
		stmt.setString(12, this.nombreOrdenante);
		stmt.setString(13, this.tipoCuentaOrdenante);
		stmt.setString(14, this.cuentaOrdenante);
		stmt.setString(15, this.rfcOrdenante);
		stmt.setString(16, this.cveReceptor);
		stmt.setString(17, this.nombreBeneficiario);
		stmt.setString(18, this.tipoCtaBeneficiario);
		stmt.setString(19, this.ctaBeneficiario);
		stmt.setString(20, this.rfcBeneficiario);
		stmt.setString(21, this.conceptoPago);
		stmt.setString(22, this.montoIva);
		stmt.setString(23, this.monto);
		stmt.setString(24, this.serCertificado);
		stmt.setString(25, this.folioPaquete);
		stmt.setString(26, this.folioOrden);
		stmt.setString(27, "");
		int recordsAffected = stmt.executeUpdate();
		sop("Records Affected : " + recordsAffected);
		stmt.close();
		return recordsAffected;
	}

	public int setDBStatusUpdate(Connection conn, String TxnId, String status )
			throws Exception {
		Statement stmt = null;
		//Primer Proceso
		//String query = "UPDATE CLOUDAPP.CTAS_UNIQ_CHENTE SET ESTATUS = '" +  status  + "' WHERE ID= '"+ TxnId  + "'";
		//String query = "UPDATE CLOUDAPP.CTAS_UNIQ_CUT SET ESTATUS = '" +  status  + "' WHERE ID= '"+ TxnId  + "'";
		String query = "UPDATE CLOUDAPP.CDAS_UNIQ_BANXICO_BENEF SET ESTATUS = '" +  status  + "' WHERE ID= '"+ TxnId  + "'";
		sop(query);
		stmt = conn.createStatement();
		int recordsAffected = stmt.executeUpdate(query);
		sop("Records Affected : " + recordsAffected);
		stmt.close();
		return recordsAffected;
	}


	public void sop(Object msg) {
		if (this.config == null) {
			System.out.println(msg);
		} else {
			System.out.println(this.config.AppName + ":" + msg);
		}
	}

	/*public void doSend() throws Exception {
		
		try {
			guardaDb();
		} catch (Exception ex) {
			ex.printStackTrace();
		} 
	}*/
	
	public void doSend(int count) throws Exception {
		Connection conn = null;
		try {
			
			sop("-----------------------STARTING-----------------------");
			sop("-----------------------CONNECTING TO DB-----------------------");
			conn = getDBConnection();
			sop("-----------------------QUEUE PAYMENTS FOR Cdas-----------------------");
			sop("-----------------------GET PAYMENTS FROM DB-----------------------");
			ArrayList<CdasRequestFromat> payments = getDBCdas(conn,count);

			if (payments != null && payments.size() > 0) {
				sop("-----------------------SENDING TO Cdas QUEUE - "
						+ config.SANSOutQueueManager + "/"
						+ config.SANSOutQueue);

				ArrayList<String> requests = new ArrayList<String>();
				for (int i = 0; i < payments.size(); i++) {
					CdasRequestFromat p = payments.get(i);
					requests.add(p.getMessage());
					//sop(" -> Cdas [" + p.getMessage() + "]");
					
				}

				sansQueue.connectionMQ();
				ArrayList<String> requestStats = sansQueue.sendToMQ(requests);

				for (int i = 0; i < requests.size(); i++) {
					

					if (requestStats.get(i) == "SENT") {
						//sop("Transaction Id=" + i + ", Status="
						//		+ "SENT");
					} else {
						sop("Transaction Id=" + i + ", Status="
								+ "ERROR");
					}
					
					//setDBStatusUpdateContinue(conn, p.getTxnId());
				}
				sansQueue.closeMQ();
				sop("TOTAL DE REGISTROS ENVIADOS HASTA EL MOMENTO [ -----" + iTotal+"----]");
			} else {
				sop("No data found");
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (Exception jmsex) {
					sop("Connection could not be closed.");
				}
			}
		}
	}

	public void doRecv() throws Exception {
		Connection conn = null;
		Document xmlDoc = null;
		try {
			sop("-----------------------STARTING-----------------------");

			sop("-----------------------GET RESPONSE FROM QUEUE-----------------------");

			ArrayList<String> response = new ArrayList<String>();

			response = sansQueue.readFromMQ();
			sop("Received Responses : " + response.size());
			//response.add("0001MXBanamex   0870      S264-6503 S264      17        000000000006503                              00000000000000000000000000000000010000000000001409306020161804161257590001NS    AS0                                                                                                                                                                                      00000000010000000000001409152400");

			if (response.size() > 0) {
				sop("-----------------------CONNECTING TO DB-----------------------");
				conn = getDBConnection();

				for (int i = 0; i < response.size(); i++) {
					
					// adding a hardcoded header coz parser is designed to use
					// header but response does not have a header , instead it
					// has 0001 before the message	
					//String originalMessage = response.get(i);
					String originalMessage = response.get(i);
					String message = "cadena original " +response.get(i) ;
					xmlDoc = loadXMLFromString(response.get(i));
					obtenXml(xmlDoc);
					boolean noExiste = false;
					boolean datIncorrectos = false;
					String cuenta = "";
					String tipoCuenta = "";
					String numCliente = "";
					String nombreCliente = "";
					String rfc = "";
					String idMessage="";
					String cadenaCompleta="";
					sop("-----------------------RESPONSE FROM CDAS-----------------------");
					sop("[" + message + "]");
					sop("-----------------------PARSING RESPONSE-----------------------");
					
					noExiste = originalMessage.contains("REGISTRO NO EXISTE EN LA BASE CONT.");
					datIncorrectos = originalMessage.contains("DATOS");
					
					if ((!noExiste) && (!datIncorrectos) && message.length()>300 ){
						//cuenta = message.substring(64,84);
						cuenta = message.substring(169,181);
						tipoCuenta = message.substring(68,70);
						numCliente = message.substring(169,181);
						nombreCliente = message.substring(181,220).trim();
						//rfc = message.substring(358,371);
						rfc = message.substring(374,387);
						idMessage = message.substring(114,122);
						cadenaCompleta=message.substring(0,450).replace("cadena original ", "");
						//setDBStatusUpdate(conn,idMessage ,"1" );
						
					}else {
						 
						
					}
					

					sop("RESPONSE RECEIVED FROM CDAS: [" + originalMessage + "]");
					
					if (cuenta.equals("") || rfc.equals("")) {
						sop("-----------------------ERRRRRRRRRRRRRRRRRRRRRRRR-----------------------");
						if (originalMessage.length() > 122) {
							idMessage = message.substring(114, 122);
						}
						if (noExiste && !datIncorrectos){
							idMessage = message.substring(114,122);
							//setDBStatusUpdate(conn,idMessage ,"2" );
						}else{
							if (!noExiste && datIncorrectos){
								//setDBStatusUpdate(conn,idMessage ,"3" );	
							}else{
								//setDBStatusUpdate(conn,idMessage ,"4" );
							}
							
						}
		
					} else {
							transax.put(cuenta, tipoCuenta+ "|" + numCliente + "|" + nombreCliente+"|"+rfc + "|" + idMessage + "|" + cadenaCompleta);
							guardaDb(); 
					}
			}
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (Exception jmsex) {
					sop("Connection could not be closed.");
				}
			}
		}
	}
	
	public void guardaDb() throws Exception{
		Connection conn = null;
		String cuenta = "";
		String tipoCuenta = "";
		String numCliente = "";
		String nombreCliente = "";
		String rfc ="";
		String idMessage ="";
		String tranx  ="";
		
		try {
			conn = getDBConnection();
			
			if (transax.size()>0){
				//transax.forEach((k,v) -> System.out.println("Key: " + k + ": Value: " + v));
				
//				for (Map.Entry<String, String> entry : transax.entrySet()) {
//				    //System.out.println("clave=" + entry.getKey() + ", valor=" + entry.getValue());
//					cuenta = entry.getKey();
//					String[] parts = entry.getValue().split("\\|");
//					tipoCuenta = parts [0];
//					numCliente = parts [1];
//					nombreCliente = parts [2];
//					rfc = parts [3];
//					idMessage = parts [4];
//					tranx = parts [5].trim();
//					sop("CDAS PARSING:-----------------------SEND TO DB CLIENTES16-----------------------");
					setDBInsertClientes(conn );
//					transax.remove(cuenta);
//					
//				}
			}else{
				sop("Mapa Buffer vacio ->" + transax.size());
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (Exception jmsex) {
					sop("Connection could not be closed.");
				}
			}
		}
		
		
	}


		  
		
		
		
//		while (true) {
//			
//			//sans.doSend();
//			///Thread.sleep(1000);
//			
//			sans.doRecv();
//			//System.out.println("-----------------------SLEEPING FOR "
//				//	+ sans.config.IntervalInSeconds
//				//	+ " SECONDS " + (new Date()) + " -----------------------");
//			Thread.sleep(Integer.parseInt(sans.config.IntervalInSeconds) * 1000);
//			
//
//		}

	
	public static Document loadXMLFromString(String xml) throws Exception
	{
	    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	    DocumentBuilder builder = factory.newDocumentBuilder();
	    InputStream  is = new    ByteArrayInputStream(xml.getBytes());
	    return builder.parse(is);
	}
	
	public void obtenXml(Document doc) {
    	String folio= "";
    	String cveRas= "";
        try {

    	doc.getDocumentElement().normalize();
    	NodeList nList = doc.getElementsByTagName("TRANSACCION");

    	for (int temp = 0; temp < nList.getLength(); temp++) {

    		Node nNode = nList.item(temp);

    		if (nNode.getNodeType() == Node.ELEMENT_NODE) {
    			Element eElement = (Element) nNode; 
    			        this.tipoEnvio= eElement.getElementsByTagName("TIPOENVIO").item(0).getTextContent();
    					this.tipoOperacion= eElement.getElementsByTagName("TIPOOPER").item(0).getTextContent();
    					this.operNum=eElement.getElementsByTagName("OPERNUM").item(0).getTextContent();
    					this.folioMco=eElement.getElementsByTagName("folio_de_la_operacion_MCO").item(0).getTextContent();
    					this.fechaOperacion= eElement.getElementsByTagName("Fecha_de_Operacion").item(0).getTextContent();
    					this.horaOperacion= eElement.getElementsByTagName("Hora_de_Operacion").item(0).getTextContent();
    					this.participanteEmisor= eElement.getElementsByTagName("Participante_Emisor").item(0).getTextContent();
    					this.nombreEmisor= eElement.getElementsByTagName("Nombre_del_Emisor").item(0).getTextContent();
    					this.nombreOrdenante=  eElement.getElementsByTagName("Nombre_del_Ordenante").item(0).getTextContent();
    					this.tipoCuentaOrdenante=  eElement.getElementsByTagName("Tipo_de_Cta_Ordenante").item(0).getTextContent();
    					this.cuentaOrdenante= eElement.getElementsByTagName("Cuenta_Ordenante").item(0).getTextContent();
    					this.rfcOrdenante=  eElement.getElementsByTagName("RFC_Ordenante").item(0).getTextContent();
    					this.cveReceptor= eElement.getElementsByTagName("Cve_Receptor").item(0).getTextContent();
    					this.nombreBeneficiario= eElement.getElementsByTagName("Nombre_Beneficiario").item(0).getTextContent();
    					this.tipoCtaBeneficiario= eElement.getElementsByTagName("Tipo_de_Cta_Beneficiario").item(0).getTextContent();
    					this.ctaBeneficiario= eElement.getElementsByTagName("Cuenta_Beneficiario").item(0).getTextContent();
    					this.rfcBeneficiario= eElement.getElementsByTagName("RFC_Beneficiario").item(0).getTextContent();
    					this.conceptoPago= eElement.getElementsByTagName("RFC_Beneficiario").item(0).getTextContent();
    					this.montoIva= eElement.getElementsByTagName("Monto_Iva").item(0).getTextContent();
    					this.monto= eElement.getElementsByTagName("Monto_Pago").item(0).getTextContent();
    					this.serCertificado= eElement.getElementsByTagName("Serie_Certificado").item(0).getTextContent();
    					this.folioPaquete= eElement.getElementsByTagName("Folio_Paquete").item(0).getTextContent();
    					this.folioOrden= eElement.getElementsByTagName("Folio_Orden").item(0).getTextContent();
    					this.cveRastreo= eElement.getElementsByTagName("Cve_Rastreo").item(0).getTextContent();
    					this.cveEmisor= eElement.getElementsByTagName("Cve_Emisor").item(0).getTextContent();
    					this.nomReceptor= eElement.getElementsByTagName("Nombre_Receptor").item(0).getTextContent();
    		
    		}
    	}
        } catch (Exception e) {
    	e.printStackTrace();
        }
        
      }
	
	
	public ArrayList<CdasRequestFromat> getDBCdas(Connection conn, int count)
			throws Exception {
					Statement stmt = null;
					
					StartEstatus = config.StartEstatus;
					IncrementInterval = config.IncrementInterval;
					CtaTypeOne = config.CtaTypeOne;
					CtaTypeTwo = config.CtaTypeTwo;
			         
					if (count == 0)
					{
						StartId = config.StartId;
						sop("--StartId--"+StartId+"-------------");
					}
					else
					{
						sop("--StartId--"+StartId+"-------------");
					}
					
					String query = "SELECT B01_CDA_CUSTOMERBENEFACCNUM, B01_CDA_CUSTOMERBENEFTYPEACC,B01_CDA_OPA_CVE,B01_CDA_FECHA, B01_CDA_TRACKINGKEY FROM B01_DATA_CDA WHERE B01_CDA_CUSTOMERBENEFTYPEACC IN ("+CtaTypeOne+","+CtaTypeTwo+") AND B01_CDA_STATUS ="+StartEstatus
							 + " AND ROWNUM <=" + IncrementInterval + " ORDER BY B01_CDA_CUSTOMERBENEFACCNUM";
					
					//String query = "SELECT NUMERO_CUENTA, TIPO_CUENTA, ID FROM CLOUDAPP.CTAS_UNIQ_CHENTE WHERE TIPO_CUENTA IN ("+CtaTypeOne+","+CtaTypeTwo+") AND ESTATUS ="+StartEstatus  
					//		+ " AND ID >" + StartId + " AND ROWNUM <=" + IncrementInterval + " ORDER BY ID";
					//String query = "SELECT NUMERO_CUENTA, TIPO_CUENTA, ID FROM CLOUDAPP.CTAS_UNIQ_CHENTE WHERE ID = 00135471";
					ArrayList<CdasRequestFromat> datos_cda = new ArrayList<CdasRequestFromat>();
			
					sop(query);
			
					stmt = conn.createStatement();
					ResultSet rs = stmt.executeQuery(query);

					iCount = 0;
					
					while (rs.next()) {
						
						CdasRequestFromat datos_in = new CdasRequestFromat();
						
						//sop("--Num_CTA DB--"+rs.getString("NUMERO_CUENTA")+"------ID------"+rs.getString("ID")+"-------------");
						
						if (rs.getInt("TIPO_CUENTA") == 40)
						{
							
							strConvertCbeCtaCard(rs.getString("NUMERO_CUENTA"));
							//strConvertCbeCta(rs.getString("NUMERO_CUENTA"));
							  
							//sop("--Numero de SUCURSAL--"+strNumSuc+"------");
							
							//sop("--Num_CTA formateada--"+numCta+"------");
							//strCuenta=strNumSuc + strFormatoNumero("000000000000", numCta);
							datos_in.setCte_Num_Cuenta(strCuenta);
						}
						else{
							strCuenta=rs.getString("NUMERO_CUENTA");
							//sop("--Num_CTA es tarjeta--"+strCuenta+"------");
							datos_in.setCte_Num_Cuenta(strCuenta);
						}
						iCount = iCount ++;
			            datos_in.setSa2_Iden_Fecha("170705");
			            datos_in.setSa2_Iden_Hora("170017");
			            strTranId = strFormatoNumero("00000000", rs.getString("ID"));
			            datos_in.setSa2_Iden_Numero(strTranId);
			            datos_in.setID_Envio(iCount);
			            StartId = rs.getString("ID");
			            //sop("--Num_CTA ARRAY--"+ datos_in.getCte_Num_Cuenta()+"-------------");
			            //sop("--ID--"+ datos_in.getSa2_Iden_Numero()+"-------------");
			            //sop("--Fecha --"+ datos_in.getSa2_Iden_Fecha()+"-------------");
						datos_cda.add(datos_in);

					}
			        
					
					rs.close();
					stmt.close();
			
					sop("Found records:" + datos_cda.size());
					iTotal = iTotal + datos_cda.size();
					
					return datos_cda;
				}
	
	public void strConvertCbeCta(String ctaCbe)
	  {
	    this.strNumSuc = ctaCbe.substring(6, 10);
	    this.numCta = ctaCbe.substring(10, ctaCbe.length() - 1);
	  }
	  
	  public String strFormatoNumero(String strFormato, String strDoble)
	  {
	    double dblDoble = 0.0D;
	    try
	    {
	      if (strDoble.indexOf(".") > 0)
	      {
	        dblDoble = Double.valueOf(strDoble).doubleValue();
	        dblDoble *= 100.0D;
	      }
	      else
	      {
	        dblDoble = Double.valueOf(strDoble).longValue();
	      }
	      DecimalFormat objMiFormato = new DecimalFormat(strFormato);
	      return objMiFormato.format(dblDoble);
	    }
	    catch (NullPointerException npe)
	    {
	      DecimalFormat objMiFormato = new DecimalFormat(strFormato);
	      return objMiFormato.format(dblDoble);
	    }
	    catch (NumberFormatException nfe)
	    {
	      DecimalFormat objMiFormato = new DecimalFormat(strFormato);
	      return objMiFormato.format(dblDoble);
	    }
	  }
	  
	  public void strConvertCbeCtaCard (String ctaCbe)
		{

			if(ctaCbe.indexOf("0020736") >= 0)
			{
				if(ctaCbe.length() == 20)
				{
					strCuenta = "517712" + ctaCbe.substring(9, 19);
				} 
				else
				{
					strCuenta = "517712" + ctaCbe.substring(7, 17);
				}
			}
			else if(ctaCbe.indexOf("0020737") >= 0)
			{
				if(ctaCbe.length() == 20)
				{
					strCuenta = "854809" + ctaCbe.substring(9, 19);
				}
				else
				{
					strCuenta = "854809" + ctaCbe.substring(7, 17);
				}
			}
			else if(ctaCbe.indexOf("0020738") >= 0)
			{
				if(ctaCbe.length() == 20)
				{
					strCuenta = "854859" + ctaCbe.substring(9, 19);
				}
				else
				{
					strCuenta = "854859" + ctaCbe.substring(7, 17);
			  }
			}
			else
			{
				//if(ctaCbe.length() == 20)
				//{
					//strCuenta = ctaCbe.substring(8, 19);
				//}
				//else
				//{
				//  strCuenta = ctaCbe.substring(6, 17);
				//}
				strConvertCbeCta(ctaCbe);
				strCuenta=strNumSuc + strFormatoNumero("000000000000", numCta);
			}
			sop("Cuenta Original ["+ctaCbe+"] Cuenta Convertida["+strCuenta+"]");
		}
	
	  
		public static void main(String[] args) throws Exception {

			validacion sans = new validacion("CutCdas.config");
			Recibe16 recibe = new Recibe16("CutCdas.config");
			
			inicio = sans.config.StartId;
			Integer iCount = 0;
			while (true) {
				sans.doSend(iCount);
				Thread.sleep(1000);
				recibe.doRecv();

				System.out.println("-----------------------SLEEPING FOR "
						+ sans.config.IntervalInSeconds
						+ " SECONDS " + (new Date()) + " -----------------------");
				Thread.sleep(Integer.parseInt(sans.config.IntervalInSeconds) * 1000);
				iCount =  iCount +1;
				if(iCount % 75 == 0)
				{
					System.out.println("-----------------------SLEEPING FOR 2000 OPERATIONS FOR "
							+ sans.config.IntervalInSeconds
							+ " SECONDS " + (new Date()) + " -----------------------");
					Thread.sleep(Integer.parseInt(sans.config.IntervalInSeconds) * 4000);
				}
				System.out.println(iCount);

			}	 
			
		}
}
