package bnmx.mq;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;

import javax.jms.Connection;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;

import com.ibm.msg.client.jms.JmsConnectionFactory;
import com.ibm.msg.client.jms.JmsFactoryFactory;
import com.ibm.msg.client.wmq.WMQConstants;

public class validacionQueue {
	private validacionConfig config = null;
	private Connection connection = null;
	private Session session = null;
	private Destination destination = null;
	private Destination replyTo = null;
	private MessageProducer producer = null;
	
	public validacionQueue(validacionConfig config){
		this.config = config;
	}

	public ArrayList<String> sendToMQ(ArrayList<String> sReqs) throws Exception {
		// Variables
		Connection connection = null;
		Session session = null;
		Destination destination = null;
		Destination replyTo = null;
		MessageProducer producer = null;

		try {
			System.out.println("Sender:Initializing Factory");
			JmsFactoryFactory ff = JmsFactoryFactory.getInstance(WMQConstants.WMQ_PROVIDER);
			System.out.println("Sender:Creating Connection Factory");
			JmsConnectionFactory cf = ff.createConnectionFactory();

			// Set the properties
			System.out.println("Sender:Initializing Connection");
			cf.setStringProperty(WMQConstants.WMQ_HOST_NAME, config.SANSOutQueueServer);
			cf.setIntProperty(WMQConstants.WMQ_PORT, Integer.parseInt(config.SANSOutQueuePort));
			cf.setStringProperty(WMQConstants.WMQ_CHANNEL, config.SANSOutQueueChannel);
			cf.setIntProperty(WMQConstants.WMQ_CONNECTION_MODE, WMQConstants.WMQ_CM_CLIENT);
			cf.setStringProperty(WMQConstants.WMQ_QUEUE_MANAGER, config.SANSOutQueueManager);

			// Create JMS objects
			System.out.println("Sender:Creating Connection");
			connection = cf.createConnection();
			System.out.println("Sender:Creating Session");
			session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			System.out.println("Sender:Creating Queue");
			destination = session.createQueue(config.SANSOutQueue);
			((com.ibm.mq.jms.MQQueue) destination).setTargetClient(WMQConstants.WMQ_CLIENT_NONJMS_MQ);
			System.out.println("Sender:Creating ReplyTo Queue");
			replyTo = session.createQueue(config.SANSOutQueueReplyTo);
			System.out.println("Sender:Creating Producer");
			producer = session.createProducer(destination);

			// Start the connection
			System.out.println("Sender:Starting Connection");
			connection.start();
			//Prepare the message
			for(int i=0;i<sReqs.size();i++){
				System.out.println("Sender:Creating Message[" + sReqs.get(i).length() + "][" + sReqs.get(i) + "]");
				TextMessage message = session.createTextMessage(sReqs.get(i));
				message.setJMSReplyTo(replyTo);
				// And, send the message
				System.out.println("Sender:Sending Message");
				producer.send(message);
				System.out.println("Sender:Sent message");
				sReqs.set(i, "SENT");
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (producer != null) {
				try {
					producer.close();
				} catch (JMSException jmsex) {
					System.out.println("Sender:Producer could not be closed.");
				}
			}

			if (session != null) {
				try {
					session.close();
				} catch (JMSException jmsex) {
					System.out.println("Sender:Session could not be closed.");
				}
			}

			if (connection != null) {
				try {
					connection.close();
				} catch (JMSException jmsex) {
					System.out.println("Sender:Connection could not be closed.");
				}
			}
		}

		return sReqs;
	}

	public ArrayList<String> readFromMQ() throws Exception {
		int timeout = 5000;
		Connection connection = null;
		Session session = null;
		Destination destination = null;
		MessageConsumer consumer = null;
		ArrayList<String> response = new ArrayList<String>();
		
		try {
			// Create a connection factory
			System.out.println("Receiver:Initializing Factory");
			JmsFactoryFactory ff = JmsFactoryFactory.getInstance(WMQConstants.WMQ_PROVIDER);
			System.out.println("Receiver:Creating Connection Factory");
			JmsConnectionFactory cf = ff.createConnectionFactory();

			// Set the properties
			System.out.println("Receiver:Initializing Connection");
			cf.setStringProperty(WMQConstants.WMQ_HOST_NAME, config.SANSInQueueServer);
			cf.setIntProperty(WMQConstants.WMQ_PORT, Integer.parseInt(config.SANSInQueuePort));
			cf.setStringProperty(WMQConstants.WMQ_CHANNEL, config.SANSInQueueChannel);
			cf.setIntProperty(WMQConstants.WMQ_CONNECTION_MODE, WMQConstants.WMQ_CM_CLIENT);
			cf.setStringProperty(WMQConstants.WMQ_QUEUE_MANAGER, config.SANSInQueueManager);

			// Create JMS objects
			System.out.println("Receiver:Creating Connection");
			connection = cf.createConnection();
			System.out.println("Receiver:Creating Session");
			session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			System.out.println("Receiver:Creating Queue");
			destination = session.createQueue(config.SANSInQueue);
			System.out.println("Receiver:Creating Consumer");
			consumer = session.createConsumer(destination);

			// Start the connection
			System.out.println("Receiver:Starting Connection");
			connection.start();
			System.out.println("Receiver:Receiving Message");
			boolean anyMessageReceived = false;
			Message message = consumer.receive(timeout);
			//System.out.println("id jefecito " + message.getJMSMessageID());
			while(message != null){
				String text =((TextMessage)message).getText();
				
				if(text != null){
					System.out.println("Receiver:Received message:[" + text.length() + "][" + text + "]");
				}else{
					System.out.println("Receiver:Received message:[" + text + "]");
				}
				
				response.add(((TextMessage)message).getText());
				message = consumer.receive(timeout);
				anyMessageReceived = true;
			}
			if(!anyMessageReceived){
				System.out.println("Receiver:No message received");
			}
		} catch (JMSException ex) {
			ex.printStackTrace();
		} finally {
			if (consumer != null) {
				try {
					consumer.close();
				} catch (JMSException jmsex) {
					System.out.println("Receiver:Consumer could not be closed.");
				}
			}

			if (session != null) {
				try {
					session.close();
				} catch (JMSException jmsex) {
					System.out.println("Receiver:Session could not be closed.");
				}
			}

			if (connection != null) {
				try {
					connection.close();
				} catch (JMSException jmsex) {
					System.out.println("Receiver:Connection could not be closed.");
				}
			}
		}

		return response;
	}
	
	public int connectionMQ(){
		int respuesta = 0;
		try {
			//System.out.println("Sender:Initializing Factory");
			JmsFactoryFactory ff = JmsFactoryFactory.getInstance(WMQConstants.WMQ_PROVIDER);
			//System.out.println("Sender:Creating Connection Factory");
			JmsConnectionFactory cf = ff.createConnectionFactory();
			
  			// Set the properties
			//System.out.println("Sender:Initializing Connection");
			cf.setStringProperty(WMQConstants.WMQ_HOST_NAME, config.SANSOutQueueServer);
			cf.setIntProperty(WMQConstants.WMQ_PORT, Integer.parseInt(config.SANSOutQueuePort));
			cf.setStringProperty(WMQConstants.WMQ_CHANNEL, config.SANSOutQueueChannel);
			cf.setIntProperty(WMQConstants.WMQ_CONNECTION_MODE, WMQConstants.WMQ_CM_CLIENT);
			cf.setStringProperty(WMQConstants.WMQ_QUEUE_MANAGER, config.SANSOutQueueManager);

			// Create JMS objects
			//System.out.println("Sender:Creating Connection");
			connection = cf.createConnection();
			//System.out.println("Sender:Creating Session");
			session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			//System.out.println("Sender:Creating Queue");
			destination = session.createQueue(config.SANSOutQueue);
			((com.ibm.mq.jms.MQQueue) destination).setTargetClient(WMQConstants.WMQ_CLIENT_NONJMS_MQ);
			//System.out.println("Sender:Creating ReplyTo Queue");
			replyTo = session.createQueue(config.SANSOutQueueReplyTo);
			//System.out.println("Sender:Creating Producer");
			producer = session.createProducer(destination);

			// Start the connection
			System.out.println("Sender:Starting Connection");
			connection.start();
			respuesta = 1;
		} catch (Exception ex) {
			
			if (producer != null) {
				try {
					producer.close();
				} catch (JMSException jmsex) {
					System.out.println("Sender:Producer could not be closed.");
				}
			}

			if (session != null) {
				try {
					session.close();
				} catch (JMSException jmsex) {
					System.out.println("Sender:Session could not be closed.");
				}
			}

			if (connection != null) {
				try {
					connection.close();
				} catch (JMSException jmsex) {
					System.out.println("Sender:Connection could not be closed.");
				}
			}

			ex.printStackTrace();
		} 
		return(respuesta);	
	}
	
	public static void main(String[] args) throws Exception{
		validacionConfig config = new validacionConfig("sans.config");
		validacionQueue sansQueue = new validacionQueue(config);
		//sansQueue.sendToMQ("Test1234");
		System.out.println(sansQueue.readFromMQ());
	}
	
	public int closeMQ(){
		if (producer != null) {
			try {
				producer.close();
			} catch (JMSException jmsex) {
				System.out.println("Sender:Producer could not be closed.");
			}
		}

		if (session != null) {
			try {
				session.close();
			} catch (JMSException jmsex) {
				System.out.println("Sender:Session could not be closed.");
			}
		}

		if (connection != null) {
			try {
				connection.close();
			} catch (JMSException jmsex) {
				System.out.println("Sender:Connection could not be closed.");
			}
		}


		return 0;	
	}
}
