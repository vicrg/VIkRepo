package bnmx.mq;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.jms.JMSException;

//Last Updated 28Apr2016 1652 VDI Time
public class Recibe16 {
	public validacionConfig config = null;
	validacionQueue sansQueue = null;
	public HashMap<String, String> txnSent = new HashMap<String, String>();		
	  HashMap<String, String> transax = new HashMap<String, String>();

	public Recibe16(String configPath) throws Exception {
		config = new validacionConfig(configPath);
		sansQueue = new validacionQueue(config);
	}

	public Connection getDBConnection() throws Exception {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection connection = null;
		connection = DriverManager.getConnection(this.config.DBConnStr,
				this.config.DBUserName, this.config.DBPassword);

		return connection;
	}

	
	public int setDBInsertClientes(Connection conn, String cuenta, String tipoCuenta, String numCliente, String nombreCliente, String rfc, String idMessage, String transax)
			throws Exception {
		
		//String nombreClie = null;
		//String transaxion;
		//sop("------- Nombre " + nombreClie );
		
		//nombreClie = nombreCliente.replace("\'" ,"'");
		//transaxion = transax.replace("\'", "'" );
		 PreparedStatement stmt = null;
		
		//sop(query);
		// Primer proceso
		//stmt = conn.prepareStatement("INSERT INTO CLOUDAPP.CDA_CTES_016 (NUMERO_CUENTA, TIPO_CUENTA, NUMERO_CLIENTE, NOMBRE_CLIENTE, RFC_CLIENTE, ID_MENSAJE, CADENA_016) VALUES (?,?,?,?,?,?,?)");
		//stmt = conn.prepareStatement("INSERT INTO CLOUDAPP.CDA_CTES_CUT_016  (NUMERO_CUENTA, TIPO_CUENTA, NUMERO_CLIENTE, NOMBRE_CLIENTE, RFC_CLIENTE, ID_MENSAJE, CADENA_016) VALUES (?,?,?,?,?,?,?)");
		 stmt = conn.prepareStatement("INSERT INTO B02_COSTUMER  (B02_CTES_ORIGINALACCOUNTNUMBER, B02_CTES_READACCOUNTTYPENUMBER, B02_CTES_CUSTOMERNUMBER, B02_CTES_CUSTOMERNAME, B02_CTES_CUSTOMERID) VALUES (?,?,?,?,?)");
		stmt.setString(1, cuenta);
		stmt.setString(2, tipoCuenta);
		stmt.setString(3, numCliente);
		stmt.setString(4, nombreCliente);
		stmt.setString(5, rfc);
		int recordsAffected = stmt.executeUpdate();
		sop("Records Affected : " + recordsAffected);
		stmt.close();
		return recordsAffected;
	}

	public int setDBStatusUpdate(Connection conn, String opaCve, String status, String fecha, String cveRastreo )
			throws Exception {
		Statement stmt = null;
		//Primer Proceso
		//String query = "UPDATE CLOUDAPP.CTAS_UNIQ_CHENTE SET ESTATUS = '" +  status  + "' WHERE ID= '"+ TxnId  + "'";
		//String query = "UPDATE CLOUDAPP.CTAS_UNIQ_CUT SET ESTATUS = '" +  status  + "' WHERE ID= '"+ TxnId  + "'";
		String query = "UPDATE B01_DATA_CDA SET B01_CDA_STATUS = '" +  status  + "' WHERE B01_CDA_OPA_CVE= '"+ opaCve  + "'" + " AND B01_CDA_FECHA= '" + fecha  + "'" + " AND B01_CDA_TRACKINGKEY= '" + cveRastreo + "'";
		sop(query);
		stmt = conn.createStatement();
		int recordsAffected = stmt.executeUpdate(query);
		sop("Records Affected : " + recordsAffected);
		stmt.close();
		return recordsAffected;
	}


	public void sop(Object msg) {
		if (this.config == null) {
			System.out.println(msg);
		} else {
			System.out.println(this.config.AppName + ":" + msg);
		}
	}

	public void doSend() throws Exception {
		
		try {
			guardaDb();
		} catch (Exception ex) {
			ex.printStackTrace();
		} 
	}

	public void doRecv() throws Exception {
		Connection conn = null;
		try {
			sop("-----------------------STARTING-----------------------");

			sop("-----------------------GET RESPONSE FROM QUEUE-----------------------");

			ArrayList<String> response = new ArrayList<String>();

			response = sansQueue.readFromMQ();
			sop("Received Responses : " + response.size());
			//response.add("0001MXBanamex   0870      S264-6503 S264      17        000000000006503                              00000000000000000000000000000000010000000000001409306020161804161257590001NS    AS0                                                                                                                                                                                      00000000010000000000001409152400");

			if (response.size() > 0) {
				sop("-----------------------CONNECTING TO DB-----------------------");
				conn = getDBConnection();

				for (int i = 0; i < response.size(); i++) {
					
					// adding a hardcoded header coz parser is designed to use
					// header but response does not have a header , instead it
					// has 0001 before the message	
					//String originalMessage = response.get(i);
					String originalMessage = response.get(i);
					String message = "cadena original " +response.get(i) ;
					boolean noExiste = false;
					boolean datIncorrectos = false;
					String cuenta = "";
					String tipoCuenta = "";
					String numCliente = "";
					String nombreCliente = "";
					String rfc = "";
					String idMessage="";
					String cadenaCompleta="";
					sop("-----------------------RESPONSE FROM CDAS-----------------------");
					sop("[" + message + "]");
					sop("-----------------------PARSING RESPONSE-----------------------");
					
					noExiste = originalMessage.contains("REGISTRO NO EXISTE EN LA BASE CONT.");
					datIncorrectos = originalMessage.contains("DATOS");
					
					if ((!noExiste) && (!datIncorrectos) && message.length()>300 ){
						//cuenta = message.substring(64,84);
						cuenta = message.substring(169,181);
						tipoCuenta = message.substring(68,70);
						numCliente = message.substring(169,181);
						nombreCliente = message.substring(181,220).trim();
						//rfc = message.substring(358,371);
						rfc = message.substring(374,387);
						idMessage = message.substring(114,122);
						cadenaCompleta=message.substring(0,450).replace("cadena original ", "");
						//setDBStatusUpdate(conn,idMessage ,"1" );
						
					}else {
						 
						
					}
					

					sop("RESPONSE RECEIVED FROM CDAS: [" + originalMessage + "]");
					
					if (cuenta.equals("") || rfc.equals("")) {
						sop("-----------------------ERRRRRRRRRRRRRRRRRRRRRRRR-----------------------");
						if (originalMessage.length() > 122) {
							idMessage = message.substring(114, 122);
						}
						if (noExiste && !datIncorrectos){
							idMessage = message.substring(114,122);
							//setDBStatusUpdate(conn,idMessage ,"2" );
						}else{
							if (!noExiste && datIncorrectos){
								//setDBStatusUpdate(conn,idMessage ,"3" );	
							}else{
								//setDBStatusUpdate(conn,idMessage ,"4" );
							}
							
						}
						
					} else {
							transax.put(cuenta, tipoCuenta+ "|" + numCliente + "|" + nombreCliente+"|"+rfc + "|" + idMessage + "|" + cadenaCompleta);
							guardaDb(); 
						
					}
			}
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (Exception jmsex) {
					sop("Connection could not be closed.");
				}
			}
		}
	}
	
	public void guardaDb() throws Exception{
		Connection conn = null;
		String cuenta = "";
		String tipoCuenta = "";
		String numCliente = "";
		String nombreCliente = "";
		String rfc ="";
		String idMessage ="";
		String tranx  ="";
		
		try {
			conn = getDBConnection();
			
			if (transax.size()>0){
				//transax.forEach((k,v) -> System.out.println("Key: " + k + ": Value: " + v));
				
				for (Map.Entry<String, String> entry : transax.entrySet()) {
				    //System.out.println("clave=" + entry.getKey() + ", valor=" + entry.getValue());
					cuenta = entry.getKey();
					String[] parts = entry.getValue().split("\\|");
					tipoCuenta = parts [0];
					numCliente = parts [1];
					nombreCliente = parts [2];
					rfc = parts [3];
					idMessage = parts [4];
					tranx = parts [5].trim();
					sop("CDAS PARSING:-----------------------SEND TO DB CLIENTES16-----------------------");
					setDBInsertClientes(conn, cuenta, tipoCuenta, numCliente, nombreCliente, rfc, idMessage, tranx );
					transax.remove(cuenta);
					
				}
			}else{
				sop("Mapa Buffer vacio ->" + transax.size());
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (Exception jmsex) {
					sop("Connection could not be closed.");
				}
			}
		}
		
		
	}

	public static void main(String[] args) throws Exception {

		Recibe16 sans = new Recibe16("sans.config");

		while (true) {
			
			//sans.doSend();
			///Thread.sleep(1000);
			
			sans.doRecv();
			//System.out.println("-----------------------SLEEPING FOR "
				//	+ sans.config.IntervalInSeconds
				//	+ " SECONDS " + (new Date()) + " -----------------------");
			Thread.sleep(Integer.parseInt(sans.config.IntervalInSeconds) * 1000);
			

		}
	}
}
